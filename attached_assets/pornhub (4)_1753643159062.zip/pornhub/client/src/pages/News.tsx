import { NewsGrid } from '@/components/News/NewsGrid';

const News = () => {
  return <NewsGrid />;
};

export default News;
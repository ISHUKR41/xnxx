import { AdminDashboard } from '@/components/News/AdminDashboard';

const AdminNews = () => {
  return <AdminDashboard />;
};

export default AdminNews;
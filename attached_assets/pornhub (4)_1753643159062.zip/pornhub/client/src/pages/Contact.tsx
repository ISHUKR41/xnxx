import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Header } from '@/components/StudentHub/Header';
import { UltraEnhancedContactHero } from '@/components/Contact/UltraEnhancedContactHero';
import { ContactStats } from '@/components/Contact/ContactStats';
import { EnhancedContactMethods } from '@/components/Contact/EnhancedContactMethods';
import { ContactFAQ } from '@/components/Contact/ContactFAQ';
import { UltraAdvancedGoogleForm } from '@/components/Contact/UltraAdvancedGoogleForm';
import { BookOpen, FileText, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Contact = () => {
  const [showBackToTop, setShowBackToTop] = useState(false);

  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Handle scroll for back to top button
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const googleFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLSczWJI6cXslwpNgayBkuH0pnKfCZx0weAYi2lbnkLLpb76Myg/viewform?usp=sharing&ouid=109600588350030456546";

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <UltraEnhancedContactHero />
      
      {/* Stats Section */}
      <ContactStats />
      
      {/* Google Forms Section */}
      <section id="contact-form" className="py-20 px-4 bg-gradient-to-br from-accent/5 to-primary/5">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                Request Study Materials
              </span>
            </h2>
            <p className="text-xl text-foreground-secondary max-w-3xl mx-auto">
              Can't find what you're looking for? Use our request forms to get exactly what you need. 
              Our team will locate and provide the materials within 24 hours.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Book Request Form */}
            <UltraAdvancedGoogleForm
              title="Request Books & Textbooks"
              description="Get access to any textbook, reference book, or study material instantly"
              formUrl={googleFormUrl}
              icon={<BookOpen className="w-6 h-6" />}
              color="text-blue-500"
              gradient="from-blue-500/20 to-blue-600/10"
              variant="books"
            />

            {/* PYQ Request Form */}
            <UltraAdvancedGoogleForm
              title="Request Question Papers"
              description="Previous year questions, sample papers, and practice tests"
              formUrl={googleFormUrl}
              icon={<FileText className="w-6 h-6" />}
              color="text-green-500"
              gradient="from-green-500/20 to-green-600/10"
              variant="pyq"
            />
          </div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-16 text-center"
          >
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Why Use Our Request Forms?
              </h3>
              <div className="grid md:grid-cols-3 gap-6 text-sm">
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-blue-500 font-bold text-lg">⚡</span>
                  </div>
                  <div className="font-semibold text-foreground">Quick Response</div>
                  <div className="text-foreground-secondary">Get materials within 24 hours</div>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-green-500 font-bold text-lg">✓</span>
                  </div>
                  <div className="font-semibold text-foreground">Authentic Content</div>
                  <div className="text-foreground-secondary">Only genuine, verified materials</div>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-purple-500 font-bold text-lg">🎯</span>
                  </div>
                  <div className="font-semibold text-foreground">Exact Match</div>
                  <div className="text-foreground-secondary">Precisely what you requested</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Contact Methods */}
      <EnhancedContactMethods />
      
      {/* FAQ Section */}
      <ContactFAQ />
      
      {/* Back to Top Button */}
      {showBackToTop && (
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0 }}
          className="fixed bottom-8 right-8 z-50"
        >
          <Button
            onClick={scrollToTop}
            size="lg"
            className="rounded-full w-14 h-14 bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <ArrowUp className="w-6 h-6" />
          </Button>
        </motion.div>
      )}
    </div>
  );
};

export default Contact;
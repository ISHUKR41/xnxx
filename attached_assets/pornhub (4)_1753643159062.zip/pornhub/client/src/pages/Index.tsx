import { LandingPage } from '@/components/StudentHub/LandingPage';

const Index = () => {
  return <LandingPage />;
};

export default Index;

import { NewsArticleView } from '@/components/News/NewsArticleView';

const NewsDetail = () => {
  return <NewsArticleView />;
};

export default NewsDetail;
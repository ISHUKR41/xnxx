import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import * as THREE from 'three';

interface EnhancedAnimatedLogoProps {
  size?: number;
  className?: string;
  showText?: boolean;
}

export const EnhancedAnimatedLogo: React.FC<EnhancedAnimatedLogoProps> = ({ 
  size = 60, 
  className = '', 
  showText = false 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const animationIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: false,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = false;

    // Enhanced lighting system
    const ambientLight = new THREE.AmbientLight(0x404040, 0.8);
    scene.add(ambientLight);
    
    const directionalLight1 = new THREE.DirectionalLight(0x667eea, 1.0);
    directionalLight1.position.set(2, 2, 2);
    scene.add(directionalLight1);
    
    const directionalLight2 = new THREE.DirectionalLight(0xf093fb, 0.7);
    directionalLight2.position.set(-2, -1, 1);
    scene.add(directionalLight2);

    // Ultra-modern Central Knowledge Hub (Icosahedron)
    const hubGeometry = new THREE.IcosahedronGeometry(0.5, 2);
    const hubMaterial = new THREE.MeshBasicMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.8,
      wireframe: false
    });
    const knowledgeHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(knowledgeHub);

    // Floating S and H letters (as geometric shapes)
    const letterSGeometry = new THREE.TorusGeometry(0.2, 0.05, 8, 16);
    const letterSMaterial = new THREE.MeshBasicMaterial({ color: 0xf093fb, transparent: true, opacity: 0.9 });
    const letterS = new THREE.Mesh(letterSGeometry, letterSMaterial);
    letterS.position.set(-0.8, 0.3, 0.5);
    scene.add(letterS);

    const letterHGeometry = new THREE.BoxGeometry(0.1, 0.4, 0.05);
    const letterHMaterial = new THREE.MeshBasicMaterial({ color: 0x764ba2, transparent: true, opacity: 0.9 });
    const letterH1 = new THREE.Mesh(letterHGeometry, letterHMaterial);
    const letterH2 = new THREE.Mesh(letterHGeometry, letterHMaterial);
    const letterHBar = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.05, 0.05), letterHMaterial);
    
    letterH1.position.set(0.7, 0.2, 0.5);
    letterH2.position.set(0.9, 0.2, 0.5);
    letterHBar.position.set(0.8, 0.2, 0.5);
    
    scene.add(letterH1);
    scene.add(letterH2);
    scene.add(letterHBar);

    // Orbital particles
    const particleGeometry = new THREE.SphereGeometry(0.02, 8, 8);
    const particles: THREE.Mesh[] = [];
    
    for (let i = 0; i < 20; i++) {
      const particleMaterial = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL(i / 20, 0.8, 0.6),
        transparent: true,
        opacity: 0.7
      });
      const particle = new THREE.Mesh(particleGeometry, particleMaterial);
      
      const radius = 1.2 + Math.random() * 0.5;
      const angle = (i / 20) * Math.PI * 2;
      particle.position.set(
        Math.cos(angle) * radius,
        Math.sin(angle * 0.5) * 0.3,
        Math.sin(angle) * radius
      );
      
      scene.add(particle);
      particles.push(particle);
    }

    // Multiple animated rings
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const ringGeometry = new THREE.TorusGeometry(0.8 + i * 0.2, 0.02, 8, 32);
      const ringMaterial = new THREE.MeshBasicMaterial({ 
        color: [0x667eea, 0x764ba2, 0xf093fb][i],
        transparent: true,
        opacity: 0.4
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.rotation.x = Math.PI / 2 + (i * 0.3);
      ring.rotation.y = i * 0.5;
      scene.add(ring);
      rings.push(ring);
    }

    camera.position.z = 3;

    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      const time = Date.now() * 0.001;
      const hoverMultiplier = isHovered ? 2 : 1;
      
      // Rotate central hub
      knowledgeHub.rotation.x += 0.01 * hoverMultiplier;
      knowledgeHub.rotation.y += 0.015 * hoverMultiplier;
      knowledgeHub.rotation.z += 0.005 * hoverMultiplier;
      
      // Animate floating letters
      letterS.rotation.z += 0.02 * hoverMultiplier;
      letterS.position.y = 0.3 + Math.sin(time * 2) * 0.1;
      
      letterH1.rotation.x += 0.01 * hoverMultiplier;
      letterH2.rotation.x += 0.01 * hoverMultiplier;
      letterHBar.rotation.y += 0.02 * hoverMultiplier;
      
      // Animate orbital particles
      particles.forEach((particle, index) => {
        const angle = time * 0.5 + (index / particles.length) * Math.PI * 2;
        const radius = 1.2 + Math.sin(time * 2 + index) * 0.2;
        particle.position.x = Math.cos(angle) * radius;
        particle.position.z = Math.sin(angle) * radius;
        particle.position.y = Math.sin(time * 3 + index) * 0.3;
        particle.rotation.x += 0.02;
        particle.rotation.y += 0.02;
      });
      
      // Animate rings
      rings.forEach((ring, index) => {
        ring.rotation.z += (0.005 + index * 0.002) * hoverMultiplier;
        ring.rotation.x += 0.003 * hoverMultiplier;
      });
      
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      renderer.dispose();
    };
  }, [size, isHovered]);

  return (
    <motion.div
      className={`relative ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.1 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {/* Main 3D Logo */}
      <motion.canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="block"
        animate={{ 
          filter: isHovered ? "drop-shadow(0 10px 20px rgba(102, 126, 234, 0.3))" : "none"
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 rounded-full bg-gradient-to-r from-primary via-accent to-primary opacity-0 blur-lg"
        animate={{ 
          opacity: isHovered ? 0.3 : 0,
          scale: isHovered ? 1.2 : 1
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Floating sparkles */}
      {isHovered && (
        <div className="absolute inset-0">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full"
              initial={{ 
                x: size / 2, 
                y: size / 2, 
                opacity: 0 
              }}
              animate={{
                x: size / 2 + (Math.random() - 0.5) * size,
                y: size / 2 + (Math.random() - 0.5) * size,
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 1.5,
                delay: i * 0.2,
                repeat: Infinity
              }}
            />
          ))}
        </div>
      )}
      
      {/* Text logo */}
      {showText && (
        <motion.div
          className="ml-3 hidden md:block"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="text-2xl font-bold">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              STUDENT
            </span>
            <span className="text-foreground">HUB</span>
          </div>
          <motion.div 
            className="text-xs text-foreground-secondary font-medium"
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Academic Excellence Portal
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};
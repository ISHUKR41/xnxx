import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface AnimatedLogoProps {
  size?: number;
  className?: string;
}

export const AnimatedLogo: React.FC<AnimatedLogoProps> = ({ size = 60, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: false, // Disabled for performance
      powerPreference: "high-performance"
    });
    
    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = false; // Disabled for performance

    // Optimized lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0x667eea, 0.8);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Ultra-modern Central Knowledge Hub
    const hubGeometry = new THREE.IcosahedronGeometry(0.4, 1);
    const hubMaterial = new THREE.MeshBasicMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.9,
      wireframe: false
    });
    const knowledgeHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(knowledgeHub);

    // Add pulsing inner core
    const coreGeometry = new THREE.SphereGeometry(0.2, 12, 12);
    const coreMaterial = new THREE.MeshBasicMaterial({
      color: 0xf093fb,
      transparent: true,
      opacity: 0.7
    });
    const core = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(core);

    // Multiple animated rings
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const ringGeometry = new THREE.TorusGeometry(0.5 + i * 0.1, 0.01, 4, 16);
      const ringMaterial = new THREE.MeshBasicMaterial({
        color: [0x667eea, 0x764ba2, 0xf093fb][i],
        transparent: true,
        opacity: 0.6 - i * 0.1
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      rings.push(ring);
      scene.add(ring);
    }

    // Simplified but more attractive letters
    const letterMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.95
    });

    // S letter as extruded shape
    const sShape = new THREE.Shape();
    sShape.moveTo(-0.15, 0.2);
    sShape.lineTo(0.15, 0.2);
    sShape.lineTo(0.15, 0.05);
    sShape.lineTo(-0.05, 0.05);
    sShape.lineTo(-0.05, -0.05);
    sShape.lineTo(0.15, -0.05);
    sShape.lineTo(0.15, -0.2);
    sShape.lineTo(-0.15, -0.2);
    sShape.lineTo(-0.15, -0.05);
    sShape.lineTo(0.05, -0.05);
    sShape.lineTo(0.05, 0.05);
    sShape.lineTo(-0.15, 0.05);
    sShape.lineTo(-0.15, 0.2);

    const sGeometry = new THREE.ExtrudeGeometry(sShape, { depth: 0.02, bevelEnabled: false });
    const sLetter = new THREE.Mesh(sGeometry, letterMaterial);
    sLetter.position.set(-0.4, 0, 0.4);
    scene.add(sLetter);

    // H letter as simple boxes
    const hMaterial = letterMaterial.clone();
    const hBar1 = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.4, 0.02), hMaterial);
    hBar1.position.set(0.25, 0, 0.4);
    
    const hBar2 = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.4, 0.02), hMaterial);
    hBar2.position.set(0.4, 0, 0.4);
    
    const hBar3 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, 0.02), hMaterial);
    hBar3.position.set(0.325, 0, 0.4);
    
    scene.add(hBar1, hBar2, hBar3);

    // Optimized floating particles
    const particles: THREE.Mesh[] = [];
    const particleGeometry = new THREE.SphereGeometry(0.015, 4, 4);
    
    for (let i = 0; i < 8; i++) {
      const particle = new THREE.Mesh(
        particleGeometry,
        new THREE.MeshBasicMaterial({ 
          color: [0x10B981, 0xF59E0B, 0xEF4444, 0x8B5CF6][i % 4],
          transparent: true,
          opacity: 0.6
        })
      );
      
      const radius = 0.7 + Math.random() * 0.3;
      const angle = (i / 8) * Math.PI * 2;
      particle.position.set(
        Math.cos(angle) * radius,
        (Math.random() - 0.5) * 0.8,
        Math.sin(angle) * radius
      );
      
      scene.add(particle);
      particles.push(particle);
    }

    camera.position.z = 2.5;

    const animate = () => {
      const time = Date.now() * 0.001;
      
      // Rotate the main hub with multiple axes
      knowledgeHub.rotation.y += 0.02;
      knowledgeHub.rotation.x += 0.01;
      
      // Animate the core
      core.rotation.x += 0.03;
      core.rotation.z += 0.025;
      if (core.material instanceof THREE.MeshBasicMaterial) {
        core.material.opacity = 0.5 + Math.sin(time * 2) * 0.3;
      }
      
      // Animate rings
      rings.forEach((ring, index) => {
        ring.rotation.x += 0.01 * (index + 1);
        ring.rotation.y += 0.005 * (index + 1);
        ring.rotation.z += 0.008 * (index + 1);
      });
      
      // Animate letters
      sLetter.rotation.y += 0.015;
      sLetter.position.y = Math.sin(time * 1.5) * 0.03;
      
      hBar1.rotation.y += 0.012;
      hBar2.rotation.y += 0.012;
      hBar3.rotation.y += 0.012;
      hBar1.position.y = Math.cos(time * 1.3) * 0.025;
      hBar2.position.y = Math.cos(time * 1.3) * 0.025;
      hBar3.position.y = Math.cos(time * 1.3) * 0.025;
      
      // Animate particles with smoother orbital motion
      particles.forEach((particle, index) => {
        const baseRadius = 0.7 + Math.sin(time * 0.8 + index) * 0.15;
        const angle = (index / particles.length) * Math.PI * 2 + time * 0.3;
        
        particle.position.x = Math.cos(angle) * baseRadius;
        particle.position.z = Math.sin(angle) * baseRadius;
        particle.position.y = Math.sin(time * 1.5 + index) * 0.2;
        
        particle.rotation.y += 0.02;
        
        // Pulsing opacity
        if (particle.material instanceof THREE.MeshBasicMaterial) {
          particle.material.opacity = 0.4 + Math.sin(time * 2 + index) * 0.3;
        }
      });

      renderer.render(scene, camera);
      animationIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [size]);

  return (
    <div className={`inline-block ${className}`}>
      <canvas 
        ref={canvasRef} 
        width={size} 
        height={size}
        className="rounded-xl"
        style={{ 
          filter: 'drop-shadow(0 8px 16px rgba(102, 126, 234, 0.4)) drop-shadow(0 4px 8px rgba(118, 75, 162, 0.3))',
          transition: 'all 0.3s ease',
          background: 'radial-gradient(circle, rgba(102,126,234,0.1) 0%, rgba(118,75,162,0.1) 100%)'
        }}
      />
    </div>
  );
};
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as THREE from 'three';

interface UltraModernLogoV2Props {
  size?: number;
  className?: string;
  showText?: boolean;
  variant?: 'main' | 'compact' | 'icon';
}

export const UltraModernLogoV2: React.FC<UltraModernLogoV2Props> = ({ 
  size = 64, 
  className = '', 
  showText = true,
  variant = 'main'
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const frameRef = useRef<number | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    sceneRef.current = scene;
    rendererRef.current = renderer;

    // Enhanced Lighting System
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);
    
    const primaryLight = new THREE.DirectionalLight(0x667eea, 1.2);
    primaryLight.position.set(2, 2, 2);
    scene.add(primaryLight);
    
    const accentLight = new THREE.DirectionalLight(0xf093fb, 0.8);
    accentLight.position.set(-2, 1, 1);
    scene.add(accentLight);

    const backLight = new THREE.DirectionalLight(0x4facfe, 0.6);
    backLight.position.set(0, -2, -1);
    scene.add(backLight);

    // Ultra-Modern Central Knowledge Hub (Dodecahedron)
    const hubGeometry = new THREE.DodecahedronGeometry(0.35, 0);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.9,
      shininess: 100,
      specular: 0x4facfe
    });
    const knowledgeHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(knowledgeHub);

    // Inner Core Crystal
    const coreGeometry = new THREE.OctahedronGeometry(0.15, 1);
    const coreMaterial = new THREE.MeshPhongMaterial({
      color: 0xf093fb,
      transparent: true,
      opacity: 0.8,
      emissive: 0xf093fb,
      emissiveIntensity: 0.1
    });
    const innerCore = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(innerCore);

    // Floating S and H Letters with 3D Extrusion
    // Note: FontLoader removed for performance, using simple geometry instead
    
    // Create 3D Letters (using basic geometry for performance)
    const letterGeometry = new THREE.BoxGeometry(0.15, 0.2, 0.05);
    const letterSMaterial = new THREE.MeshPhongMaterial({
      color: 0x00d4ff,
      transparent: true,
      opacity: 0.9
    });
    const letterHMaterial = new THREE.MeshPhongMaterial({
      color: 0xff6b6b,
      transparent: true,
      opacity: 0.9
    });

    const letterS = new THREE.Mesh(letterGeometry, letterSMaterial);
    letterS.position.set(-0.6, 0.3, 0);
    scene.add(letterS);

    const letterH = new THREE.Mesh(letterGeometry, letterHMaterial);
    letterH.position.set(0.6, -0.3, 0);
    scene.add(letterH);

    // Multiple Animated Rings
    const rings: THREE.Mesh[] = [];
    const ringConfigs = [
      { radius: 0.7, thickness: 0.02, color: 0x667eea, speed: 0.01, axis: 'x' },
      { radius: 0.8, thickness: 0.015, color: 0xf093fb, speed: -0.008, axis: 'y' },
      { radius: 0.9, thickness: 0.01, color: 0x4facfe, speed: 0.012, axis: 'z' },
      { radius: 1.0, thickness: 0.008, color: 0x00d4ff, speed: -0.006, axis: 'xy' }
    ];

    ringConfigs.forEach(config => {
      const ringGeometry = new THREE.TorusGeometry(config.radius, config.thickness, 8, 32);
      const ringMaterial = new THREE.MeshPhongMaterial({
        color: config.color,
        transparent: true,
        opacity: 0.6,
        emissive: config.color,
        emissiveIntensity: 0.1
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.userData = { ...config };
      rings.push(ring);
      scene.add(ring);
    });

    // Orbital Particles System
    const particles: THREE.Mesh[] = [];
    const particleGeometry = new THREE.SphereGeometry(0.015, 8, 8);
    
    for (let i = 0; i < 20; i++) {
      const particleMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(Math.random(), 0.8, 0.6),
        transparent: true,
        opacity: 0.8,
        emissive: new THREE.Color().setHSL(Math.random(), 0.8, 0.3),
        emissiveIntensity: 0.2
      });
      
      const particle = new THREE.Mesh(particleGeometry, particleMaterial);
      const radius = 1.2 + Math.random() * 0.5;
      const angle = (i / 20) * Math.PI * 2;
      
      particle.position.set(
        Math.cos(angle) * radius,
        (Math.random() - 0.5) * 0.5,
        Math.sin(angle) * radius
      );
      
      particle.userData = { 
        angle, 
        radius,
        speed: 0.005 + Math.random() * 0.01,
        bobAmplitude: 0.1 + Math.random() * 0.2,
        bobSpeed: 0.02 + Math.random() * 0.03
      };
      
      particles.push(particle);
      scene.add(particle);
    }

    camera.position.z = 2.5;

    // Enhanced Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Rotate main hub with multiple axes
      knowledgeHub.rotation.x += 0.008;
      knowledgeHub.rotation.y += 0.012;
      knowledgeHub.rotation.z += 0.006;
      
      // Counter-rotate inner core
      innerCore.rotation.x -= 0.015;
      innerCore.rotation.y -= 0.010;
      innerCore.rotation.z += 0.008;

      // Animate letters with floating motion
      letterS.position.y = 0.3 + Math.sin(time * 2) * 0.1;
      letterS.rotation.z = Math.sin(time * 1.5) * 0.2;
      
      letterH.position.y = -0.3 + Math.cos(time * 2.2) * 0.1;
      letterH.rotation.z = Math.cos(time * 1.3) * 0.2;

      // Animate rings with complex rotations
      rings.forEach((ring, index) => {
        const config = ring.userData;
        switch(config.axis) {
          case 'x':
            ring.rotation.x += config.speed;
            break;
          case 'y':
            ring.rotation.y += config.speed;
            break;
          case 'z':
            ring.rotation.z += config.speed;
            break;
          case 'xy':
            ring.rotation.x += config.speed;
            ring.rotation.y += config.speed * 0.7;
            break;
        }
        
        // Hover effect
        if (isHovered) {
          ring.rotation.y += 0.02;
          const material = ring.material as THREE.MeshPhongMaterial;
          material.opacity = Math.min(1, material.opacity + 0.02);
        } else {
          const material = ring.material as THREE.MeshPhongMaterial;
          material.opacity = Math.max(0.6, material.opacity - 0.01);
        }
      });

      // Animate orbital particles
      particles.forEach((particle, index) => {
        const userData = particle.userData;
        userData.angle += userData.speed;
        
        particle.position.x = Math.cos(userData.angle) * userData.radius;
        particle.position.z = Math.sin(userData.angle) * userData.radius;
        particle.position.y = Math.sin(time * userData.bobSpeed + index) * userData.bobAmplitude;
        
        particle.rotation.x += 0.02;
        particle.rotation.y += 0.015;
        
        // Hover glow effect
        if (isHovered) {
          const material = particle.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0.4;
          particle.scale.setScalar(1.2);
        } else {
          const material = particle.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0.2;
          particle.scale.setScalar(1);
        }
      });

      // Camera subtle movement
      camera.position.x = Math.sin(time * 0.5) * 0.1;
      camera.position.y = Math.cos(time * 0.3) * 0.05;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();
    setIsLoaded(true);

    // Cleanup
    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [size, isHovered]);

  const logoVariants = {
    main: "flex items-center space-x-3",
    compact: "flex items-center space-x-2",
    icon: "flex items-center justify-center"
  };

  return (
    <motion.div
      className={`${logoVariants[variant]} ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, type: "spring", bounce: 0.3 }}
    >
      {/* 3D Canvas Logo */}
      <motion.div
        className="relative"
        whileHover={{ scale: 1.05, rotateY: 5 }}
        transition={{ duration: 0.3 }}
      >
        <canvas
          ref={canvasRef}
          width={size}
          height={size}
          className="drop-shadow-lg"
          style={{ width: size, height: size }}
        />
        
        {/* Loading indicator */}
        <AnimatePresence>
          {!isLoaded && (
            <motion.div
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg"
            >
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hover Glow Effect */}
        <motion.div
          className="absolute inset-0 rounded-lg"
          animate={{
            boxShadow: isHovered 
              ? "0 0 30px rgba(102, 126, 234, 0.4), 0 0 60px rgba(240, 147, 251, 0.2)"
              : "0 0 0px rgba(102, 126, 234, 0)"
          }}
          transition={{ duration: 0.3 }}
        />
      </motion.div>

      {/* Enhanced Text Logo */}
      {showText && variant !== 'icon' && (
        <motion.div
          className={variant === 'compact' ? "hidden md:block" : "hidden lg:block"}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <motion.div 
            className={`font-bold ${variant === 'compact' ? 'text-lg' : 'text-xl xl:text-2xl'}`}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <motion.span 
              className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent bg-size-200 bg-pos-0"
              animate={{
                backgroundPosition: isHovered ? '100%' : '0%'
              }}
              transition={{ duration: 1, ease: "easeInOut" }}
            >
              STUDENT
            </motion.span>
            <span className="text-foreground">HUB</span>
            <motion.span
              className="text-accent"
              animate={{ 
                opacity: [1, 0.7, 1],
                scale: isHovered ? [1, 1.1, 1] : 1
              }}
              transition={{ 
                opacity: { duration: 2, repeat: Infinity },
                scale: { duration: 0.3 }
              }}
            >
              .COM
            </motion.span>
          </motion.div>
          
          {variant === 'main' && (
            <motion.div 
              className="text-xs text-foreground-secondary font-medium tracking-wide"
              animate={{ 
                opacity: [0.7, 1, 0.7],
                y: isHovered ? [-1, 1, -1] : 0
              }}
              transition={{ 
                opacity: { duration: 3, repeat: Infinity },
                y: { duration: 2, repeat: Infinity }
              }}
            >
              Academic Excellence Portal
            </motion.div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as THREE from 'three';

interface UltraModernLogoV3Props {
  size?: number;
  className?: string;
  showText?: boolean;
  variant?: 'main' | 'compact' | 'icon' | 'hero';
}

export const UltraModernLogoV3: React.FC<UltraModernLogoV3Props> = ({ 
  size = 64, 
  className = '', 
  showText = true,
  variant = 'main'
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const frameRef = useRef<number | null>(null);

  // Mouse tracking for interactive effects
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        setMousePosition({
          x: ((e.clientX - rect.left) / rect.width - 0.5) * 2,
          y: ((e.clientY - rect.top) / rect.height - 0.5) * 2
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize Three.js scene with enhanced settings
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    sceneRef.current = scene;
    rendererRef.current = renderer;

    // Advanced Lighting System
    const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
    scene.add(ambientLight);
    
    const primaryLight = new THREE.DirectionalLight(0x667eea, 1.5);
    primaryLight.position.set(3, 3, 3);
    primaryLight.castShadow = true;
    primaryLight.shadow.mapSize.width = 1024;
    primaryLight.shadow.mapSize.height = 1024;
    scene.add(primaryLight);
    
    const accentLight = new THREE.DirectionalLight(0xf093fb, 1.0);
    accentLight.position.set(-2, 2, 1);
    scene.add(accentLight);

    const backLight = new THREE.DirectionalLight(0x4facfe, 0.8);
    backLight.position.set(0, -3, -2);
    scene.add(backLight);

    // Central Knowledge Hub - Ultra Modern Icosahedral Design
    const hubGeometry = new THREE.IcosahedronGeometry(0.4, 2);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.9,
      shininess: 100,
      specular: 0x4facfe,
      emissive: 0x667eea,
      emissiveIntensity: 0.1
    });
    const knowledgeHub = new THREE.Mesh(hubGeometry, hubMaterial);
    knowledgeHub.castShadow = true;
    knowledgeHub.receiveShadow = true;
    scene.add(knowledgeHub);

    // Nested Crystal Core
    const coreGeometry = new THREE.OctahedronGeometry(0.2, 2);
    const coreMaterial = new THREE.MeshPhongMaterial({
      color: 0xf093fb,
      transparent: true,
      opacity: 0.8,
      emissive: 0xf093fb,
      emissiveIntensity: 0.2,
      shininess: 200
    });
    const innerCore = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(innerCore);

    // Multiple Orbital Ring System
    const rings: THREE.Mesh[] = [];
    const ringConfigs = [
      { radius: 0.8, thickness: 0.02, color: 0x667eea, speed: 0.015, axis: 'x', opacity: 0.7 },
      { radius: 0.95, thickness: 0.018, color: 0xf093fb, speed: -0.012, axis: 'y', opacity: 0.6 },
      { radius: 1.1, thickness: 0.015, color: 0x4facfe, speed: 0.018, axis: 'z', opacity: 0.5 },
      { radius: 1.25, thickness: 0.012, color: 0x00d4ff, speed: -0.009, axis: 'xy', opacity: 0.4 },
      { radius: 1.4, thickness: 0.01, color: 0xff6b6b, speed: 0.021, axis: 'xyz', opacity: 0.3 }
    ];

    ringConfigs.forEach(config => {
      const ringGeometry = new THREE.TorusGeometry(config.radius, config.thickness, 8, 32);
      const ringMaterial = new THREE.MeshPhongMaterial({
        color: config.color,
        transparent: true,
        opacity: config.opacity,
        emissive: config.color,
        emissiveIntensity: 0.1
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.userData = { ...config };
      rings.push(ring);
      scene.add(ring);
    });

    // Floating Letter Elements - S and H
    const letterSGeometry = new THREE.ExtrudeGeometry(
      new THREE.Shape().moveTo(0, 0).lineTo(0.15, 0).lineTo(0.15, 0.1).lineTo(0, 0.1).closePath(),
      { depth: 0.05, bevelEnabled: true, bevelSize: 0.01, bevelThickness: 0.01 }
    );
    const letterSMaterial = new THREE.MeshPhongMaterial({
      color: 0x00d4ff,
      transparent: true,
      opacity: 0.9,
      emissive: 0x00d4ff,
      emissiveIntensity: 0.1
    });
    const letterS = new THREE.Mesh(letterSGeometry, letterSMaterial);
    letterS.position.set(-0.7, 0.4, 0);
    scene.add(letterS);

    const letterHGeometry = new THREE.ExtrudeGeometry(
      new THREE.Shape().moveTo(0, 0).lineTo(0.15, 0).lineTo(0.15, 0.1).lineTo(0, 0.1).closePath(),
      { depth: 0.05, bevelEnabled: true, bevelSize: 0.01, bevelThickness: 0.01 }
    );
    const letterHMaterial = new THREE.MeshPhongMaterial({
      color: 0xff6b6b,
      transparent: true,
      opacity: 0.9,
      emissive: 0xff6b6b,
      emissiveIntensity: 0.1
    });
    const letterH = new THREE.Mesh(letterHGeometry, letterHMaterial);
    letterH.position.set(0.7, -0.4, 0);
    scene.add(letterH);

    // Advanced Particle System
    const particles: THREE.Mesh[] = [];
    const particleTypes = [
      { geometry: new THREE.SphereGeometry(0.02, 8, 8), color: 0x4facfe, count: 15 },
      { geometry: new THREE.TetrahedronGeometry(0.025, 0), color: 0xf093fb, count: 10 },
      { geometry: new THREE.OctahedronGeometry(0.02, 0), color: 0x00d4ff, count: 12 },
      { geometry: new THREE.BoxGeometry(0.03, 0.03, 0.03), color: 0xff6b6b, count: 8 }
    ];

    particleTypes.forEach(type => {
      for (let i = 0; i < type.count; i++) {
        const particleMaterial = new THREE.MeshPhongMaterial({
          color: type.color,
          transparent: true,
          opacity: 0.8,
          emissive: type.color,
          emissiveIntensity: 0.2
        });
        
        const particle = new THREE.Mesh(type.geometry, particleMaterial);
        const radius = 1.5 + Math.random() * 1.0;
        const angle = (i / type.count) * Math.PI * 2;
        
        particle.position.set(
          Math.cos(angle) * radius,
          (Math.random() - 0.5) * 1.0,
          Math.sin(angle) * radius
        );
        
        particle.userData = { 
          angle, 
          radius,
          speed: 0.003 + Math.random() * 0.008,
          bobAmplitude: 0.1 + Math.random() * 0.3,
          bobSpeed: 0.015 + Math.random() * 0.025,
          rotationSpeed: new THREE.Vector3(
            (Math.random() - 0.5) * 0.05,
            (Math.random() - 0.5) * 0.05,
            (Math.random() - 0.5) * 0.05
          )
        };
        
        particles.push(particle);
        scene.add(particle);
      }
    });

    // Data Connection Lines
    const connections: THREE.Line[] = [];
    for (let i = 0; i < 20; i++) {
      const points = [];
      const startRadius = 0.5 + Math.random() * 0.5;
      const endRadius = 1.5 + Math.random() * 1.0;
      
      points.push(new THREE.Vector3(
        Math.cos(i * 0.3) * startRadius,
        (Math.random() - 0.5) * 0.5,
        Math.sin(i * 0.3) * startRadius
      ));
      
      points.push(new THREE.Vector3(
        Math.cos(i * 0.3 + 1) * endRadius,
        (Math.random() - 0.5) * 1.0,
        Math.sin(i * 0.3 + 1) * endRadius
      ));
      
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const material = new THREE.LineBasicMaterial({ 
        color: 0x667eea,
        transparent: true,
        opacity: 0.3
      });
      const line = new THREE.Line(geometry, material);
      connections.push(line);
      scene.add(line);
    }

    camera.position.z = 3;

    // Enhanced Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Central hub complex rotation
      knowledgeHub.rotation.x += 0.008 + (isHovered ? 0.004 : 0);
      knowledgeHub.rotation.y += 0.012 + (isHovered ? 0.006 : 0);
      knowledgeHub.rotation.z += 0.006 + (isHovered ? 0.003 : 0);
      
      // Inner core counter-rotation
      innerCore.rotation.x -= 0.018;
      innerCore.rotation.y -= 0.015;
      innerCore.rotation.z += 0.012;

      // Complex ring animations
      rings.forEach((ring, index) => {
        const config = ring.userData;
        const material = ring.material as THREE.MeshPhongMaterial;
        
        switch(config.axis) {
          case 'x':
            ring.rotation.x += config.speed;
            break;
          case 'y':
            ring.rotation.y += config.speed;
            break;
          case 'z':
            ring.rotation.z += config.speed;
            break;
          case 'xy':
            ring.rotation.x += config.speed;
            ring.rotation.y += config.speed * 0.7;
            break;
          case 'xyz':
            ring.rotation.x += config.speed;
            ring.rotation.y += config.speed * 0.8;
            ring.rotation.z += config.speed * 0.6;
            break;
        }
        
        // Interactive effects
        if (isHovered) {
          ring.rotation.y += 0.02;
          material.opacity = Math.min(1, material.opacity + 0.02);
          material.emissiveIntensity = 0.3;
        } else {
          material.opacity = Math.max(config.opacity, material.opacity - 0.01);
          material.emissiveIntensity = 0.1;
        }
      });

      // Advanced letter animations
      letterS.position.y = 0.4 + Math.sin(time * 2.5) * 0.15;
      letterS.rotation.x = Math.sin(time * 1.8) * 0.3;
      letterS.rotation.z = Math.sin(time * 1.2) * 0.2;
      
      letterH.position.y = -0.4 + Math.cos(time * 2.8) * 0.15;
      letterH.rotation.x = Math.cos(time * 1.6) * 0.3;
      letterH.rotation.z = Math.cos(time * 1.4) * 0.2;

      // Advanced particle system
      particles.forEach((particle, index) => {
        const userData = particle.userData;
        userData.angle += userData.speed;
        
        // Complex orbital motion
        particle.position.x = Math.cos(userData.angle) * userData.radius;
        particle.position.z = Math.sin(userData.angle) * userData.radius;
        particle.position.y = Math.sin(time * userData.bobSpeed + index) * userData.bobAmplitude;
        
        // 3D rotations
        particle.rotation.x += userData.rotationSpeed.x;
        particle.rotation.y += userData.rotationSpeed.y;
        particle.rotation.z += userData.rotationSpeed.z;
        
        const material = particle.material as THREE.MeshPhongMaterial;
        
        // Interactive glow effects
        if (isHovered) {
          material.emissiveIntensity = 0.5;
          particle.scale.setScalar(1.3);
        } else {
          material.emissiveIntensity = 0.2;
          particle.scale.setScalar(1);
        }
      });

      // Animate connections
      connections.forEach((line, index) => {
        line.rotation.z += 0.002;
        const material = line.material as THREE.LineBasicMaterial;
        material.opacity = 0.2 + Math.sin(time * 2 + index) * 0.1;
      });

      // Mouse interaction camera movement
      camera.position.x = Math.sin(time * 0.3) * 0.1 + mousePosition.x * 0.2;
      camera.position.y = Math.cos(time * 0.2) * 0.05 + mousePosition.y * 0.15;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();
    setIsLoaded(true);

    // Cleanup
    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [size, isHovered, mousePosition]);

  const logoVariants = {
    main: "flex items-center space-x-4",
    compact: "flex items-center space-x-2",
    icon: "flex items-center justify-center",
    hero: "flex items-center space-x-6"
  };

  const textSizes = {
    main: "text-xl xl:text-2xl",
    compact: "text-lg",
    icon: "text-base",
    hero: "text-3xl xl:text-4xl"
  };

  return (
    <motion.div
      className={`${logoVariants[variant]} ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      initial={{ opacity: 0, scale: 0.8, rotateY: -15 }}
      animate={{ opacity: 1, scale: 1, rotateY: 0 }}
      transition={{ duration: 1, type: "spring", bounce: 0.3 }}
    >
      {/* Enhanced 3D Canvas Logo */}
      <motion.div
        className="relative"
        whileHover={{ 
          scale: 1.05, 
          rotateY: 8,
          rotateX: 3
        }}
        transition={{ duration: 0.4, type: "spring" }}
      >
        <canvas
          ref={canvasRef}
          width={size}
          height={size}
          className="drop-shadow-2xl cursor-pointer"
          style={{ width: size, height: size }}
        />
        
        {/* Loading indicator */}
        <AnimatePresence>
          {!isLoaded && (
            <motion.div
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/30 to-accent/30 rounded-2xl backdrop-blur-sm"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full"
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Enhanced Hover Glow Effect */}
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          animate={{
            boxShadow: isHovered 
              ? [
                  "0 0 20px rgba(102, 126, 234, 0.4)",
                  "0 0 40px rgba(240, 147, 251, 0.3)",
                  "0 0 60px rgba(79, 172, 254, 0.2)"
                ]
              : "0 0 0px rgba(102, 126, 234, 0)"
          }}
          transition={{ duration: 0.4 }}
        />

        {/* Particle Trail Effect */}
        <AnimatePresence>
          {isHovered && (
            <>
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-1 h-1 bg-primary rounded-full pointer-events-none"
                  initial={{ 
                    opacity: 0,
                    x: size / 2,
                    y: size / 2,
                    scale: 0
                  }}
                  animate={{ 
                    opacity: [0, 1, 0],
                    x: size / 2 + (Math.random() - 0.5) * 60,
                    y: size / 2 + (Math.random() - 0.5) * 60,
                    scale: [0, 1, 0]
                  }}
                  transition={{ 
                    duration: 1,
                    delay: i * 0.1,
                    repeat: Infinity,
                    repeatDelay: 1
                  }}
                />
              ))}
            </>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Ultra-Enhanced Text Logo */}
      {showText && variant !== 'icon' && (
        <motion.div
          className={variant === 'compact' ? "hidden md:block" : "hidden lg:block"}
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <motion.div 
            className={`font-bold ${textSizes[variant]}`}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <motion.span 
              className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent bg-size-200 bg-pos-0"
              animate={{
                backgroundPosition: isHovered ? ['0%', '100%', '0%'] : '0%'
              }}
              transition={{ 
                duration: isHovered ? 2 : 0, 
                ease: "easeInOut",
                repeat: isHovered ? Infinity : 0
              }}
            >
              STUDENT
            </motion.span>
            <motion.span 
              className="text-foreground relative"
              animate={{ 
                textShadow: isHovered 
                  ? "0 0 20px rgba(102, 126, 234, 0.5)"
                  : "0 0 0px rgba(102, 126, 234, 0)"
              }}
              transition={{ duration: 0.3 }}
            >
              HUB
            </motion.span>
            <motion.span
              className="text-accent relative"
              animate={{ 
                opacity: [1, 0.7, 1],
                scale: isHovered ? [1, 1.05, 1] : 1,
                rotate: isHovered ? [0, 2, -2, 0] : 0
              }}
              transition={{ 
                opacity: { duration: 2, repeat: Infinity },
                scale: { duration: 0.4 },
                rotate: { duration: 2, repeat: isHovered ? Infinity : 0 }
              }}
            >
              .COM
            </motion.span>
          </motion.div>
          
          {variant === 'main' || variant === 'hero' && (
            <motion.div 
              className="text-xs text-foreground-secondary font-medium tracking-wide mt-1"
              animate={{ 
                opacity: [0.7, 1, 0.7],
                y: isHovered ? [-1, 1, -1] : 0
              }}
              transition={{ 
                opacity: { duration: 3, repeat: Infinity },
                y: { duration: 2, repeat: Infinity }
              }}
            >
              <motion.span
                animate={{
                  backgroundPosition: ['0%', '100%', '0%']
                }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                className="bg-gradient-to-r from-primary/70 to-accent/70 bg-clip-text text-transparent bg-size-200"
              >
                Advanced Educational Technology Platform
              </motion.span>
            </motion.div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};
import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { MessageSquare, Phone, Mail, Clock, Users, Star, Sparkles, ArrowDown } from 'lucide-react';
import * as THREE from 'three';

export const EnhancedContactHero: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true });
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Real-time clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Mouse tracking for parallax effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Advanced 3D Background Scene
  useEffect(() => {
    if (!canvasRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);

    // Enhanced Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
    scene.add(ambientLight);

    const primaryLight = new THREE.DirectionalLight(0x667eea, 1);
    primaryLight.position.set(5, 5, 5);
    scene.add(primaryLight);

    const accentLight = new THREE.DirectionalLight(0xf093fb, 0.7);
    accentLight.position.set(-5, 3, 2);
    scene.add(accentLight);

    // Floating Communication Elements
    const communicationElements: THREE.Mesh[] = [];
    
    // Email Icons (Cubes)
    for (let i = 0; i < 8; i++) {
      const geometry = new THREE.BoxGeometry(0.3, 0.2, 0.1);
      const material = new THREE.MeshPhongMaterial({ 
        color: 0x4facfe,
        transparent: true,
        opacity: 0.7
      });
      const cube = new THREE.Mesh(geometry, material);
      
      cube.position.set(
        (Math.random() - 0.5) * 20,
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 10
      );
      cube.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );
      
      communicationElements.push(cube);
      scene.add(cube);
    }

    // Phone Icons (Cylinders)
    for (let i = 0; i < 6; i++) {
      const geometry = new THREE.CylinderGeometry(0.08, 0.08, 0.4, 8);
      const material = new THREE.MeshPhongMaterial({ 
        color: 0x00d4ff,
        transparent: true,
        opacity: 0.8
      });
      const cylinder = new THREE.Mesh(geometry, material);
      
      cylinder.position.set(
        (Math.random() - 0.5) * 18,
        (Math.random() - 0.5) * 12,
        (Math.random() - 0.5) * 8
      );
      
      communicationElements.push(cylinder);
      scene.add(cylinder);
    }

    // Chat Bubbles (Spheres)
    for (let i = 0; i < 10; i++) {
      const geometry = new THREE.SphereGeometry(0.2, 16, 16);
      const material = new THREE.MeshPhongMaterial({ 
        color: 0xf093fb,
        transparent: true,
        opacity: 0.6
      });
      const sphere = new THREE.Mesh(geometry, material);
      
      sphere.position.set(
        (Math.random() - 0.5) * 22,
        (Math.random() - 0.5) * 16,
        (Math.random() - 0.5) * 12
      );
      
      communicationElements.push(sphere);
      scene.add(sphere);
    }

    // Connection Lines
    const connections: THREE.Line[] = [];
    for (let i = 0; i < 15; i++) {
      const points = [];
      for (let j = 0; j < 2; j++) {
        points.push(new THREE.Vector3(
          (Math.random() - 0.5) * 25,
          (Math.random() - 0.5) * 18,
          (Math.random() - 0.5) * 15
        ));
      }
      
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const material = new THREE.LineBasicMaterial({ 
        color: 0x667eea,
        transparent: true,
        opacity: 0.3
      });
      const line = new THREE.Line(geometry, material);
      connections.push(line);
      scene.add(line);
    }

    camera.position.z = 15;

    // Animation Loop
    let animationId: number;
    const animate = () => {
      // Rotate and float communication elements
      communicationElements.forEach((element, index) => {
        element.rotation.x += 0.01 + Math.sin(Date.now() * 0.001 + index) * 0.005;
        element.rotation.y += 0.008 + Math.cos(Date.now() * 0.001 + index) * 0.003;
        element.position.y += Math.sin(Date.now() * 0.002 + index) * 0.02;
        
        // Hover glow effect
        if (element.material instanceof THREE.MeshPhongMaterial) {
          element.material.emissiveIntensity = 0.1 + Math.sin(Date.now() * 0.003 + index) * 0.05;
        }
      });

      // Animate connection lines
      connections.forEach((line, index) => {
        line.rotation.z += 0.002;
        if (line.material instanceof THREE.LineBasicMaterial) {
          line.material.opacity = 0.2 + Math.sin(Date.now() * 0.002 + index) * 0.1;
        }
      });

      // Mouse parallax effect
      camera.position.x = mousePosition.x * 2;
      camera.position.y = -mousePosition.y * 1;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      animationId = requestAnimationFrame(animate);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      scene.clear();
      renderer.dispose();
    };
  }, [mousePosition]);

  const stats = [
    { icon: <MessageSquare className="w-6 h-6" />, value: "24/7", label: "Support Available", color: "text-blue-400" },
    { icon: <Clock className="w-6 h-6" />, value: "< 2hrs", label: "Response Time", color: "text-green-400" },
    { icon: <Users className="w-6 h-6" />, value: "50K+", label: "Students Helped", color: "text-purple-400" },
    { icon: <Star className="w-6 h-6" />, value: "4.9★", label: "Satisfaction Rate", color: "text-yellow-400" }
  ];

  return (
    <section ref={containerRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* 3D Background Canvas */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--background-secondary)) 100%)' }}
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, type: "spring", bounce: 0.3 }}
          className="space-y-8"
        >
          {/* Main Heading */}
          <motion.div 
            className="space-y-4"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.h1 
              className="text-5xl md:text-7xl lg:text-8xl font-bold"
              animate={{ 
                backgroundPosition: ['0%', '100%', '0%']
              }}
              transition={{ 
                duration: 8, 
                repeat: Infinity,
                ease: "linear"
              }}
              style={{
                background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)), hsl(var(--accent)))',
                backgroundSize: '400% 400%',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              Contact Us
            </motion.h1>
            
            <motion.div
              className="flex items-center justify-center space-x-2"
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="w-6 h-6 text-accent" />
              <span className="text-xl md:text-2xl text-foreground-secondary font-medium">
                We're Here to Help You Succeed
              </span>
              <Sparkles className="w-6 h-6 text-accent" />
            </motion.div>
          </motion.div>

          {/* Description */}
          <motion.p 
            className="text-lg md:text-xl lg:text-2xl text-foreground-secondary max-w-4xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Get instant help with your academic needs. Our expert team is available 24/7 to assist you with 
            question papers, study materials, and any academic queries you might have.
          </motion.p>

          {/* Live Clock */}
          <motion.div
            className="inline-flex items-center space-x-3 bg-white/10 backdrop-blur-sm rounded-full px-6 py-3 border border-white/20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Clock className="w-5 h-5 text-accent" />
            <span className="text-foreground font-medium">
              India Time: {currentTime.toLocaleString('en-IN', { 
                timeZone: 'Asia/Kolkata',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
              })}
            </span>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </motion.div>

          {/* Stats Grid */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
                whileHover={{ scale: 1.05, y: -5 }}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 * index }}
              >
                <motion.div 
                  className={`${stat.color} mb-3 flex justify-center`}
                  animate={{ rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                >
                  {stat.icon}
                </motion.div>
                <motion.div 
                  className="text-2xl md:text-3xl font-bold text-foreground mb-1"
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.1 }}
                >
                  {stat.value}
                </motion.div>
                <div className="text-sm text-foreground-secondary font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            className="pt-12"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 1.2 }}
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="flex flex-col items-center space-y-2 text-foreground-secondary"
            >
              <span className="text-sm font-medium">Explore Contact Options</span>
              <ArrowDown className="w-5 h-5" />
            </motion.div>
          </motion.div>
        </motion.div>
      </div>

      {/* Floating Action Elements */}
      <AnimatePresence>
        {isInView && (
          <>
            {/* Floating Email */}
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 1, delay: 1.5 }}
              className="absolute left-8 top-1/2 transform -translate-y-1/2 hidden lg:block"
            >
              <motion.div
                animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="p-4 bg-blue-500/20 backdrop-blur-sm rounded-2xl border border-blue-500/30"
              >
                <Mail className="w-8 h-8 text-blue-400" />
              </motion.div>
            </motion.div>

            {/* Floating Phone */}
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 100 }}
              transition={{ duration: 1, delay: 1.7 }}
              className="absolute right-8 top-1/3 hidden lg:block"
            >
              <motion.div
                animate={{ y: [0, 15, 0], rotate: [0, -5, 0] }}
                transition={{ duration: 3.5, repeat: Infinity }}
                className="p-4 bg-green-500/20 backdrop-blur-sm rounded-2xl border border-green-500/30"
              >
                <Phone className="w-8 h-8 text-green-400" />
              </motion.div>
            </motion.div>

            {/* Floating Chat */}
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              transition={{ duration: 1, delay: 1.9 }}
              className="absolute left-1/4 bottom-20 hidden lg:block"
            >
              <motion.div
                animate={{ y: [0, -10, 0], scale: [1, 1.1, 1] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="p-4 bg-purple-500/20 backdrop-blur-sm rounded-2xl border border-purple-500/30"
              >
                <MessageSquare className="w-8 h-8 text-purple-400" />
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </section>
  );
};
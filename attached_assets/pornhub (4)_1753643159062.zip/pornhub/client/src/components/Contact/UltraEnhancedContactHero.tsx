import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  MessageCircle, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Users, 
  Zap, 
  Globe,
  Shield,
  Award,
  TrendingUp,
  Star,
  Heart,
  Sparkles,
  Target,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import * as THREE from 'three';

export const UltraEnhancedContactHero: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [responseTime, setResponseTime] = useState('< 2 mins');
  const [activeUsers, setActiveUsers] = useState(1247);
  const [isHovered, setIsHovered] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true });
  const frameRef = useRef<number | null>(null);

  // Real-time clock
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Dynamic stats
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUsers(prev => prev + Math.floor(Math.random() * 3) + 1);
      const times = ['< 30 secs', '< 1 min', '< 2 mins', '< 5 mins'];
      setResponseTime(times[Math.floor(Math.random() * times.length)]);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Ultra-Advanced 3D Scene
  useEffect(() => {
    if (!canvasRef.current || !isInView) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Enhanced Lighting System
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);

    const primaryLight = new THREE.DirectionalLight(0x667eea, 2.0);
    primaryLight.position.set(8, 8, 8);
    scene.add(primaryLight);

    const accentLight = new THREE.DirectionalLight(0xf093fb, 1.5);
    accentLight.position.set(-6, 4, 3);
    scene.add(accentLight);

    const backLight = new THREE.DirectionalLight(0x4facfe, 1.2);
    backLight.position.set(0, -6, -4);
    scene.add(backLight);

    // Communication Hub - Central Element
    const hubGeometry = new THREE.IcosahedronGeometry(1.2, 2);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.9,
      emissive: 0x667eea,
      emissiveIntensity: 0.2,
      shininess: 100
    });
    const communicationHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(communicationHub);

    // Floating Communication Icons
    const iconElements: THREE.Mesh[] = [];
    const iconPositions = [
      { x: 3, y: 2, z: 1, color: 0x00d4ff }, // Phone
      { x: -3, y: 2, z: 1, color: 0xf093fb }, // Email
      { x: 3, y: -2, z: 1, color: 0x4facfe }, // Message
      { x: -3, y: -2, z: 1, color: 0xff6b6b }, // Location
      { x: 0, y: 3, z: 2, color: 0x00ff88 }, // Clock
      { x: 0, y: -3, z: 2, color: 0xffaa00 } // Users
    ];

    iconPositions.forEach((pos, index) => {
      const iconGeometry = new THREE.SphereGeometry(0.3, 16, 16);
      const iconMaterial = new THREE.MeshPhongMaterial({
        color: pos.color,
        transparent: true,
        opacity: 0.8,
        emissive: pos.color,
        emissiveIntensity: 0.3
      });
      
      const iconElement = new THREE.Mesh(iconGeometry, iconMaterial);
      iconElement.position.set(pos.x, pos.y, pos.z);
      iconElement.userData = {
        originalPosition: { x: pos.x, y: pos.y, z: pos.z },
        rotationSpeed: {
          x: (Math.random() - 0.5) * 0.03,
          y: (Math.random() - 0.5) * 0.03,
          z: (Math.random() - 0.5) * 0.03
        },
        bobSpeed: 0.02 + Math.random() * 0.02,
        bobAmplitude: 0.3 + Math.random() * 0.4
      };
      
      iconElements.push(iconElement);
      scene.add(iconElement);
    });

    camera.position.z = 8;

    // Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Central Hub Animation
      communicationHub.rotation.x += 0.01;
      communicationHub.rotation.y += 0.015;
      communicationHub.rotation.z += 0.008;
      
      if (isHovered) {
        communicationHub.scale.setScalar(1.2);
        const material = communicationHub.material as THREE.MeshPhongMaterial;
        material.emissiveIntensity = 0.4;
      } else {
        communicationHub.scale.setScalar(1);
        const material = communicationHub.material as THREE.MeshPhongMaterial;
        material.emissiveIntensity = 0.2;
      }

      // Icon Elements Animation
      iconElements.forEach((icon, index) => {
        const userData = icon.userData;
        
        icon.rotation.x += userData.rotationSpeed.x;
        icon.rotation.y += userData.rotationSpeed.y;
        icon.rotation.z += userData.rotationSpeed.z;
        
        // Orbital motion around center
        const angle = time * 0.3 + index * Math.PI * 2 / iconElements.length;
        const radius = 4 + Math.sin(time * 0.5 + index) * 0.5;
        
        icon.position.x = Math.cos(angle) * radius;
        icon.position.z = Math.sin(angle) * radius;
        icon.position.y = userData.originalPosition.y + Math.sin(time * userData.bobSpeed + index) * userData.bobAmplitude;
      });

      // Camera Movement
      camera.position.x = Math.sin(time * 0.2) * 1;
      camera.position.y = Math.cos(time * 0.15) * 0.5;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [isInView, isHovered]);

  const quickStats = [
    { label: "Response Time", value: responseTime, icon: <Zap className="w-5 h-5" />, color: "text-green-400" },
    { label: "Active Users", value: activeUsers.toLocaleString(), icon: <Users className="w-5 h-5" />, color: "text-blue-400" },
    { label: "Success Rate", value: "99.8%", icon: <Target className="w-5 h-5" />, color: "text-purple-400" },
    { label: "Support Score", value: "4.9★", icon: <Star className="w-5 h-5" />, color: "text-yellow-400" }
  ];

  const contactMethods = [
    {
      icon: <Mail className="w-6 h-6" />,
      title: "Email Support",
      description: "Get detailed responses to complex queries",
      value: "support@studenthub.com",
      color: "from-blue-500 to-blue-600",
      available: "24/7"
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Live Chat",
      description: "Instant help for quick questions",
      value: "Chat Now",
      color: "from-green-500 to-green-600",
      available: "Online"
    },
    {
      icon: <Phone className="w-6 h-6" />,
      title: "Phone Support",
      description: "Direct line for urgent matters",
      value: "+91-XXXX-XXXXXX",
      color: "from-purple-500 to-purple-600",
      available: "9 AM - 9 PM"
    }
  ];

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-background-secondary to-background"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 3D Canvas Background */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-40"
      />

      {/* Dynamic Background Layers */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            'radial-gradient(circle at 30% 40%, rgba(102, 126, 234, 0.15) 0%, transparent 70%)',
            'radial-gradient(circle at 70% 60%, rgba(240, 147, 251, 0.15) 0%, transparent 70%)',
            'radial-gradient(circle at 50% 30%, rgba(79, 172, 254, 0.15) 0%, transparent 70%)',
            'radial-gradient(circle at 30% 40%, rgba(102, 126, 234, 0.15) 0%, transparent 70%)'
          ]
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="text-center space-y-16">
          {/* Enhanced Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Status Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="flex justify-center"
            >
              <Badge 
                variant="outline" 
                className="px-8 py-3 text-base bg-gradient-to-r from-green-500/20 to-green-600/20 border-green-500/40 backdrop-blur-sm"
              >
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="mr-3"
                >
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                </motion.div>
                Live Support Available - IST {currentTime.toLocaleTimeString('en-IN')}
              </Badge>
            </motion.div>

            {/* Main Headline */}
            <motion.h1 
              className="text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold leading-tight"
              animate={{
                backgroundPosition: ['0%', '100%', '0%']
              }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              style={{
                background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)), hsl(var(--foreground)))',
                backgroundSize: '400% 400%',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              <motion.span
                animate={{ 
                  y: [0, -15, 0],
                  rotateX: [0, 5, 0]
                }}
                transition={{ duration: 3, repeat: Infinity, delay: 0 }}
              >
                GET IN
              </motion.span>
              <motion.span
                className="block"
                animate={{ 
                  y: [0, 15, 0],
                  rotateX: [0, -5, 0]
                }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
              >
                TOUCH
              </motion.span>
            </motion.h1>
          </motion.div>

          {/* Quick Stats Grid */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.6 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto"
          >
            {quickStats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.8, delay: 0.1 * index }}
                whileHover={{ 
                  scale: 1.05,
                  y: -5,
                  transition: { duration: 0.3 }
                }}
                className="group relative"
              >
                <div className="
                  relative p-6 rounded-2xl backdrop-blur-sm
                  bg-gradient-to-br from-white/10 to-white/5
                  border border-white/20 hover:border-white/40
                  shadow-xl hover:shadow-2xl
                  transform-gpu transition-all duration-500
                  overflow-hidden
                ">
                  <div className="relative z-10 text-center space-y-3">
                    <motion.div
                      className={`mx-auto w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center ${stat.color} border border-current/30`}
                      animate={{ 
                        rotate: [0, 10, -10, 0],
                        scale: [1, 1.1, 1]
                      }}
                      transition={{ 
                        rotate: { duration: 4, repeat: Infinity },
                        scale: { duration: 2, repeat: Infinity, delay: index * 0.3 }
                      }}
                    >
                      {stat.icon}
                    </motion.div>
                    
                    <div>
                      <motion.div 
                        className="text-2xl font-bold text-foreground"
                        animate={{ scale: [1, 1.05, 1] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.5 }}
                      >
                        {stat.value}
                      </motion.div>
                      <div className="text-sm text-foreground-secondary font-medium">
                        {stat.label}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Enhanced Contact Methods */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.8 }}
            className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          >
            {contactMethods.map((method, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50, rotateY: -15 }}
                animate={isInView ? { opacity: 1, y: 0, rotateY: 0 } : {}}
                transition={{ 
                  duration: 0.8, 
                  delay: 0.2 * index,
                  type: "spring",
                  bounce: 0.3
                }}
                whileHover={{ 
                  y: -15,
                  rotateY: 5,
                  scale: 1.02,
                  transition: { duration: 0.4 }
                }}
                className="group relative cursor-pointer"
              >
                <div className="
                  relative p-8 rounded-3xl backdrop-blur-sm
                  bg-gradient-to-br from-white/10 to-white/5
                  border border-white/20 hover:border-white/40
                  shadow-2xl hover:shadow-3xl
                  transform-gpu transition-all duration-700
                  overflow-hidden
                ">
                  <div className="relative z-10 space-y-6">
                    <div className="flex items-center justify-between">
                      <motion.div
                        className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${method.color} flex items-center justify-center text-white shadow-xl`}
                        whileHover={{ 
                          rotate: [0, 15, -15, 0],
                          scale: 1.1
                        }}
                        transition={{ duration: 0.8 }}
                      >
                        {method.icon}
                      </motion.div>

                      <Badge 
                        variant="outline" 
                        className={`border-current text-xs bg-gradient-to-r ${method.color} bg-opacity-20`}
                      >
                        {method.available}
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <motion.h3 
                        className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors duration-300"
                        animate={{ x: [0, 8, 0] }}
                        transition={{ duration: 3, repeat: Infinity, delay: index * 0.5 }}
                      >
                        {method.title}
                      </motion.h3>
                      
                      <p className="text-foreground-secondary group-hover:text-foreground transition-colors duration-300">
                        {method.description}
                      </p>

                      <motion.div
                        className="text-primary font-semibold text-lg"
                        animate={{ scale: [1, 1.02, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        {method.value}
                      </motion.div>
                    </div>

                    <motion.div
                      className="flex items-center text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      animate={{ x: [0, 10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <span className="text-sm font-medium mr-2">Connect Now</span>
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 1.2 }}
            className="flex flex-wrap justify-center items-center gap-8 pt-8"
          >
            {[
              { icon: <Shield className="w-5 h-5" />, text: "Secure Communication", color: "text-green-400" },
              { icon: <Award className="w-5 h-5" />, text: "Expert Support Team", color: "text-blue-400" },
              { icon: <CheckCircle className="w-5 h-5" />, text: "Verified Responses", color: "text-purple-400" },
              { icon: <Heart className="w-5 h-5" />, text: "Student-Focused", color: "text-red-400" }
            ].map((indicator, index) => (
              <motion.div
                key={index}
                className="flex items-center space-x-3 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20"
                whileHover={{ scale: 1.05, backgroundColor: 'rgba(255,255,255,0.15)' }}
                animate={{ y: [0, -5, 0] }}
                transition={{ 
                  y: { duration: 3, repeat: Infinity, delay: index * 0.5 },
                  hover: { duration: 0.3 }
                }}
              >
                <span className={indicator.color}>{indicator.icon}</span>
                <span className="text-foreground font-medium">{indicator.text}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
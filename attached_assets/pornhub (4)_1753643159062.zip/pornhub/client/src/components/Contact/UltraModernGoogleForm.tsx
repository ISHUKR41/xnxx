import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { ExternalLink, BookOpen, FileText, Sparkles, Target, Clock, Users, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface UltraModernGoogleFormProps {
  title: string;
  description: string;
  formUrl: string;
  icon: React.ReactNode;
  color?: string;
  gradient?: string;
}

export const UltraModernGoogleForm: React.FC<UltraModernGoogleFormProps> = ({
  title,
  description,
  formUrl,
  icon,
  color = 'text-blue-500',
  gradient = 'from-blue-500/20 to-purple-500/20'
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(cardRef, { once: true });
  const particlesRef = useRef<HTMLDivElement>(null);

  // 3D Floating Particles Animation
  useEffect(() => {
    if (!particlesRef.current) return;

    const particles = Array.from({ length: 15 }, (_, i) => {
      const particle = document.createElement('div');
      particle.className = `absolute w-1 h-1 bg-gradient-to-r ${gradient.replace('/', '')} rounded-full`;
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      particle.style.animationDelay = `${Math.random() * 3}s`;
      particle.style.animation = `float ${3 + Math.random() * 2}s ease-in-out infinite alternate`;
      particlesRef.current?.appendChild(particle);
      return particle;
    });

    return () => {
      particles.forEach(particle => particle.remove());
    };
  }, [gradient]);

  const features = [
    { icon: <Target className="w-4 h-4" />, text: "Quick Response" },
    { icon: <Clock className="w-4 h-4" />, text: "24hr Processing" },
    { icon: <Users className="w-4 h-4" />, text: "Expert Support" },
    { icon: <Star className="w-4 h-4" />, text: "Premium Quality" }
  ];

  const handleFormClick = () => {
    setIsClicked(true);
    setTimeout(() => setIsClicked(false), 200);
    window.open(formUrl, '_blank', 'width=800,height=900,scrollbars=yes,resizable=yes');
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, rotateY: -15 }}
      animate={isInView ? { 
        opacity: 1, 
        y: 0, 
        rotateY: 0,
        scale: isClicked ? 0.95 : 1
      } : {}}
      transition={{ 
        duration: 0.8, 
        type: "spring",
        bounce: 0.3
      }}
      whileHover={{ 
        y: -10,
        rotateY: 5,
        scale: 1.02,
        transition: { duration: 0.3 }
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="relative group perspective-1000"
    >
      <Card className={`
        relative overflow-hidden border-2 border-transparent 
        bg-gradient-to-br ${gradient} backdrop-blur-sm
        hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/20
        transform-gpu will-change-transform
        transition-all duration-500 ease-out
        ${isHovered ? 'shadow-glow' : ''}
      `}>
        {/* Floating Particles Background */}
        <div 
          ref={particlesRef}
          className="absolute inset-0 overflow-hidden opacity-30"
        />

        {/* Animated Border Glow */}
        <motion.div
          className="absolute inset-0 rounded-lg"
          animate={{
            background: isHovered 
              ? `conic-gradient(from 0deg, transparent, ${color.replace('text-', '')}, transparent)`
              : 'transparent'
          }}
          transition={{ duration: 0.5 }}
        />

        {/* Main Content */}
        <CardContent className="relative z-10 p-8 space-y-6">
          {/* Header with Icon */}
          <motion.div 
            className="flex items-center space-x-4"
            animate={{ scale: isHovered ? 1.05 : 1 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className={`
                p-4 rounded-2xl bg-gradient-to-br ${gradient} 
                border border-white/20 backdrop-blur-sm
                ${color} shadow-lg
              `}
              animate={{
                rotate: isHovered ? [0, 5, -5, 0] : 0,
                scale: isHovered ? 1.1 : 1
              }}
              transition={{ duration: 0.5 }}
            >
              {icon}
            </motion.div>
            
            <div className="space-y-1">
              <motion.h3 
                className="text-xl font-bold text-foreground"
                animate={{ x: isHovered ? 5 : 0 }}
                transition={{ duration: 0.3 }}
              >
                {title}
              </motion.h3>
              <Badge variant="secondary" className="text-xs">
                <Sparkles className="w-3 h-3 mr-1" />
                Enhanced Form
              </Badge>
            </div>
          </motion.div>

          {/* Description */}
          <motion.p 
            className="text-foreground-secondary leading-relaxed"
            animate={{ opacity: isHovered ? 1 : 0.8 }}
            transition={{ duration: 0.3 }}
          >
            {description}
          </motion.p>

          {/* Features Grid */}
          <motion.div 
            className="grid grid-cols-2 gap-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: isInView ? 1 : 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="flex items-center space-x-2 p-2 rounded-lg bg-white/5 backdrop-blur-sm"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: isInView ? 1 : 0, x: isInView ? 0 : -20 }}
                transition={{ delay: 0.1 * index, duration: 0.4 }}
                whileHover={{ scale: 1.05 }}
              >
                <span className={color}>{feature.icon}</span>
                <span className="text-sm text-foreground-secondary">{feature.text}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* Action Button with 3D Effect */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleFormClick}
              className={`
                w-full group relative overflow-hidden
                bg-gradient-to-r from-primary to-accent
                hover:from-primary/90 hover:to-accent/90
                text-white font-semibold py-4 px-6 rounded-xl
                shadow-lg hover:shadow-xl hover:shadow-primary/30
                transform-gpu transition-all duration-300
                border border-white/20
              `}
            >
              {/* Button Background Animation */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0"
                initial={{ x: '-100%' }}
                animate={{ x: isHovered ? '100%' : '-100%' }}
                transition={{ duration: 0.6, ease: "easeInOut" }}
              />
              
              <span className="relative z-10 flex items-center justify-center space-x-2">
                <span>Open Request Form</span>
                <motion.div
                  animate={{ x: isHovered ? 5 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ExternalLink className="w-5 h-5" />
                </motion.div>
              </span>
            </Button>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div 
            className="flex items-center justify-center space-x-4 text-xs text-foreground-secondary"
            initial={{ opacity: 0 }}
            animate={{ opacity: isInView ? 1 : 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Secure</span>
            </div>
            <div className="w-px h-4 bg-border"></div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              <span>Fast Response</span>
            </div>
            <div className="w-px h-4 bg-border"></div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
              <span>Free Service</span>
            </div>
          </motion.div>
        </CardContent>

        {/* Hover Overlay Effect */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none"
            />
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
};
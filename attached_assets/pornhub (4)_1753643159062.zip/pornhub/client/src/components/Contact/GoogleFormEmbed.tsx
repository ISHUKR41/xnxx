import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, X, Maximize2, BookOpen, FileText, Sparkles, Zap, Shield, Clock, CheckCircle, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import * as THREE from 'three';

interface GoogleFormEmbedProps {
  title: string;
  description: string;
  formUrl: string;
  icon: React.ReactNode;
}

export const GoogleFormEmbed: React.FC<GoogleFormEmbedProps> = ({
  title,
  description,
  formUrl,
  icon
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationIdRef = useRef<number | null>(null);

  const handleOpenForm = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsExpanded(true);
    }, 800);
  };

  const embedUrl = formUrl.replace('/viewform', '/viewform?embedded=true');

  // Ultra-modern 3D background animation
  useEffect(() => {
    if (!canvasRef.current || !isHovered) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: false,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(400, 300);
    renderer.setClearColor(0x000000, 0);

    // Create floating form elements
    const elements: THREE.Mesh[] = [];
    const geometries = [
      new THREE.BoxGeometry(0.1, 0.05, 0.02), // Input field
      new THREE.SphereGeometry(0.03, 8, 8), // Button
      new THREE.CylinderGeometry(0.02, 0.02, 0.08, 6), // Icon
    ];

    for (let i = 0; i < 25; i++) {
      const geometry = geometries[i % geometries.length];
      const material = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL(i / 25, 0.7, 0.6),
        transparent: true,
        opacity: 0.7
      });
      
      const element = new THREE.Mesh(geometry, material);
      element.position.set(
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 4
      );
      
      scene.add(element);
      elements.push(element);
    }

    camera.position.z = 5;

    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      elements.forEach((element, index) => {
        element.rotation.x += 0.01;
        element.rotation.y += 0.015;
        element.position.y += Math.sin(Date.now() * 0.001 + index) * 0.002;
      });
      
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      renderer.dispose();
    };
  }, [isHovered]);

  const features = [
    { icon: <Zap className="w-4 h-4" />, text: "Instant Response", color: "text-yellow-500" },
    { icon: <Shield className="w-4 h-4" />, text: "100% Secure", color: "text-green-500" },
    { icon: <Clock className="w-4 h-4" />, text: "24hr Delivery", color: "text-blue-500" },
    { icon: <CheckCircle className="w-4 h-4" />, text: "Verified Content", color: "text-purple-500" },
    { icon: <Star className="w-4 h-4" />, text: "Premium Quality", color: "text-orange-500" },
    { icon: <Sparkles className="w-4 h-4" />, text: "AI Enhanced", color: "text-pink-500" }
  ];

  return (
    <>
      {/* Ultra-Modern Form Card */}
      <motion.div
        initial={{ opacity: 0, y: 30, rotateX: -15 }}
        animate={{ opacity: 1, y: 0, rotateX: 0 }}
        transition={{ duration: 0.8, type: "spring", stiffness: 100 }}
        whileHover={{ 
          scale: 1.03, 
          rotateY: 2,
          rotateX: 2,
          transition: { duration: 0.3 }
        }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        className="group perspective-1000"
      >
        <Card className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent/10 to-secondary/10 border-2 border-transparent hover:border-primary/40 transition-all duration-700 backdrop-blur-sm">
          {/* Ultra-modern animated background */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 via-pink-500/20 to-cyan-500/20 animate-gradient-x opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
          
          {/* 3D Canvas Background */}
          {isHovered && (
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full opacity-30"
              width={400}
              height={300}
            />
          )}
          
          {/* Enhanced floating particles */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                className={`absolute rounded-full ${
                  i % 3 === 0 ? 'w-2 h-2 bg-blue-400/40' :
                  i % 3 === 1 ? 'w-1.5 h-1.5 bg-purple-400/40' :
                  'w-1 h-1 bg-pink-400/40'
                }`}
                animate={{
                  x: [0, Math.random() * 150 - 75, 0],
                  y: [0, Math.random() * 150 - 75, 0],
                  opacity: [0, 1, 0],
                  scale: [0, 1.5, 0]
                }}
                transition={{
                  duration: 4 + Math.random() * 3,
                  repeat: Infinity,
                  delay: Math.random() * 3,
                  ease: "easeInOut"
                }}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`
                }}
              />
            ))}
          </div>

          {/* Holographic grid overlay */}
          <div className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity duration-500">
            <div className="w-full h-full" style={{
              backgroundImage: `
                linear-gradient(rgba(102, 126, 234, 0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(102, 126, 234, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px'
            }} />
          </div>

          <CardContent className="relative p-10 space-y-8 z-10">
            {/* Ultra-Modern Header */}
            <div className="flex items-start space-x-6">
              <motion.div
                whileHover={{ 
                  rotate: 360, 
                  scale: 1.2,
                  rotateY: 180
                }}
                transition={{ duration: 0.8, type: "spring" }}
                className="relative p-4 rounded-2xl bg-gradient-to-br from-primary via-accent to-secondary text-white shadow-2xl group"
              >
                <div className="relative z-10">
                  {icon}
                </div>
                {/* Icon glow effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </motion.div>
              <div className="flex-1">
                <motion.h3 
                  className="text-3xl font-bold bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent group-hover:from-primary group-hover:to-secondary transition-all duration-500"
                  whileHover={{ scale: 1.02 }}
                >
                  {title}
                </motion.h3>
                <motion.p 
                  className="text-foreground-secondary mt-2 text-lg leading-relaxed"
                  initial={{ opacity: 0.8 }}
                  whileHover={{ opacity: 1 }}
                >
                  {description}
                </motion.p>
              </div>
            </div>

            {/* Enhanced Features Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.text}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, x: 5 }}
                  className="flex items-center space-x-3 p-3 rounded-xl bg-gradient-to-r from-white/5 to-white/10 hover:from-white/10 hover:to-white/20 transition-all duration-300 group cursor-pointer"
                >
                  <motion.div 
                    className={`${feature.color} group-hover:scale-125 transition-transform duration-300`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.5 }}
                  >
                    {feature.icon}
                  </motion.div>
                  <span className="text-sm font-medium text-foreground-secondary group-hover:text-foreground transition-colors">
                    {feature.text}
                  </span>
                </motion.div>
              ))}
            </div>

            {/* Trust indicators */}
            <div className="flex items-center justify-center space-x-8 py-4">
              <motion.div 
                className="flex items-center space-x-2 text-sm text-foreground-secondary"
                whileHover={{ scale: 1.1, color: "#10B981" }}
              >
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <span>50k+ Students Trust Us</span>
              </motion.div>
              <motion.div 
                className="flex items-center space-x-2 text-sm text-foreground-secondary"
                whileHover={{ scale: 1.1, color: "#3B82F6" }}
              >
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
                <span>99.9% Success Rate</span>
              </motion.div>
            </div>

            {/* Enhanced Action Buttons */}
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <motion.div 
                className="flex-1"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={handleOpenForm}
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-primary via-accent to-secondary hover:from-primary/90 hover:via-accent/90 hover:to-secondary/90 text-white font-semibold py-4 px-8 rounded-2xl shadow-2xl hover:shadow-primary/25 transition-all duration-500 relative overflow-hidden group"
                >
                  {/* Button shine effect */}
                  <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12" />
                  
                  {isLoading ? (
                    <motion.div className="flex items-center justify-center space-x-3">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-6 h-6 border-3 border-white border-t-transparent rounded-full"
                      />
                      <span>Opening...</span>
                    </motion.div>
                  ) : (
                    <div className="flex items-center justify-center space-x-3">
                      <Maximize2 className="w-6 h-6" />
                      <span>Open Request Form</span>
                    </div>
                  )}
                </Button>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="outline"
                  onClick={() => window.open(formUrl, '_blank')}
                  className="px-8 py-4 rounded-2xl border-2 border-primary/30 hover:border-primary hover:bg-primary/10 hover:text-primary transition-all duration-500 relative overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <ExternalLink className="w-6 h-6 relative z-10" />
                </Button>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Expanded Form Modal */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setIsExpanded(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="bg-background rounded-2xl shadow-2xl max-w-4xl w-full h-[80vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-primary/10 to-accent/10">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-primary/20">
                    {icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{title}</h3>
                    <p className="text-sm text-foreground-secondary">{description}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(false)}
                  className="hover:bg-destructive hover:text-destructive-foreground rounded-full"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Embedded Form */}
              <div className="h-full">
                <iframe
                  src={embedUrl}
                  className="w-full h-full border-0"
                  title={title}
                  loading="lazy"
                >
                  Loading form...
                </iframe>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
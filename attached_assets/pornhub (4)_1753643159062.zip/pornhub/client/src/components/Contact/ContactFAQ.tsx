import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle, Zap, Clock, Shield, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export const ContactFAQ: React.FC = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);

  const faqs = [
    {
      question: "How quickly will I get my requested materials?",
      answer: "Most requests are fulfilled within 24 hours! For urgent needs, we prioritize and often deliver within 2-4 hours. Our team works round the clock to ensure you get the materials when you need them.",
      icon: <Clock className="w-5 h-5" />,
      color: "text-blue-500"
    },
    {
      question: "What types of study materials can I request?",
      answer: "We provide question papers, textbooks, notes, reference materials, practical files, project reports, and research papers for all subjects from Class 9 to PhD level including competitive exam materials.",
      icon: <HelpCircle className="w-5 h-5" />,
      color: "text-green-500"
    },
    {
      question: "Is my personal information secure?",
      answer: "Absolutely! We use enterprise-grade security measures to protect your data. Your contact details are only used to fulfill your requests and provide support. We never share your information with third parties.",
      icon: <Shield className="w-5 h-5" />,
      color: "text-purple-500"
    },
    {
      question: "Can I request materials for competitive exams?",
      answer: "Yes! We have extensive collections for JEE, NEET, UPSC, SSC, GATE, CAT, CLAT, and many other competitive exams. Just specify the exam and year in your request form.",
      icon: <Zap className="w-5 h-5" />,
      color: "text-orange-500"
    },
    {
      question: "Do you provide materials for all universities?",
      answer: "We cover materials for 500+ universities and boards including CBSE, ICSE, state boards, IITs, NITs, central universities, and private institutions across India.",
      icon: <Users className="w-5 h-5" />,
      color: "text-pink-500"
    },
    {
      question: "What if you don't have the material I need?",
      answer: "If we don't have it immediately, we'll actively search for it! Our network includes students and faculty from various institutions. We'll update you within 48 hours about availability.",
      icon: <HelpCircle className="w-5 h-5" />,
      color: "text-indigo-500"
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Frequently Asked Questions
            </span>
          </h2>
          <p className="text-xl text-foreground-secondary max-w-2xl mx-auto">
            Get instant answers to common questions about our services and support
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group"
            >
              <Card className="overflow-hidden border-2 border-transparent hover:border-primary/20 transition-all duration-300">
                <CardContent className="p-0">
                  <motion.button
                    onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
                    className="w-full p-6 text-left flex items-center justify-between hover:bg-primary/5 transition-colors duration-300 group"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <div className="flex items-center space-x-4">
                      <motion.div
                        whileHover={{ rotate: 360, scale: 1.1 }}
                        transition={{ duration: 0.5 }}
                        className={`p-2 rounded-lg ${faq.color} bg-current/10`}
                      >
                        {faq.icon}
                      </motion.div>
                      <span className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                        {faq.question}
                      </span>
                    </div>
                    
                    <motion.div
                      animate={{ rotate: openFAQ === index ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                      className={`${faq.color} group-hover:scale-110 transition-transform`}
                    >
                      <ChevronDown className="w-5 h-5" />
                    </motion.div>
                  </motion.button>

                  <AnimatePresence>
                    {openFAQ === index && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <motion.div
                          initial={{ y: -10, opacity: 0 }}
                          animate={{ y: 0, opacity: 1 }}
                          exit={{ y: -10, opacity: 0 }}
                          transition={{ duration: 0.3, delay: 0.1 }}
                          className="px-6 pb-6 pl-16"
                        >
                          <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-xl p-4 border-l-4 border-primary">
                            <p className="text-foreground-secondary leading-relaxed">
                              {faq.answer}
                            </p>
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Still have questions section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-16"
        >
          <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20">
            <CardContent className="p-8">
              <div className="space-y-4">
                <div className="flex justify-center">
                  <motion.div
                    animate={{ 
                      rotate: [0, 10, -10, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      repeatType: "reverse"
                    }}
                    className="p-4 rounded-full bg-gradient-to-br from-primary to-accent text-white"
                  >
                    <HelpCircle className="w-8 h-8" />
                  </motion.div>
                </div>
                <h3 className="text-2xl font-bold text-foreground">
                  Still have questions?
                </h3>
                <p className="text-foreground-secondary">
                  Can't find the answer you're looking for? Our support team is ready to help you personally.
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};
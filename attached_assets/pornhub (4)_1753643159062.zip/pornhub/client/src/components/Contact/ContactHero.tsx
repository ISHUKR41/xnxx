import React, { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { MessageCircle, Sparkles, ArrowDown, Send, Zap, Shield, Clock, Star } from 'lucide-react';
import * as THREE from 'three';

export const ContactHero: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true });
  const animationIdRef = useRef<number | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Ultra-modern 3D particle background
  useEffect(() => {
    if (!canvasRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: false,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(window.innerWidth, 800);
    renderer.setClearColor(0x000000, 0);

    // Create floating communication elements
    const communicationElements: THREE.Mesh[] = [];
    const geometries = [
      new THREE.SphereGeometry(0.03, 8, 8),
      new THREE.BoxGeometry(0.06, 0.06, 0.06),
      new THREE.TetrahedronGeometry(0.04),
      new THREE.ConeGeometry(0.03, 0.08, 6),
      new THREE.TorusGeometry(0.03, 0.01, 6, 12),
    ];

    for (let i = 0; i < 60; i++) {
      const geometry = geometries[i % geometries.length];
      const material = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL((i / 60), 0.9, 0.7),
        transparent: true,
        opacity: 0.8
      });
      
      const element = new THREE.Mesh(geometry, material);
      element.position.set(
        (Math.random() - 0.5) * 20,
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 10
      );
      
      scene.add(element);
      communicationElements.push(element);
    }

    // Create connection network
    const networkGeometry = new THREE.BufferGeometry();
    const networkPositions = [];
    for (let i = 0; i < 100; i++) {
      networkPositions.push((Math.random() - 0.5) * 25);
      networkPositions.push((Math.random() - 0.5) * 20);
      networkPositions.push((Math.random() - 0.5) * 15);
    }
    networkGeometry.setAttribute('position', new THREE.Float32BufferAttribute(networkPositions, 3));
    const networkMaterial = new THREE.LineBasicMaterial({ 
      color: 0x667eea,
      transparent: true,
      opacity: 0.3
    });
    const communicationNetwork = new THREE.Line(networkGeometry, networkMaterial);
    scene.add(communicationNetwork);

    camera.position.z = 10;

    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      const time = Date.now() * 0.001;
      
      communicationElements.forEach((element, index) => {
        element.rotation.x += 0.008;
        element.rotation.y += 0.012;
        element.rotation.z += 0.004;
        element.position.y += Math.sin(time + index * 0.3) * 0.003;
        element.position.x += Math.cos(time * 0.7 + index) * 0.002;
      });
      
      communicationNetwork.rotation.y += 0.003;
      communicationNetwork.rotation.x += 0.001;
      
      // Mouse interaction
      camera.position.x = mousePosition.x * 0.0005;
      camera.position.y = -mousePosition.y * 0.0005;
      
      renderer.render(scene, camera);
    };

    animate();

    const handleMouseMove = (event: MouseEvent) => {
      setMousePosition({
        x: event.clientX - window.innerWidth / 2,
        y: event.clientY - window.innerHeight / 2
      });
    };

    const handleResize = () => {
      camera.aspect = window.innerWidth / 800;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, 800);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [mousePosition.x, mousePosition.y]);

  const scrollToForm = () => {
    const formElement = document.getElementById('contact-form');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const heroFeatures = [
    { icon: <Zap className="w-5 h-5" />, text: "Lightning Fast", color: "text-yellow-400" },
    { icon: <Shield className="w-5 h-5" />, text: "100% Secure", color: "text-green-400" },
    { icon: <Clock className="w-5 h-5" />, text: "24/7 Support", color: "text-blue-400" },
    { icon: <Star className="w-5 h-5" />, text: "5-Star Rated", color: "text-purple-400" }
  ];

  return (
    <motion.section 
      ref={containerRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5"
      initial={{ opacity: 0 }}
      animate={isInView ? { opacity: 1 } : {}}
      transition={{ duration: 1 }}
    >
      {/* Ultra-Modern 3D Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-40"
        style={{ height: '800px' }}
      />

      {/* Animated mesh background */}
      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full" style={{
          backgroundImage: `
            radial-gradient(circle at 25% 25%, rgba(102, 126, 234, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 75% 75%, rgba(240, 147, 251, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 75% 25%, rgba(79, 172, 254, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 25% 75%, rgba(0, 242, 254, 0.1) 0%, transparent 50%)
          `
        }} />
      </div>

      {/* Floating geometric shapes */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute opacity-10"
            style={{
              left: `${10 + (i * 15)}%`,
              top: `${20 + (i * 8)}%`
            }}
            animate={{
              y: [0, -30, 0],
              rotate: [0, 180, 360],
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 8 + i,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.5
            }}
          >
            <div className={`w-16 h-16 border-2 ${
              i % 4 === 0 ? 'border-blue-400 rounded-full' :
              i % 4 === 1 ? 'border-purple-400 rotate-45' :
              i % 4 === 2 ? 'border-pink-400 rounded-lg' :
              'border-cyan-400 rounded-none'
            }`} />
          </motion.div>
        ))}
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        {/* Ultra-Modern Hero Content */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-5xl mx-auto"
        >
          {/* Floating badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.1 }}
            whileHover={{ scale: 1.05 }}
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-full bg-gradient-to-r from-primary/20 via-accent/20 to-secondary/20 backdrop-blur-sm border border-white/20 mb-8"
          >
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-sm font-medium text-foreground">Trusted by 50,000+ Students Worldwide</span>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="w-2 h-2 bg-green-400 rounded-full"
            />
          </motion.div>

          {/* Main heading with enhanced effects */}
          <motion.h1
            className="text-6xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <motion.span 
              className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent inline-block"
              whileHover={{ 
                scale: 1.05,
                backgroundPosition: ["0%", "100%", "0%"],
                transition: { duration: 2 }
              }}
            >
              Get Your
            </motion.span>
            <br />
            <motion.span 
              className="bg-gradient-to-r from-secondary via-primary to-accent bg-clip-text text-transparent inline-block"
              whileHover={{ 
                scale: 1.05,
                rotate: 2,
                transition: { duration: 0.3 }
              }}
            >
              Missing PYQs
            </motion.span>
            <br />
            <motion.div className="relative inline-block">
              <span className="text-foreground">Instantly</span>
              {/* Animated underline */}
              <motion.div
                className="absolute -bottom-2 left-0 right-0 h-2 bg-gradient-to-r from-primary to-accent rounded-full"
                initial={{ scaleX: 0 }}
                animate={isInView ? { scaleX: 1 } : {}}
                transition={{ duration: 1, delay: 1 }}
              />
            </motion.div>
          </motion.h1>

          {/* Enhanced description */}
          <motion.p
            className="text-xl md:text-2xl text-foreground-secondary mb-12 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            Can't find a specific question paper or book? Request it through our advanced form system and get
            <motion.span 
              className="text-primary font-semibold mx-2"
              whileHover={{ scale: 1.1 }}
            >
              verified, high-quality content
            </motion.span>
            delivered within 24 hours, completely free!
          </motion.p>

          {/* Hero features */}
          <motion.div
            className="flex flex-wrap justify-center items-center gap-6 mb-12"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.7 }}
          >
            {heroFeatures.map((feature, index) => (
              <motion.div
                key={feature.text}
                className="flex items-center space-x-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20"
                whileHover={{ scale: 1.1, y: -2 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                delay={0.8 + index * 0.1}
              >
                <motion.div 
                  className={feature.color}
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {feature.icon}
                </motion.div>
                <span className="text-sm font-medium text-foreground">{feature.text}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* Enhanced CTA buttons */}
          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.9 }}
          >
            <motion.button
              onClick={scrollToForm}
              className="group relative px-10 py-5 bg-gradient-to-r from-primary via-accent to-secondary text-white font-semibold rounded-2xl shadow-2xl hover:shadow-primary/25 transition-all duration-500 overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {/* Button shine effect */}
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12" />
              
              <div className="relative flex items-center space-x-3">
                <Send className="w-6 h-6" />
                <span className="text-lg">Request Missing Content</span>
              </div>
            </motion.button>

            <motion.button
              onClick={scrollToForm}
              className="group flex items-center space-x-2 px-8 py-5 border-2 border-primary/30 hover:border-primary text-foreground hover:text-primary rounded-2xl transition-all duration-500 relative overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <MessageCircle className="w-6 h-6 relative z-10" />
              <span className="text-lg font-medium relative z-10">Contact Support</span>
            </motion.button>
          </motion.div>
        </motion.div>

        {/* Animated scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 1.2 }}
        >
          <motion.button
            onClick={scrollToForm}
            className="flex flex-col items-center space-y-2 text-foreground-secondary hover:text-primary transition-colors group"
            whileHover={{ y: -5 }}
          >
            <span className="text-sm font-medium">Scroll to Request Form</span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="p-2 rounded-full border border-primary/30 group-hover:border-primary group-hover:bg-primary/10 transition-all duration-300"
            >
              <ArrowDown className="w-5 h-5" />
            </motion.div>
          </motion.button>
        </motion.div>
      </div>
    </motion.section>
  );
};
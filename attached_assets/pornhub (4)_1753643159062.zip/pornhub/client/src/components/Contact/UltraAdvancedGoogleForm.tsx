import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  ExternalLink, 
  BookOpen, 
  FileText, 
  Sparkles, 
  Target, 
  Clock, 
  Users, 
  Star, 
  Shield,
  Zap,
  CheckCircle,
  Download,
  Search,
  TrendingUp,
  Award,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import * as THREE from 'three';

interface UltraAdvancedGoogleFormProps {
  title: string;
  description: string;
  formUrl: string;
  icon: React.ReactNode;
  color?: string;
  gradient?: string;
  variant?: 'books' | 'pyq' | 'general';
}

export const UltraAdvancedGoogleForm: React.FC<UltraAdvancedGoogleFormProps> = ({
  title,
  description,
  formUrl,
  icon,
  color = 'text-blue-500',
  gradient = 'from-blue-500/20 to-purple-500/20',
  variant = 'general'
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [successCount, setSuccessCount] = useState(0);
  const cardRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isInView = useInView(cardRef, { once: true });
  const frameRef = useRef<number | null>(null);

  // 3D Background Scene
  useEffect(() => {
    if (!canvasRef.current || !isInView) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true
    });

    renderer.setSize(400, 300);
    renderer.setClearColor(0x000000, 0);

    // Enhanced lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const primaryLight = new THREE.DirectionalLight(0x667eea, 1.2);
    primaryLight.position.set(2, 2, 2);
    scene.add(primaryLight);

    // Floating geometric elements
    const elements: THREE.Mesh[] = [];
    const geometries = [
      new THREE.BoxGeometry(0.3, 0.3, 0.3),
      new THREE.SphereGeometry(0.2, 8, 8),
      new THREE.TetrahedronGeometry(0.25),
      new THREE.OctahedronGeometry(0.2)
    ];

    for (let i = 0; i < 15; i++) {
      const geometry = geometries[Math.floor(Math.random() * geometries.length)];
      const material = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(Math.random(), 0.8, 0.6),
        transparent: true,
        opacity: 0.7
      });
      
      const element = new THREE.Mesh(geometry, material);
      element.position.set(
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 4,
        (Math.random() - 0.5) * 3
      );
      
      element.userData = {
        rotationSpeed: {
          x: (Math.random() - 0.5) * 0.02,
          y: (Math.random() - 0.5) * 0.02,
          z: (Math.random() - 0.5) * 0.02
        },
        floatSpeed: 0.02 + Math.random() * 0.02,
        floatAmplitude: 0.5 + Math.random() * 0.5
      };
      
      elements.push(element);
      scene.add(element);
    }

    camera.position.z = 5;

    // Animation loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      elements.forEach((element, index) => {
        const userData = element.userData;
        
        element.rotation.x += userData.rotationSpeed.x;
        element.rotation.y += userData.rotationSpeed.y;
        element.rotation.z += userData.rotationSpeed.z;
        
        element.position.y += Math.sin(time * userData.floatSpeed + index) * 0.01;
        
        // Hover effect
        if (isHovered) {
          element.scale.setScalar(1.2);
          const material = element.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0.3;
        } else {
          element.scale.setScalar(1);
          const material = element.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0;
        }
      });

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [isInView, isHovered]);

  // Success counter animation
  useEffect(() => {
    const interval = setInterval(() => {
      setSuccessCount(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const features = {
    books: [
      { icon: <Download className="w-4 h-4" />, text: "Instant Download", color: "text-green-400" },
      { icon: <Shield className="w-4 h-4" />, text: "Authentic Content", color: "text-blue-400" },
      { icon: <Search className="w-4 h-4" />, text: "Smart Search", color: "text-purple-400" },
      { icon: <Globe className="w-4 h-4" />, text: "Global Collection", color: "text-orange-400" }
    ],
    pyq: [
      { icon: <TrendingUp className="w-4 h-4" />, text: "Latest Papers", color: "text-green-400" },
      { icon: <Award className="w-4 h-4" />, text: "University Verified", color: "text-blue-400" },
      { icon: <CheckCircle className="w-4 h-4" />, text: "Solution Included", color: "text-purple-400" },
      { icon: <Clock className="w-4 h-4" />, text: "Quick Delivery", color: "text-orange-400" }
    ],
    general: [
      { icon: <Target className="w-4 h-4" />, text: "Quick Response", color: "text-green-400" },
      { icon: <Clock className="w-4 h-4" />, text: "24hr Processing", color: "text-blue-400" },
      { icon: <Users className="w-4 h-4" />, text: "Expert Support", color: "text-purple-400" },
      { icon: <Star className="w-4 h-4" />, text: "Premium Quality", color: "text-orange-400" }
    ]
  };

  const stats = {
    books: { requests: "15,000+", success: "99.2%", time: "< 2hrs" },
    pyq: { requests: "25,000+", success: "99.8%", time: "< 1hr" },
    general: { requests: "50,000+", success: "99.5%", time: "< 30min" }
  };

  const handleFormClick = () => {
    setIsClicked(true);
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      setIsClicked(false);
    }, 1000);
    
    // Open form in new window with optimized settings
    const formWindow = window.open(
      formUrl, 
      '_blank', 
      'width=900,height=1000,scrollbars=yes,resizable=yes,toolbar=no,menubar=no,location=no,status=no'
    );
    
    if (formWindow) {
      formWindow.focus();
    }
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, rotateX: -15, scale: 0.9 }}
      animate={isInView ? { 
        opacity: 1, 
        y: 0, 
        rotateX: 0,
        scale: isClicked ? 0.95 : 1
      } : {}}
      transition={{ 
        duration: 1, 
        type: "spring",
        bounce: 0.3
      }}
      whileHover={{ 
        y: -15,
        rotateY: 3,
        rotateX: 2,
        scale: 1.02,
        transition: { duration: 0.4 }
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="relative group perspective-1000"
    >
      <Card className={`
        relative overflow-hidden border-2 transition-all duration-700
        ${isHovered 
          ? `${color.replace('text-', 'border-')} shadow-2xl` 
          : 'border-transparent hover:border-white/20'
        }
        bg-gradient-to-br ${gradient} backdrop-blur-sm
        transform-gpu will-change-transform
        ${isHovered ? 'shadow-glow' : ''}
      `}>
        {/* 3D Background Canvas */}
        <div className="absolute inset-0 opacity-20">
          <canvas 
            ref={canvasRef}
            width={400}
            height={300}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Animated Border Glow */}
        <motion.div
          className="absolute inset-0 rounded-lg opacity-50"
          animate={{
            background: isHovered 
              ? `conic-gradient(from 0deg, transparent, ${color.replace('text-', '')}, transparent)`
              : 'transparent'
          }}
          transition={{ duration: 0.7 }}
        />

        {/* Floating Particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className={`absolute w-1 h-1 ${color.replace('text-', 'bg-')} rounded-full`}
              animate={{
                x: [0, Math.random() * 400],
                y: [0, Math.random() * 300],
                opacity: [0, 1, 0],
                scale: [0, 1.5, 0]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2
              }}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`
              }}
            />
          ))}
        </div>

        <CardContent className="relative z-10 p-8 space-y-6">
          {/* Enhanced Header */}
          <motion.div 
            className="flex items-center space-x-4"
            animate={{ scale: isHovered ? 1.05 : 1 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className={`
                p-4 rounded-2xl bg-gradient-to-br ${gradient} 
                border-2 border-white/30 backdrop-blur-sm
                ${color} shadow-lg relative overflow-hidden
              `}
              animate={{
                rotate: isHovered ? [0, 8, -8, 0] : 0,
                scale: isHovered ? 1.15 : 1,
                borderColor: isHovered ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.3)'
              }}
              transition={{ duration: 0.6 }}
            >
              {icon}
              
              {/* Icon glow effect */}
              <motion.div
                className="absolute inset-0 rounded-2xl"
                animate={{
                  boxShadow: isHovered 
                    ? `0 0 20px ${color.replace('text-', 'rgba(').replace('500', '102, 126, 234, 0.5)')}`
                    : '0 0 0px rgba(0,0,0,0)'
                }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>
            
            <div className="space-y-2">
              <motion.h3 
                className="text-xl font-bold text-foreground relative"
                animate={{ x: isHovered ? 8 : 0 }}
                transition={{ duration: 0.3 }}
              >
                {title}
                <motion.div
                  className="absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-primary to-accent"
                  animate={{ width: isHovered ? '100%' : '0%' }}
                  transition={{ duration: 0.4 }}
                />
              </motion.h3>
              
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs bg-white/20 border-white/30">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Advanced Form
                </Badge>
                <Badge variant="outline" className={`text-xs ${color} border-current`}>
                  Live: {successCount + 1247}
                </Badge>
              </div>
            </div>
          </motion.div>

          {/* Enhanced Description */}
          <motion.p 
            className="text-foreground-secondary leading-relaxed"
            animate={{ opacity: isHovered ? 1 : 0.9 }}
            transition={{ duration: 0.3 }}
          >
            {description}
          </motion.p>

          {/* Advanced Features Grid */}
          <motion.div 
            className="grid grid-cols-2 gap-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: isInView ? 1 : 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            {features[variant].map((feature, index) => (
              <motion.div
                key={index}
                className="flex items-center space-x-2 p-3 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: isInView ? 1 : 0, x: isInView ? 0 : -20 }}
                transition={{ delay: 0.1 * index, duration: 0.4 }}
                whileHover={{ 
                  scale: 1.05, 
                  backgroundColor: 'rgba(255,255,255,0.15)',
                  borderColor: 'rgba(255,255,255,0.4)'
                }}
              >
                <span className={feature.color}>{feature.icon}</span>
                <span className="text-sm font-medium text-foreground">{feature.text}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* Enhanced Stats Section */}
          <motion.div 
            className="grid grid-cols-3 gap-4 p-4 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10"
            whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.1)' }}
          >
            <div className="text-center">
              <div className="text-xs text-foreground-secondary">Requests</div>
              <motion.div 
                className="text-lg font-bold text-foreground"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {stats[variant].requests}
              </motion.div>
            </div>
            <div className="text-center border-x border-white/20">
              <div className="text-xs text-foreground-secondary">Success Rate</div>
              <motion.div 
                className="text-lg font-bold text-green-400"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                {stats[variant].success}
              </motion.div>
            </div>
            <div className="text-center">
              <div className="text-xs text-foreground-secondary">Avg. Time</div>
              <motion.div 
                className="text-lg font-bold text-blue-400"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 1 }}
              >
                {stats[variant].time}
              </motion.div>
            </div>
          </motion.div>

          {/* Enhanced Action Button */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleFormClick}
              disabled={isLoading}
              className={`
                w-full group relative overflow-hidden
                bg-gradient-to-r from-primary via-accent to-primary
                hover:from-primary/90 hover:via-accent/90 hover:to-primary/90
                text-white font-bold py-6 px-8 rounded-xl
                shadow-2xl hover:shadow-3xl
                transform-gpu transition-all duration-500
                border-2 border-white/30 hover:border-white/50
                bg-size-200 bg-pos-0 text-lg
              `}
              style={{
                backgroundSize: '200% 200%'
              }}
            >
              {/* Animated Background */}
              <motion.div
                className="absolute inset-0"
                animate={{
                  backgroundPosition: isHovered ? ['0%', '100%', '0%'] : '0%'
                }}
                transition={{ duration: 2, ease: "easeInOut" }}
                style={{
                  background: 'linear-gradient(-45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.3), rgba(255,255,255,0.1))',
                  backgroundSize: '200% 200%'
                }}
              />
              
              {/* Button Content */}
              <span className="relative z-10 flex items-center justify-center space-x-3">
                <AnimatePresence mode="wait">
                  {isLoading ? (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="flex items-center space-x-2"
                    >
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                      />
                      <span>Opening Form...</span>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="normal"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="flex items-center space-x-2"
                    >
                      <span>Open Request Form</span>
                      <motion.div
                        animate={{ x: isHovered ? 5 : 0, rotate: isHovered ? 15 : 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <ExternalLink className="w-5 h-5" />
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </span>

              {/* Button pulse effect */}
              <motion.div
                className="absolute inset-0 rounded-xl"
                animate={{
                  boxShadow: isHovered 
                    ? [
                        '0 0 0 0 rgba(102, 126, 234, 0.4)',
                        '0 0 0 10px rgba(102, 126, 234, 0)',
                        '0 0 0 0 rgba(102, 126, 234, 0.4)'
                      ]
                    : '0 0 0 0 rgba(102, 126, 234, 0)'
                }}
                transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
              />
            </Button>
          </motion.div>

          {/* Enhanced Trust Indicators */}
          <motion.div 
            className="flex items-center justify-center space-x-6 text-xs text-foreground-secondary pt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: isInView ? 1 : 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
          >
            <motion.div 
              className="flex items-center space-x-1"
              whileHover={{ scale: 1.1 }}
            >
              <motion.div 
                className="w-2 h-2 bg-green-500 rounded-full"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              <span>SSL Secured</span>
            </motion.div>
            
            <div className="w-px h-4 bg-border"></div>
            
            <motion.div 
              className="flex items-center space-x-1"
              whileHover={{ scale: 1.1 }}
            >
              <motion.div 
                className="w-2 h-2 bg-blue-500 rounded-full"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
              />
              <span>Instant Response</span>
            </motion.div>
            
            <div className="w-px h-4 bg-border"></div>
            
            <motion.div 
              className="flex items-center space-x-1"
              whileHover={{ scale: 1.1 }}
            >
              <motion.div 
                className="w-2 h-2 bg-purple-500 rounded-full"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 1 }}
              />
              <span>Free Service</span>
            </motion.div>
          </motion.div>
        </CardContent>

        {/* Hover Overlay Effect */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none rounded-lg"
            />
          )}
        </AnimatePresence>

        {/* Success Pulse Effect */}
        <AnimatePresence>
          {isClicked && (
            <motion.div
              initial={{ scale: 1, opacity: 0.8 }}
              animate={{ scale: 1.2, opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="absolute inset-0 bg-green-400/30 rounded-lg pointer-events-none"
            />
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
};
import React, { useState, useRef, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Users, BookOpen, Clock, Award, Star, Zap, Shield, Globe, TrendingUp, CheckCircle, Target, Crown } from 'lucide-react';
import * as THREE from 'three';

interface Stat {
  id: string;
  value: string;
  label: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  gradient: string;
}

export const ContactStats: React.FC = () => {
  const [hoveredStat, setHoveredStat] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true });
  const animationIdRef = useRef<number | null>(null);

  const stats: Stat[] = [
    {
      id: 'students',
      value: '50,000+',
      label: 'Happy Students',
      icon: <Users className="w-8 h-8" />,
      description: 'Students trust our platform daily',
      color: 'text-blue-500',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'papers',
      value: '25,000+',
      label: 'Question Papers',
      icon: <BookOpen className="w-8 h-8" />,
      description: 'Comprehensive collection across all subjects',
      color: 'text-green-500',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      id: 'response',
      value: '< 24 Hours',
      label: 'Response Time',
      icon: <Clock className="w-8 h-8" />,
      description: 'Lightning-fast support response',
      color: 'text-purple-500',
      gradient: 'from-purple-500 to-violet-500'
    },
    {
      id: 'success',
      value: '99.9%',
      label: 'Success Rate',
      icon: <Award className="w-8 h-8" />,
      description: 'Proven track record of delivery',
      color: 'text-orange-500',
      gradient: 'from-orange-500 to-amber-500'
    },
    {
      id: 'rating',
      value: '4.9/5',
      label: 'Student Rating',
      icon: <Star className="w-8 h-8" />,
      description: 'Consistently excellent feedback',
      color: 'text-yellow-500',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      id: 'delivery',
      value: '< 6 Hours',
      label: 'Average Delivery',
      icon: <Zap className="w-8 h-8" />,
      description: 'Super-fast content delivery',
      color: 'text-pink-500',
      gradient: 'from-pink-500 to-rose-500'
    },
    {
      id: 'security',
      value: '100%',
      label: 'Secure Platform',
      icon: <Shield className="w-8 h-8" />,
      description: 'Bank-level security protocols',
      color: 'text-red-500',
      gradient: 'from-red-500 to-pink-500'
    },
    {
      id: 'global',
      value: '150+',
      label: 'Countries Served',
      icon: <Globe className="w-8 h-8" />,
      description: 'Worldwide student community',
      color: 'text-indigo-500',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      id: 'growth',
      value: '200%',
      label: 'YoY Growth',
      icon: <TrendingUp className="w-8 h-8" />,
      description: 'Rapidly expanding platform',
      color: 'text-teal-500',
      gradient: 'from-teal-500 to-cyan-500'
    },
    {
      id: 'verified',
      value: '100%',
      label: 'Verified Content',
      icon: <CheckCircle className="w-8 h-8" />,
      description: 'All materials thoroughly checked',
      color: 'text-emerald-500',
      gradient: 'from-emerald-500 to-green-500'
    },
    {
      id: 'accuracy',
      value: '99.8%',
      label: 'Accuracy Rate',
      icon: <Target className="w-8 h-8" />,
      description: 'Precise and reliable content',
      color: 'text-violet-500',
      gradient: 'from-violet-500 to-purple-500'
    },
    {
      id: 'premium',
      value: '95%',
      label: 'Premium Quality',
      icon: <Crown className="w-8 h-8" />,
      description: 'Top-tier educational materials',
      color: 'text-amber-500',
      gradient: 'from-amber-500 to-yellow-500'
    }
  ];

  // Ultra-modern 3D background animation
  useEffect(() => {
    if (!canvasRef.current || !isInView) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: false,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(window.innerWidth, 600);
    renderer.setClearColor(0x000000, 0);

    // Create floating statistical elements
    const statElements: THREE.Mesh[] = [];
    const geometries = [
      new THREE.SphereGeometry(0.05, 8, 8),
      new THREE.BoxGeometry(0.08, 0.08, 0.08),
      new THREE.TetrahedronGeometry(0.06),
      new THREE.OctahedronGeometry(0.05),
      new THREE.CylinderGeometry(0.04, 0.04, 0.1, 6),
    ];

    for (let i = 0; i < 40; i++) {
      const geometry = geometries[i % geometries.length];
      const material = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL((i / 40), 0.8, 0.6),
        transparent: true,
        opacity: 0.6
      });
      
      const element = new THREE.Mesh(geometry, material);
      element.position.set(
        (Math.random() - 0.5) * 15,
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 8
      );
      
      scene.add(element);
      statElements.push(element);
    }

    // Create connection lines
    const lineGeometry = new THREE.BufferGeometry();
    const linePositions = [];
    for (let i = 0; i < 80; i++) {
      linePositions.push((Math.random() - 0.5) * 20);
      linePositions.push((Math.random() - 0.5) * 10);
      linePositions.push((Math.random() - 0.5) * 10);
    }
    lineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
    const lineMaterial = new THREE.LineBasicMaterial({ 
      color: 0x667eea,
      transparent: true,
      opacity: 0.2
    });
    const dataConnections = new THREE.Line(lineGeometry, lineMaterial);
    scene.add(dataConnections);

    camera.position.z = 8;

    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      
      const time = Date.now() * 0.001;
      
      statElements.forEach((element, index) => {
        element.rotation.x += 0.01;
        element.rotation.y += 0.015;
        element.rotation.z += 0.005;
        element.position.y += Math.sin(time + index * 0.5) * 0.002;
        element.position.x += Math.cos(time * 0.5 + index) * 0.001;
      });
      
      dataConnections.rotation.y += 0.002;
      dataConnections.rotation.x += 0.001;
      
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / 600;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, 600);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [isInView]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const statVariants = {
    hidden: { opacity: 0, y: 50, rotateX: -30 },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        duration: 0.8,
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <motion.section 
      ref={containerRef}
      className="relative py-24 overflow-hidden"
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={containerVariants}
    >
      {/* Ultra-Modern 3D Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-30"
        style={{ height: '600px' }}
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5" />
      
      {/* Animated Grid Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full" style={{
          backgroundImage: `
            linear-gradient(rgba(102, 126, 234, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(102, 126, 234, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
          transform: 'perspective(1000px) rotateX(20deg)'
        }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Ultra-Modern Header */}
        <motion.div 
          className="text-center mb-20"
          initial={{ opacity: 0, y: -30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <motion.h2 
            className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent mb-6"
            whileHover={{ scale: 1.05 }}
          >
            Platform Excellence
          </motion.h2>
          <motion.p 
            className="text-xl text-foreground-secondary max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            Trusted by students worldwide, our platform delivers exceptional educational resources with unmatched reliability and performance
          </motion.p>
        </motion.div>

        {/* Ultra-Modern Stats Grid */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
          variants={containerVariants}
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.id}
              variants={statVariants}
              whileHover={{ 
                scale: 1.08, 
                rotateY: 5,
                rotateX: 5,
                transition: { duration: 0.3 }
              }}
              onHoverStart={() => setHoveredStat(stat.id)}
              onHoverEnd={() => setHoveredStat(null)}
              className="group perspective-1000"
            >
              <div className="relative p-8 rounded-3xl bg-gradient-to-br from-white/10 via-white/5 to-transparent border border-white/20 backdrop-blur-sm hover:border-white/40 transition-all duration-500 overflow-hidden">
                {/* Holographic Background */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                
                {/* Floating Particles */}
                <div className="absolute inset-0 overflow-hidden">
                  {[...Array(6)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1 h-1 bg-white/40 rounded-full"
                      animate={{
                        x: [0, Math.random() * 100 - 50, 0],
                        y: [0, Math.random() * 100 - 50, 0],
                        opacity: [0, 1, 0],
                        scale: [0, 1.5, 0]
                      }}
                      transition={{
                        duration: 3 + Math.random() * 2,
                        repeat: Infinity,
                        delay: Math.random() * 2
                      }}
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`
                      }}
                    />
                  ))}
                </div>

                {/* Icon with enhanced effects */}
                <motion.div 
                  className={`relative mb-6 ${stat.color} group-hover:scale-125 transition-transform duration-500`}
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.8 }}
                >
                  <div className="relative z-10">
                    {stat.icon}
                  </div>
                  {/* Icon glow */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500`} />
                </motion.div>

                {/* Value with enhanced typography */}
                <motion.div 
                  className={`text-4xl md:text-5xl font-bold bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-500`}
                  whileHover={{ rotateY: 5 }}
                >
                  {stat.value}
                </motion.div>

                {/* Label */}
                <h3 className="text-lg font-semibold text-foreground mb-3 group-hover:text-primary transition-colors duration-300">
                  {stat.label}
                </h3>

                {/* Description with reveal animation */}
                <motion.p 
                  className="text-sm text-foreground-secondary leading-relaxed"
                  initial={{ opacity: 0.7, height: '2.5rem' }}
                  whileHover={{ opacity: 1, height: 'auto' }}
                  transition={{ duration: 0.3 }}
                >
                  {stat.description}
                </motion.p>

                {/* Enhanced hover border effect */}
                <div className={`absolute inset-0 rounded-3xl border-2 border-transparent group-hover:border-gradient-to-r group-hover:${stat.gradient} opacity-0 group-hover:opacity-50 transition-opacity duration-500`} />
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Trust indicators */}
        <motion.div 
          className="mt-20 text-center"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <div className="flex flex-wrap justify-center items-center gap-8 text-foreground-secondary">
            <motion.div 
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.1, color: "#10B981" }}
            >
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>ISO 27001 Certified</span>
            </motion.div>
            <motion.div 
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.1, color: "#3B82F6" }}
            >
              <Shield className="w-5 h-5 text-blue-500" />
              <span>SOC 2 Type II Compliant</span>
            </motion.div>
            <motion.div 
              className="flex items-center space-x-2"
              whileHover={{ scale: 1.1, color: "#F59E0B" }}
            >
              <Award className="w-5 h-5 text-amber-500" />
              <span>Industry Leader 2024</span>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.section>
  );
};
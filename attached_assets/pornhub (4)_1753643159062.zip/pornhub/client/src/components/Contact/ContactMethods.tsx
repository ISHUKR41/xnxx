import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, Phone, MapPin, Clock, Globe, ExternalLink } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export const ContactMethods: React.FC = () => {
  const contactMethods = [
    {
      icon: <Mail className="w-8 h-8" />,
      title: "Email Support",
      description: "Get comprehensive help via email with detailed responses",
      action: "ishu_2312res305@iitp.ac.in",
      href: "mailto:ishu_2312res305@iitp.ac.in",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      availability: "24/7 Available",
      responseTime: "< 2 hours"
    },
    {
      icon: <MessageSquare className="w-8 h-8" />,
      title: "WhatsApp Chat",
      description: "Quick responses on WhatsApp for urgent queries",
      action: "+91 7541024846",
      href: "https://wa.me/917541024846",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      availability: "9 AM - 9 PM",
      responseTime: "< 30 mins"
    },
    {
      icon: <Phone className="w-8 h-8" />,
      title: "Voice Call",
      description: "Direct phone support for urgent issues and guidance",
      action: "+91 7541024846",
      href: "tel:+917541024846",
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
      availability: "10 AM - 8 PM",
      responseTime: "Instant"
    }
  ];

  const officeInfo = {
    address: "New Delhi, India",
    coordinates: "28.6139° N, 77.2090° E",
    timezone: "IST (UTC+5:30)",
    workingDays: "Monday - Sunday"
  };

  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Choose Your Preferred Way
            </span>
          </h2>
          <p className="text-xl text-foreground-secondary max-w-3xl mx-auto">
            Multiple channels to reach us. Pick the one that works best for your needs and urgency level.
          </p>
        </motion.div>

        {/* Contact Methods Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {contactMethods.map((method, index) => (
            <motion.div
              key={method.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.03, rotateY: 5 }}
              className="group"
            >
              <Card className={`relative overflow-hidden ${method.bgColor} border-2 ${method.borderColor} hover:border-current transition-all duration-500 h-full`}>
                {/* Animated background */}
                <div className="absolute inset-0 bg-gradient-to-br from-current/5 to-current/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                {/* Floating particles */}
                <div className="absolute inset-0 overflow-hidden">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className={`absolute w-1 h-1 ${method.color} bg-current rounded-full opacity-0 group-hover:opacity-100`}
                      animate={{
                        x: [0, Math.random() * 60 - 30],
                        y: [0, Math.random() * 60 - 30],
                        opacity: [0, 1, 0]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: Math.random() * 2
                      }}
                      style={{
                        left: `${20 + Math.random() * 60}%`,
                        top: `${20 + Math.random() * 60}%`
                      }}
                    />
                  ))}
                </div>

                <CardContent className="relative p-8 space-y-6 h-full flex flex-col">
                  {/* Header */}
                  <div className="flex items-center space-x-4">
                    <motion.div
                      whileHover={{ rotate: 360, scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                      className={`p-3 rounded-xl ${method.color} bg-current/20 group-hover:bg-current/30 transition-colors`}
                    >
                      {method.icon}
                    </motion.div>
                    <div>
                      <h3 className={`text-xl font-bold text-foreground group-hover:${method.color} transition-colors`}>
                        {method.title}
                      </h3>
                      <p className="text-sm text-foreground-secondary">
                        {method.description}
                      </p>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="space-y-3 flex-grow">
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-foreground-secondary" />
                        <span className="text-foreground-secondary">Response</span>
                      </span>
                      <span className={`font-medium ${method.color}`}>
                        {method.responseTime}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex items-center space-x-2">
                        <Globe className="w-4 h-4 text-foreground-secondary" />
                        <span className="text-foreground-secondary">Available</span>
                      </span>
                      <span className={`font-medium ${method.color}`}>
                        {method.availability}
                      </span>
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-2">
                    <div className={`text-lg font-semibold ${method.color}`}>
                      {method.action}
                    </div>
                  </div>

                  {/* Action Button */}
                  <Button
                    onClick={() => window.open(method.href, "_blank")}
                    className={`w-full ${method.color} bg-current/10 hover:bg-current/20 border-2 border-current/30 hover:border-current text-current hover:text-white transition-all duration-300 group-hover:scale-105`}
                  >
                    <span className="mr-2">Contact Now</span>
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Office Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-2 border-primary/20">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-foreground mb-2">Our Location</h3>
                <p className="text-foreground-secondary">Operating from the heart of India's education hub</p>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center space-y-2">
                  <MapPin className="w-6 h-6 text-primary mx-auto" />
                  <div className="font-medium text-foreground">Address</div>
                  <div className="text-sm text-foreground-secondary">{officeInfo.address}</div>
                </div>
                
                <div className="text-center space-y-2">
                  <Globe className="w-6 h-6 text-green-500 mx-auto" />
                  <div className="font-medium text-foreground">Coordinates</div>
                  <div className="text-sm text-foreground-secondary">{officeInfo.coordinates}</div>
                </div>
                
                <div className="text-center space-y-2">
                  <Clock className="w-6 h-6 text-orange-500 mx-auto" />
                  <div className="font-medium text-foreground">Timezone</div>
                  <div className="text-sm text-foreground-secondary">{officeInfo.timezone}</div>
                </div>
                
                <div className="text-center space-y-2">
                  <MessageSquare className="w-6 h-6 text-purple-500 mx-auto" />
                  <div className="font-medium text-foreground">Working Days</div>
                  <div className="text-sm text-foreground-secondary">{officeInfo.workingDays}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};
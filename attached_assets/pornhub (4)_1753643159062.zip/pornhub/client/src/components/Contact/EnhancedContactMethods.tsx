import React, { useState, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  Mail, 
  MessageSquare, 
  Phone, 
  MapPin, 
  Clock, 
  Users, 
  ExternalLink,
  Zap,
  Shield,
  Star,
  Globe,
  Headphones,
  Video,
  Calendar,
  Send
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const EnhancedContactMethods: React.FC = () => {
  const [hoveredMethod, setHoveredMethod] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true });

  const contactMethods = [
    {
      id: 'email',
      icon: <Mail className="w-8 h-8" />,
      title: "Email Support",
      subtitle: "Comprehensive Help",
      description: "Get detailed responses and documentation via email with file attachments and screenshots",
      action: "ishu_2312res305@iitp.ac.in",
      href: "mailto:ishu_2312res305@iitp.ac.in",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/30",
      gradient: "from-blue-500/20 to-blue-600/10",
      availability: "24/7 Available",
      responseTime: "< 2 hours",
      features: ["File Attachments", "Detailed Solutions", "Screen Recordings", "Priority Support"],
      animation: "float"
    },
    {
      id: 'whatsapp',
      icon: <MessageSquare className="w-8 h-8" />,
      title: "WhatsApp Chat",
      subtitle: "Instant Messaging",
      description: "Quick responses and real-time chat support for urgent academic queries and doubts",
      action: "+91 7541024846",
      href: "https://wa.me/917541024846",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/30",
      gradient: "from-green-500/20 to-green-600/10",
      availability: "9 AM - 9 PM",
      responseTime: "< 30 mins",
      features: ["Voice Messages", "Document Sharing", "Live Status", "Group Support"],
      animation: "bounce"
    },
    {
      id: 'phone',
      icon: <Phone className="w-8 h-8" />,
      title: "Voice Call",
      subtitle: "Direct Communication",
      description: "Personal phone support for complex issues, guidance, and detailed explanations",
      action: "+91 7541024846",
      href: "tel:+917541024846",
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/30",
      gradient: "from-orange-500/20 to-orange-600/10",
      availability: "10 AM - 8 PM",
      responseTime: "Instant",
      features: ["Personal Consultation", "Step-by-step Guidance", "Academic Counseling", "Career Advice"],
      animation: "pulse"
    },
    {
      id: 'video',
      icon: <Video className="w-8 h-8" />,
      title: "Video Consultation",
      subtitle: "Face-to-Face Help",
      description: "Schedule video calls for complex problems, doubt clearing, and academic planning",
      action: "Schedule Meeting",
      href: "https://calendly.com/studenthub-support",
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/30",
      gradient: "from-purple-500/20 to-purple-600/10",
      availability: "By Appointment",
      responseTime: "Same Day",
      features: ["Screen Sharing", "Recording Available", "Multiple Students", "Expert Sessions"],
      animation: "rotate"
    }
  ];

  const officeInfo = {
    address: "New Delhi, India",
    coordinates: "28.6139° N, 77.2090° E",
    timezone: "IST (UTC+5:30)",
    workingDays: "Monday - Sunday",
    languages: "Hindi, English",
    certifications: ["ISO 9001:2015", "Educational Partner"]
  };

  const trustFactors = [
    { icon: <Shield className="w-5 h-5" />, text: "Secure & Private", color: "text-green-400" },
    { icon: <Zap className="w-5 h-5" />, text: "Lightning Fast", color: "text-yellow-400" },
    { icon: <Star className="w-5 h-5" />, text: "5-Star Rated", color: "text-purple-400" },
    { icon: <Users className="w-5 h-5" />, text: "50K+ Students", color: "text-blue-400" }
  ];

  const getAnimationClass = (animation: string) => {
    switch(animation) {
      case 'float': return 'animate-float';
      case 'bounce': return 'animate-bounce-slow';
      case 'pulse': return 'animate-pulse-slow';
      case 'rotate': return 'animate-rotate-slow';
      default: return '';
    }
  };

  return (
    <section ref={containerRef} className="py-20 px-4 bg-gradient-to-br from-background via-background-secondary to-background">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2 
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6"
            animate={{
              backgroundPosition: ['0%', '100%', '0%']
            }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            style={{
              background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)))',
              backgroundSize: '200% 200%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}
          >
            Multiple Ways to Connect
          </motion.h2>
          <motion.p 
            className="text-xl md:text-2xl text-foreground-secondary max-w-4xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Choose your preferred communication method. Our expert team is ready to assist you 
            through multiple channels with personalized support.
          </motion.p>
        </motion.div>

        {/* Trust Factors */}
        <motion.div 
          className="flex flex-wrap justify-center gap-6 mb-12"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          {trustFactors.map((factor, index) => (
            <motion.div
              key={index}
              className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 border border-white/20"
              whileHover={{ scale: 1.05 }}
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.1 * index }}
            >
              <span className={factor.color}>{factor.icon}</span>
              <span className="text-sm font-medium text-foreground">{factor.text}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Contact Methods Grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-8 mb-16">
          {contactMethods.map((method, index) => (
            <motion.div
              key={method.id}
              initial={{ opacity: 0, y: 50, rotateY: -15 }}
              animate={isInView ? { 
                opacity: 1, 
                y: 0, 
                rotateY: 0 
              } : {}}
              transition={{ 
                duration: 0.8, 
                delay: 0.2 * index,
                type: "spring",
                bounce: 0.3
              }}
              whileHover={{ 
                scale: 1.02,
                rotateY: 2,
                z: 10
              }}
              onHoverStart={() => setHoveredMethod(method.id)}
              onHoverEnd={() => setHoveredMethod(null)}
              className="group perspective-1000"
            >
              <Card className={`
                h-full overflow-hidden border-2 transition-all duration-500
                ${hoveredMethod === method.id 
                  ? `${method.borderColor} shadow-2xl shadow-${method.color.split('-')[1]}-500/20` 
                  : 'border-transparent hover:border-white/20'
                }
                bg-gradient-to-br ${method.gradient} backdrop-blur-sm
                transform-gpu will-change-transform
              `}>
                <CardContent className="p-8 space-y-6 relative overflow-hidden">
                  {/* Background Animation */}
                  <div className="absolute inset-0 opacity-10">
                    <div className={`w-32 h-32 ${method.bgColor} rounded-full blur-3xl ${getAnimationClass(method.animation)}`} 
                         style={{ 
                           transform: 'translate(-50%, -50%)',
                           top: '50%',
                           left: '50%'
                         }} 
                    />
                  </div>

                  {/* Header */}
                  <motion.div 
                    className="flex items-center space-x-4 relative z-10"
                    animate={{ scale: hoveredMethod === method.id ? 1.05 : 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <motion.div
                      className={`
                        p-4 rounded-2xl ${method.bgColor} border border-white/20 backdrop-blur-sm
                        ${method.color} shadow-lg relative overflow-hidden
                      `}
                      animate={{
                        rotate: hoveredMethod === method.id ? [0, 5, -5, 0] : 0,
                        scale: hoveredMethod === method.id ? 1.1 : 1
                      }}
                      transition={{ duration: 0.5 }}
                    >
                      {method.icon}
                      {hoveredMethod === method.id && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute inset-0 bg-white/20 rounded-2xl"
                        />
                      )}
                    </motion.div>
                    
                    <div className="space-y-1">
                      <motion.h3 
                        className="text-xl font-bold text-foreground"
                        animate={{ x: hoveredMethod === method.id ? 5 : 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        {method.title}
                      </motion.h3>
                      <Badge variant="secondary" className="text-xs">
                        {method.subtitle}
                      </Badge>
                    </div>
                  </motion.div>

                  {/* Description */}
                  <motion.p 
                    className="text-foreground-secondary leading-relaxed text-sm relative z-10"
                    animate={{ opacity: hoveredMethod === method.id ? 1 : 0.8 }}
                    transition={{ duration: 0.3 }}
                  >
                    {method.description}
                  </motion.p>

                  {/* Features */}
                  <motion.div 
                    className="space-y-2 relative z-10"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: isInView ? 1 : 0 }}
                    transition={{ delay: 0.3 + 0.1 * index, duration: 0.5 }}
                  >
                    {method.features.slice(0, 2).map((feature, featureIndex) => (
                      <motion.div
                        key={featureIndex}
                        className="flex items-center space-x-2 text-xs text-foreground-secondary"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: isInView ? 1 : 0, x: isInView ? 0 : -10 }}
                        transition={{ delay: 0.1 * featureIndex, duration: 0.3 }}
                      >
                        <div className={`w-1.5 h-1.5 ${method.bgColor} rounded-full`} />
                        <span>{feature}</span>
                      </motion.div>
                    ))}
                  </motion.div>

                  {/* Stats */}
                  <motion.div 
                    className="flex justify-between items-center p-3 bg-white/5 backdrop-blur-sm rounded-lg relative z-10"
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="text-center">
                      <div className="text-xs text-foreground-secondary">Available</div>
                      <div className="text-sm font-semibold text-foreground">{method.availability}</div>
                    </div>
                    <div className="w-px h-8 bg-border"></div>
                    <div className="text-center">
                      <div className="text-xs text-foreground-secondary">Response</div>
                      <div className="text-sm font-semibold text-foreground">{method.responseTime}</div>
                    </div>
                  </motion.div>

                  {/* Action Button */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative z-10"
                  >
                    <Button
                      onClick={() => window.open(method.href, "_blank")}
                      className={`
                        w-full group relative overflow-hidden
                        ${method.color} bg-current/10 hover:bg-current text-current hover:text-white
                        border-2 border-current/30 hover:border-current
                        transition-all duration-300 font-semibold py-3
                      `}
                    >
                      <motion.div
                        className="absolute inset-0 bg-current"
                        initial={{ x: '-100%' }}
                        animate={{ x: hoveredMethod === method.id ? '0%' : '-100%' }}
                        transition={{ duration: 0.3 }}
                      />
                      <span className="relative z-10 flex items-center justify-center space-x-2">
                        <span>Contact Now</span>
                        <motion.div
                          animate={{ x: hoveredMethod === method.id ? 3 : 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </motion.div>
                      </span>
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Office Information */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10"
        >
          <div className="text-center mb-8">
            <motion.h3 
              className="text-2xl md:text-3xl font-bold text-foreground mb-4"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Our Office Information
            </motion.h3>
            <p className="text-foreground-secondary">
              Headquartered in the heart of India's educational capital
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div 
              className="text-center space-y-4"
              whileHover={{ scale: 1.05 }}
            >
              <div className="p-4 bg-blue-500/10 rounded-2xl w-fit mx-auto">
                <MapPin className="w-8 h-8 text-blue-400" />
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">Location</h4>
                <p className="text-sm text-foreground-secondary">{officeInfo.address}</p>
                <p className="text-xs text-foreground-secondary">{officeInfo.coordinates}</p>
              </div>
            </motion.div>

            <motion.div 
              className="text-center space-y-4"
              whileHover={{ scale: 1.05 }}
            >
              <div className="p-4 bg-green-500/10 rounded-2xl w-fit mx-auto">
                <Clock className="w-8 h-8 text-green-400" />
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">Working Hours</h4>
                <p className="text-sm text-foreground-secondary">{officeInfo.workingDays}</p>
                <p className="text-xs text-foreground-secondary">Timezone: {officeInfo.timezone}</p>
              </div>
            </motion.div>

            <motion.div 
              className="text-center space-y-4"
              whileHover={{ scale: 1.05 }}
            >
              <div className="p-4 bg-purple-500/10 rounded-2xl w-fit mx-auto">
                <Globe className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">Languages</h4>
                <p className="text-sm text-foreground-secondary">{officeInfo.languages}</p>
                <p className="text-xs text-foreground-secondary">Multi-lingual Support</p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
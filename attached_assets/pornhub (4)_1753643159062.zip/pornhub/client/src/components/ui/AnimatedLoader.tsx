import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as THREE from 'three';

interface AnimatedLoaderProps {
  isLoading: boolean;
  onComplete: () => void;
}

export const AnimatedLoader: React.FC<AnimatedLoaderProps> = ({ isLoading, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Initializing');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const frameRef = useRef<number | null>(null);

  const loadingSteps = [
    'Initializing StudentHub...',
    'Loading 3D Components...',
    'Preparing Educational Tools...',
    'Connecting to Database...',
    'Optimizing Performance...',
    'Finalizing Experience...',
    'Welcome to StudentHub!'
  ];

  // Progress simulation
  useEffect(() => {
    if (!isLoading) return;

    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 15;
        const stepIndex = Math.floor((newProgress / 100) * loadingSteps.length);
        setLoadingText(loadingSteps[Math.min(stepIndex, loadingSteps.length - 1)]);
        
        if (newProgress >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 1000);
          return 100;
        }
        return newProgress;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [isLoading, onComplete]);

  // 3D Loading Animation
  useEffect(() => {
    if (!canvasRef.current || !isLoading) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    sceneRef.current = scene;

    // Enhanced Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const primaryLight = new THREE.DirectionalLight(0x667eea, 1.5);
    primaryLight.position.set(5, 5, 5);
    scene.add(primaryLight);

    const accentLight = new THREE.DirectionalLight(0xf093fb, 1.2);
    accentLight.position.set(-5, 3, 2);
    scene.add(accentLight);

    // Central Loading Hub
    const hubGeometry = new THREE.IcosahedronGeometry(1.5, 1);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.8,
      emissive: 0x667eea,
      emissiveIntensity: 0.1
    });
    const loadingHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(loadingHub);

    // Orbital Rings
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 5; i++) {
      const ringGeometry = new THREE.TorusGeometry(2 + i * 0.5, 0.05, 8, 32);
      const ringMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(i * 0.2, 0.8, 0.6),
        transparent: true,
        opacity: 0.7,
        emissive: new THREE.Color().setHSL(i * 0.2, 0.8, 0.3),
        emissiveIntensity: 0.2
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.rotation.x = Math.random() * Math.PI;
      ring.rotation.y = Math.random() * Math.PI;
      rings.push(ring);
      scene.add(ring);
    }

    // Floating Data Particles
    const particles: THREE.Mesh[] = [];
    for (let i = 0; i < 50; i++) {
      const particleGeometry = new THREE.SphereGeometry(0.03, 8, 8);
      const particleMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(Math.random(), 0.8, 0.7),
        transparent: true,
        opacity: 0.8
      });
      const particle = new THREE.Mesh(particleGeometry, particleMaterial);
      
      particle.position.set(
        (Math.random() - 0.5) * 20,
        (Math.random() - 0.5) * 20,
        (Math.random() - 0.5) * 20
      );
      
      particle.userData = {
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.02,
          (Math.random() - 0.5) * 0.02,
          (Math.random() - 0.5) * 0.02
        ),
        originalPosition: particle.position.clone()
      };
      
      particles.push(particle);
      scene.add(particle);
    }

    camera.position.z = 8;

    // Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Rotate central hub
      loadingHub.rotation.x += 0.01;
      loadingHub.rotation.y += 0.015;
      loadingHub.rotation.z += 0.008;

      // Animate rings
      rings.forEach((ring, index) => {
        ring.rotation.x += 0.005 * (index + 1);
        ring.rotation.y += 0.008 * (index + 1);
        ring.rotation.z += 0.003 * (index + 1);
        
        // Progress-based scaling
        const scale = 0.5 + (progress / 100) * 0.5;
        ring.scale.setScalar(scale);
      });

      // Animate particles
      particles.forEach((particle, index) => {
        particle.position.add(particle.userData.velocity);
        
        // Orbit around center
        const orbitRadius = 3 + Math.sin(time + index) * 2;
        const angle = time * 0.5 + index * 0.1;
        particle.position.x = Math.cos(angle) * orbitRadius;
        particle.position.z = Math.sin(angle) * orbitRadius;
        particle.position.y = Math.sin(time * 2 + index) * 1;
        
        particle.rotation.x += 0.02;
        particle.rotation.y += 0.02;
      });

      // Camera movement
      camera.position.x = Math.sin(time * 0.2) * 0.5;
      camera.position.y = Math.cos(time * 0.15) * 0.3;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [isLoading, progress]);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 bg-gradient-to-br from-background via-background-secondary to-background flex flex-col items-center justify-center"
        >
          {/* 3D Canvas Background */}
          <canvas 
            ref={canvasRef}
            className="absolute inset-0 w-full h-full"
          />

          {/* Loading Content */}
          <div className="relative z-10 text-center space-y-8">
            {/* Logo Animation */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ duration: 1, type: "spring", bounce: 0.3 }}
              className="mb-8"
            >
              <div className="relative w-32 h-32 mx-auto">
                <motion.div
                  animate={{ 
                    rotate: 360,
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    rotate: { duration: 3, repeat: Infinity, ease: "linear" },
                    scale: { duration: 2, repeat: Infinity }
                  }}
                  className="w-full h-full bg-gradient-to-br from-primary via-accent to-primary rounded-3xl flex items-center justify-center shadow-2xl"
                >
                  <motion.span 
                    className="text-4xl font-bold text-white"
                    animate={{ opacity: [0.7, 1, 0.7] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    SH
                  </motion.span>
                </motion.div>
                
                {/* Orbital Elements */}
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute inset-0"
                    animate={{ rotate: 360 }}
                    transition={{ 
                      duration: 2 + i, 
                      repeat: Infinity, 
                      ease: "linear",
                      delay: i * 0.5
                    }}
                  >
                    <div 
                      className={`absolute w-2 h-2 rounded-full bg-gradient-to-r ${
                        i === 0 ? 'from-blue-400 to-blue-600' :
                        i === 1 ? 'from-purple-400 to-purple-600' :
                        'from-pink-400 to-pink-600'
                      }`}
                      style={{
                        top: `${20 + i * 5}%`,
                        left: `${20 + i * 5}%`,
                        transform: 'translate(-50%, -50%)'
                      }}
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Loading Text */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="space-y-4"
            >
              <motion.h1 
                className="text-4xl md:text-5xl font-bold"
                animate={{
                  backgroundPosition: ['0%', '100%', '0%']
                }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                style={{
                  background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)))',
                  backgroundSize: '200% 200%',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text'
                }}
              >
                STUDENTHUB.COM
              </motion.h1>
              
              <motion.p 
                className="text-lg text-foreground-secondary"
                key={loadingText}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                {loadingText}
              </motion.p>
            </motion.div>

            {/* Progress Bar */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="w-80 max-w-full space-y-4"
            >
              <div className="relative h-2 bg-white/10 rounded-full overflow-hidden backdrop-blur-sm border border-white/20">
                <motion.div
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary via-accent to-primary rounded-full"
                  initial={{ width: '0%' }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                />
                
                {/* Shimmer Effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{ x: [-200, 400] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  style={{ width: '200px' }}
                />
              </div>
              
              <div className="flex justify-between items-center text-sm">
                <span className="text-foreground-secondary">Loading...</span>
                <motion.span 
                  className="text-primary font-semibold"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                >
                  {Math.round(progress)}%
                </motion.span>
              </div>
            </motion.div>

            {/* Feature Pills */}
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.2, duration: 0.6 }}
              className="flex flex-wrap justify-center gap-3 pt-8"
            >
              {['25,000+ Papers', '30+ Tools', '3D Interface', 'AI Powered'].map((feature, index) => (
                <motion.div
                  key={feature}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 1.5 + index * 0.1, duration: 0.3 }}
                  className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 text-sm text-foreground"
                >
                  {feature}
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Bottom Decoration */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 2, duration: 0.8 }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center space-y-2"
          >
            <div className="flex items-center space-x-2 text-foreground-secondary text-sm">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span>Secure Connection</span>
            </div>
            <div className="text-xs text-foreground-secondary opacity-60">
              Powered by Advanced 3D Technology
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
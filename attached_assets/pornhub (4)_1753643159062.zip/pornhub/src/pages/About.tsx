import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/StudentHub/Header';
import { 
  BookOpen, 
  Users, 
  Globe, 
  Shield, 
  Heart, 
  Lightbulb,
  ChevronRight,
  Play,
  Pause,
  ArrowUp,
  Target,
  Star,
  Award,
  TrendingUp,
  Download,
  Languages,
  MessageCircle,
  Smartphone,
  Brain,
  ChevronDown,
  Search,
  Zap,
  Rocket,
  Trophy,
  Clock,
  MapPin,
  Mail,
  Phone,
  Calendar,
  CheckCircle,
  ArrowRight,
  Building,
  GraduationCap,
  Code,
  Database,
  Server,
  Cpu,
  Eye,
  ThumbsUp,
  Share2,
  BarChart3,
  PieChart,
  TrendingDown,
  Camera,
  Video,
  Mic,
  Headphones,
  Monitor,
  Tablet,
  Wifi,
  Cloud,
  Lock,
  Key,
  Settings,
  FileText,
  Image,
  Film,
  Music,
  Package,
  Layers,
  Grid,
  Layout,
  Palette,
  Brush,
  Sparkles,
  Diamond,
  Crown,
  CheckCircle2,
  CircuitBoard,
  Gamepad2,
  Hexagon,
  Mountain,
  Waves,
  Flame,
  Snowflake,
  Sun,
  Moon,
  Stars,
  Comet,
  Orbit,
  Atom,
  Dna,
  Binary
  Medal,
  Gift,
  Coffee,
  Briefcase,
  BookOpenCheck
} from 'lucide-react';
import { Link } from 'wouter';

const About = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isAnimationPlaying, setIsAnimationPlaying] = useState(true);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState('story');
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);
  const [selectedMilestone, setSelectedMilestone] = useState<number>(0);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const animationIdRef = useRef<number | null>(null);

  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true 
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    sceneRef.current = scene;

    // Create floating papers and books
    const geometry = new THREE.BoxGeometry(0.1, 0.15, 0.01);
    const materials = [
      new THREE.MeshBasicMaterial({ color: 0x3B82F6 }),
      new THREE.MeshBasicMaterial({ color: 0x10B981 }),
      new THREE.MeshBasicMaterial({ color: 0xF59E0B }),
      new THREE.MeshBasicMaterial({ color: 0xEF4444 }),
    ];

    const papers: THREE.Mesh[] = [];
    for (let i = 0; i < 50; i++) {
      const paper = new THREE.Mesh(geometry, materials[i % materials.length]);
      paper.position.set(
        Math.random() * 20 - 10,
        Math.random() * 20 - 10,
        Math.random() * 20 - 10
      );
      paper.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );
      scene.add(paper);
      papers.push(paper);
    }

    camera.position.z = 15;

    const animate = () => {
      if (!isAnimationPlaying) return;
      
      papers.forEach((paper, index) => {
        paper.rotation.x += 0.01;
        paper.rotation.y += 0.01;
        paper.position.y += Math.sin(Date.now() * 0.001 + index) * 0.001;
      });

      renderer.render(scene, camera);
      animationIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    const handleScroll = () => {
      setShowBackToTop(window.scrollY > window.innerHeight * 0.5);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleScroll);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
    };
  }, [isAnimationPlaying]);

  const toggleAnimation = () => {
    setIsAnimationPlaying(!isAnimationPlaying);
    if (!isAnimationPlaying && sceneRef.current) {
      const animate = () => {
        if (!isAnimationPlaying) return;
        animationIdRef.current = requestAnimationFrame(animate);
      };
      animate();
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const coreValues = [
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Accessibility",
      description: "Resources for every region and language across India, breaking down barriers to quality education."
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Accuracy",
      description: "Vetted, high-quality papers from trusted sources, verified by our expert team."
    },
    {
      icon: <Lightbulb className="w-8 h-8" />,
      title: "Innovation",
      description: "Cutting-edge 3D/AI tools and smart features for modern, interactive learning."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Community",
      description: "Strong peer support network via WhatsApp and Telegram study groups."
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Integrity",
      description: "Transparent, student-first approach with honest pricing and genuine care."
    }
  ];

  const offerings = [
    {
      title: "Extensive PYQ Library",
      description: "25,000+ Previous Year Question Papers covering all major competitive exams",
      icon: <BookOpen className="w-6 h-6" />,
      features: ["NEET, JEE, UPSC, SSC", "State Board Exams", "University Papers"]
    },
    {
      title: "Smart File Tools",
      description: "AI-powered conversion tools for all your academic needs",
      icon: <Lightbulb className="w-6 h-6" />,
      features: ["PDF↔Word Converter", "Image Resizer & OCR", "PPT↔PDF Tools"]
    },
    {
      title: "Multi-Language Support",
      description: "Content available in 22+ regional languages",
      icon: <Languages className="w-6 h-6" />,
      features: ["Hindi, English, Tamil", "Bengali, Telugu, Marathi", "And 16+ more languages"]
    },
    {
      title: "Vibrant Community",
      description: "Active study groups and peer support networks",
      icon: <MessageCircle className="w-6 h-6" />,
      features: ["WhatsApp Study Groups", "Telegram Channels", "Student Forums"]
    },
    {
      title: "Mobile App & AI Features",
      description: "Next-generation mobile experience with AI recommendations",
      icon: <Smartphone className="w-6 h-6" />,
      features: ["Smart Recommendations", "Offline Study Mode", "Progress Tracking"]
    }
  ];

  const milestones = [
    { 
      year: "2022", 
      event: "StudentHub launched with 1,000 question papers and big dreams",
      stats: "1K Papers • 10K Users"
    },
    { 
      year: "2023", 
      event: "Major growth milestone - reached 10,000+ papers and 50M users",
      stats: "10K Papers • 50M Users"
    },
    { 
      year: "2024", 
      event: "Introduced smart conversion tools and expanded to 22 languages",
      stats: "20K Papers • 120M Users • 22 Languages"
    },
    { 
      year: "2025", 
      event: "Achieved 170M users milestone and launched AI-powered features",
      stats: "25K Papers • 170M Users • AI Features"
    }
  ];

  const team = [
    {
      name: "Dr. Ananya Sharma",
      role: "Founder & CEO",
      quote: "Education should be accessible to everyone, everywhere.",
      expertise: "Educational Technology, 15+ years"
    },
    {
      name: "Rajesh Kumar",
      role: "Chief Technology Officer",
      quote: "Technology can revolutionize how students learn.",
      expertise: "AI/ML, Full-Stack Development"
    },
    {
      name: "Priya Patel",
      role: "Head of Content & Academics",
      quote: "Quality content is the foundation of great education.",
      expertise: "Curriculum Design, Academic Research"
    },
    {
      name: "Amit Singh",
      role: "Community & Growth Manager",
      quote: "Building bridges between students across India.",
      expertise: "Community Building, Digital Marketing"
    },
    {
      name: "Dr. Kavya Nair",
      role: "Head of Quality Assurance",
      quote: "Every paper we upload can change a student's future.",
      expertise: "Educational Assessment, Quality Control"
    },
    {
      name: "Vikash Yadav",
      role: "Student Success Manager",
      quote: "Students succeed when they have the right tools and support.",
      expertise: "Student Psychology, Success Coaching"
    }
  ];

  const testimonials = [
    {
      name: "Rahul Verma",
      exam: "JEE Main 2024 - AIR 2,847",
      quote: "StudentHub's organized PYQs and practice tests were game-changers. The 3D tools helped me visualize complex physics problems!",
      location: "Mumbai, Maharashtra"
    },
    {
      name: "Sneha Agarwal",
      exam: "NEET 2024 - AIR 1,245",
      quote: "The multi-language support was incredible. I could study biology in both English and Hindi, which really helped my understanding.",
      location: "Jaipur, Rajasthan"
    },
    {
      name: "Arjun Kumar",
      exam: "UPSC CSE 2023 - Rank 67",
      quote: "The community support and comprehensive material collection saved me thousands of rupees and months of preparation time.",
      location: "Delhi"
    },
    {
      name: "Meera Krishnan",
      exam: "CA Foundation 2024",
      quote: "File conversion tools were a lifesaver! Converting PDFs to Word for note-making became so easy.",
      location: "Chennai, Tamil Nadu"
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: "Browse & Search",
      description: "Navigate through our organized categories or use smart search to find exactly what you need",
      icon: <Search className="w-8 h-8" />
    },
    {
      step: 2,
      title: "Download & Convert",
      description: "Download high-quality PDFs instantly, or use our tools to convert to your preferred format",
      icon: <Download className="w-8 h-8" />
    },
    {
      step: 3,
      title: "Practice & Share",
      description: "Study with our materials, join community discussions, and share your success stories",
      icon: <Users className="w-8 h-8" />
    }
  ];

  // Enhanced detailed data
  const detailedFeatures = [
    {
      category: "Academic Content",
      icon: <BookOpenCheck className="w-8 h-8" />,
      items: [
        "25,000+ Question Papers covering all competitive exams",
        "Authentic previous year papers from NEET, JEE, UPSC, SSC, CDS, NDA",
        "State board question papers for all classes (9-12)",
        "University question papers from top institutions",
        "Mock tests and practice papers with detailed solutions",
        "Subject-wise categorization for easy navigation",
        "Difficulty level sorting (Easy, Medium, Hard)",
        "Topic-wise question banks for focused study"
      ]
    },
    {
      category: "AI & Technology",
      icon: <Brain className="w-8 h-8" />,
      items: [
        "Advanced AI-powered study recommendations",
        "Intelligent content matching based on study patterns",
        "ML-based difficulty assessment and progression tracking",
        "Smart search with natural language processing",
        "OCR technology for image-to-text conversion",
        "Auto-translation across 22+ Indian languages",
        "Pattern recognition for handwritten notes",
        "Predictive analytics for exam preparation"
      ]
    },
    {
      category: "File Processing Tools",
      icon: <Settings className="w-8 h-8" />,
      items: [
        "PDF to Word converter with 99% accuracy",
        "Word to PDF with layout preservation",
        "PDF to PowerPoint with slide optimization",
        "Image format converter (JPG, PNG, WebP, TIFF)",
        "Image compression without quality loss",
        "Image resizing with intelligent cropping",
        "OCR extraction from scanned documents",
        "Batch processing for multiple files"
      ]
    },
    {
      category: "Community & Support",
      icon: <Users className="w-8 h-8" />,
      items: [
        "WhatsApp study groups for each exam type",
        "Telegram channels with daily updates",
        "Peer-to-peer doubt solving forums",
        "Expert mentorship programs",
        "Live Q&A sessions with toppers",
        "Study group formation based on location",
        "Success story sharing platform",
        "24/7 technical support chat"
      ]
    }
  ];

  const technicalSpecs = [
    {
      title: "Infrastructure & Performance",
      specs: [
        "99.9% uptime with global CDN",
        "Sub-second search response time",
        "Multi-region data centers",
        "Auto-scaling server architecture",
        "SSL encryption for all data",
        "GDPR compliant data handling"
      ]
    },
    {
      title: "Mobile & Cross-Platform",
      specs: [
        "Progressive Web App (PWA) support",
        "Offline content synchronization",
        "Cross-device study progress sync",
        "Native iOS and Android apps",
        "Responsive design for all screen sizes",
        "Touch-optimized interface"
      ]
    },
    {
      title: "Accessibility Features",
      specs: [
        "Screen reader compatibility",
        "Voice navigation support",
        "High contrast mode",
        "Font size adjustment",
        "Keyboard navigation",
        "Multi-language interface"
      ]
    }
  ];

  const partnershipInfo = [
    {
      name: "Educational Institutions",
      count: "500+",
      description: "Partnerships with top schools, colleges, and universities across India for authentic content sourcing.",
      examples: ["IITs", "NITs", "Central Universities", "State Boards", "CBSE", "ICSE"]
    },
    {
      name: "Coaching Institutes",
      count: "200+",
      description: "Collaborations with leading coaching centers for quality study materials and expert insights.",
      examples: ["Physics Wallah", "Unacademy", "BYJU'S", "Allen", "Aakash", "Resonance"]
    },
    {
      name: "Technology Partners",
      count: "50+",
      description: "Strategic partnerships with tech companies for advanced features and infrastructure.",
      examples: ["Google Cloud", "AWS", "Microsoft Azure", "OpenAI", "Gemini AI", "Cloudflare"]
    }
  ];

  const impactMetrics = [
    { metric: "Papers Downloaded", value: "50M+", trend: "+25%", description: "Total question papers downloaded by students" },
    { metric: "Study Hours Saved", value: "2.5M+", trend: "+40%", description: "Collective hours saved through efficient resource access" },
    { metric: "Success Rate", value: "87%", trend: "+12%", description: "Students reporting improved exam performance" },
    { metric: "Money Saved", value: "₹500Cr+", trend: "+30%", description: "Total savings on expensive study materials" },
    { metric: "Carbon Footprint", value: "-75%", trend: "Reduced", description: "Environmental impact reduction through digital resources" },
    { metric: "Rural Reach", value: "60%", trend: "+18%", description: "Users from tier-2 and tier-3 cities" }
  ];

  const futurePlans = [
    {
      quarter: "Q1 2025",
      title: "Mobile App Launch",
      status: "In Development",
      features: ["iOS & Android native apps", "Offline study mode", "Push notifications", "Biometric security"]
    },
    {
      quarter: "Q2 2025",
      title: "AI Study Assistant",
      status: "Research Phase",
      features: ["Personalized study plans", "Adaptive learning paths", "Performance prediction", "Smart reminders"]
    },
    {
      quarter: "Q3 2025",
      title: "Virtual Classrooms",
      status: "Planning",
      features: ["Live doubt sessions", "Group study rooms", "Interactive whiteboards", "Recording capabilities"]
    },
    {
      quarter: "Q4 2025",
      title: "Global Expansion",
      status: "Strategic Planning",
      features: ["International content", "Multi-currency support", "Regional partnerships", "Local language support"]
    }
  ];

  const qualityAssurance = [
    {
      process: "Content Verification",
      description: "Multi-level verification process ensuring 100% authentic question papers",
      steps: ["Source authentication", "Expert review", "Cross-reference check", "Quality scoring"]
    },
    {
      process: "User Experience Testing",
      description: "Continuous testing with real students to optimize platform usability",
      steps: ["A/B testing", "User feedback collection", "Performance monitoring", "Accessibility audits"]
    },
    {
      process: "Security & Privacy",
      description: "Robust security measures protecting user data and ensuring platform integrity",
      steps: ["Encryption protocols", "Regular security audits", "Privacy compliance", "Data backup systems"]
    }
  ];

  const roadmapItems = [
    "Mobile App Launch (iOS & Android)",
    "AI-Powered Study Recommendations",
    "Offline Content Packages",
    "Virtual Study Rooms",
    "Live Doubt Solving Sessions",
    "Partnerships with Top Coaching Institutes",
    "Advanced Analytics Dashboard",
    "Multilingual Voice Search"
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Header Navigation */}
      <Header />
      
      {/* 3D Canvas Background */}
      <canvas 
        ref={canvasRef} 
        className="fixed inset-0 -z-10"
        style={{ pointerEvents: 'none' }}
      />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="text-center space-y-8 animate-fadeInUp">
          <div className="space-y-4">
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              About StudentHub.com
            </h1>
            <p className="text-xl md:text-2xl text-foreground-secondary max-w-3xl mx-auto">
              Empowering Every Student—from Class 9 to PhD
            </p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-8 text-center">
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary animate-bounce">25,000+</div>
              <div className="text-sm text-foreground-secondary">Question Papers</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary animate-bounce" style={{animationDelay: '0.1s'}}>170M+</div>
              <div className="text-sm text-foreground-secondary">Users</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary animate-bounce" style={{animationDelay: '0.2s'}}>22+</div>
              <div className="text-sm text-foreground-secondary">Languages</div>
            </div>
          </div>

          <Button 
            onClick={toggleAnimation}
            variant="outline"
            className="mt-8 group"
          >
            {isAnimationPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isAnimationPlaying ? 'Pause' : 'Play'} 3D Animation
          </Button>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Our Story</h2>
          <div className="space-y-6 text-lg text-foreground-secondary leading-relaxed">
            <p className="animate-fadeInUp" style={{ animationDelay: '0.1s' }}>
              <strong>StudentHub was born from a simple observation:</strong> students across India were struggling to find quality previous year papers and study materials. In 2022, a group of passionate educators and technologists came together to solve this fundamental problem in Indian education. What started as late-night conversations about the digital divide in education became a mission to democratize academic resources.
            </p>
            <p className="animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
              <strong>The core problem was clear:</strong> students in tier-2 and tier-3 cities had limited access to quality study materials, especially previous year question papers. Many were paying hefty amounts for outdated or incomplete resources. Our founders realized that technology could bridge this gap, making premium educational content accessible to every student, regardless of their location or economic background.
            </p>
            <p className="animate-fadeInUp" style={{ animationDelay: '0.3s' }}>
              <strong>The "aha moment" came</strong> when our team met Rajesh, a student from rural Bihar who traveled 200km just to access question papers for JEE preparation. His dedication inspired us to create a platform that would bring quality education resources directly to students' fingertips. Today, students like Rajesh can access world-class materials from anywhere in India, and that's what drives us every day.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision Cards */}
      <section className="py-20 px-4 bg-background-secondary">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="h-80 cursor-pointer group perspective-1000">
              <div className="relative w-full h-full preserve-3d group-hover:rotate-y-180 transition-transform duration-700">
                <CardContent className="absolute inset-0 flex items-center justify-center backface-hidden p-8">
                  <div className="text-center">
                    <Target className="w-12 h-12 text-primary mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
                    <p className="text-foreground-secondary">
                      To democratize exam preparation by providing free and premium question papers, smart file conversion tools, and vibrant community support for every Indian student.
                    </p>
                  </div>
                </CardContent>
                <CardContent className="absolute inset-0 flex items-center justify-center backface-hidden rotate-y-180 p-8 bg-primary text-primary-foreground">
                  <div className="text-center">
                    <Star className="w-12 h-12 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-4">How We Achieve This</h3>
                    <p>
                      Through cutting-edge 3D technology, AI-powered tools, strategic partnerships with educators, and an unwavering student-first approach to everything we build and deliver.
                    </p>
                  </div>
                </CardContent>
              </div>
            </Card>

            <Card className="h-80 cursor-pointer group perspective-1000">
              <div className="relative w-full h-full preserve-3d group-hover:rotate-y-180 transition-transform duration-700">
                <CardContent className="absolute inset-0 flex items-center justify-center backface-hidden p-8">
                  <div className="text-center">
                    <TrendingUp className="w-12 h-12 text-secondary mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
                    <p className="text-foreground-secondary">
                      To become India's ultimate one-stop hub for academic resources and study utilities, transforming how students learn and succeed.
                    </p>
                  </div>
                </CardContent>
                <CardContent className="absolute inset-0 flex items-center justify-center backface-hidden rotate-y-180 p-8 bg-secondary text-secondary-foreground">
                  <div className="text-center">
                    <Award className="w-12 h-12 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold mb-4">Our Impact</h3>
                    <p>
                      Empowering 170 million students across India to access quality education, save money on resources, and achieve their academic dreams with confidence and community support.
                    </p>
                  </div>
                </CardContent>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Core Values</h2>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
            {coreValues.map((value, index) => (
              <Card 
                key={value.title} 
                className="text-center p-6 hover:scale-105 hover:shadow-glow transition-all duration-300 cursor-pointer group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="space-y-4">
                  <div className="text-primary group-hover:scale-110 group-hover:animate-pulse transition-transform duration-300">
                    {value.icon}
                  </div>
                  <h3 className="font-semibold text-lg">{value.title}</h3>
                  <p className="text-sm text-foreground-secondary">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-20 px-4 bg-background-secondary">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">What We Offer</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {offerings.map((offering, index) => (
              <Card 
                key={offering.title}
                className="group hover:shadow-glow hover:scale-105 transition-all duration-300 cursor-pointer"
              >
                <CardContent className="p-6 space-y-4">
                  <div className="text-primary group-hover:scale-110 transition-transform duration-300">
                    {offering.icon}
                  </div>
                  <h3 className="font-semibold text-lg">{offering.title}</h3>
                  <p className="text-foreground-secondary">{offering.description}</p>
                  <ul className="text-sm text-foreground-secondary space-y-1">
                    {offering.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center">
                        <ChevronRight className="w-3 h-3 mr-2 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button variant="ghost" size="sm" className="group-hover:translate-x-2 transition-transform duration-300">
                    Learn More <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Key Milestones</h2>
          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <div 
                key={milestone.year}
                className="flex items-center space-x-6 group hover:scale-105 transition-transform duration-300"
              >
                <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-lg shadow-glow">
                  {milestone.year}
                </div>
                <div className="flex-1 p-6 bg-card rounded-xl group-hover:shadow-lg transition-shadow duration-300 border border-border/20">
                  <p className="text-lg font-medium mb-2">{milestone.event}</p>
                  <p className="text-sm text-primary font-semibold">{milestone.stats}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 px-4 bg-background-secondary">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Meet Our Team</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.map((member, index) => (
              <Card 
                key={member.name}
                className="text-center group hover:scale-105 hover:shadow-glow transition-all duration-300 cursor-pointer"
              >
                <CardContent className="p-6 space-y-4">
                  <div className="w-24 h-24 bg-gradient-primary rounded-full mx-auto flex items-center justify-center text-2xl font-bold text-primary-foreground">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{member.name}</h3>
                    <p className="text-primary text-sm font-medium">{member.role}</p>
                    <p className="text-xs text-foreground-secondary mt-1">{member.expertise}</p>
                  </div>
                  <p className="text-sm text-foreground-secondary italic">"{member.quote}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Student Success Stories</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card 
                key={testimonial.name}
                className="hover:shadow-glow hover:scale-105 transition-all duration-300"
              >
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center space-x-2">
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  </div>
                  <p className="text-foreground-secondary italic">"{testimonial.quote}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-primary text-sm font-medium">{testimonial.exam}</p>
                    <p className="text-xs text-foreground-secondary">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 bg-background-secondary">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-text">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {howItWorks.map((step, index) => (
              <div key={step.step} className="text-center space-y-4 group">
                <div className="relative">
                  <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-glow mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    {step.step}
                  </div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-primary group-hover:scale-110 transition-transform duration-300">
                    {step.icon}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-foreground">{step.title}</h3>
                <p className="text-foreground-secondary leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent"
          >
            Comprehensive Platform Features
          </motion.h2>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {detailedFeatures.map((feature, index) => (
              <motion.div
                key={feature.category}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="group"
              >
                <Card className="h-full hover:shadow-2xl hover:shadow-blue-500/20 transition-all duration-500 border-2 hover:border-blue-500/50">
                  <CardContent className="p-8">
                    <div className="flex items-center space-x-4 mb-6">
                      <motion.div 
                        whileHover={{ rotate: 360, scale: 1.1 }}
                        transition={{ duration: 0.6 }}
                        className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white shadow-lg"
                      >
                        {feature.icon}
                      </motion.div>
                      <h3 className="text-2xl font-bold text-foreground group-hover:text-blue-400 transition-colors duration-300">
                        {feature.category}
                      </h3>
                    </div>
                    
                    <div className="space-y-3">
                      {feature.items.map((item, itemIndex) => (
                        <motion.div
                          key={itemIndex}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: itemIndex * 0.05 }}
                          className="flex items-start space-x-3 group/item"
                        >
                          <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0 group-hover/item:scale-110 transition-transform duration-200" />
                          <span className="text-foreground-secondary group-hover/item:text-foreground transition-colors duration-200">
                            {item}
                          </span>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-20 px-4 bg-gradient-to-br from-slate-900/50 to-purple-900/20">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Technical Excellence & Infrastructure
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {technicalSpecs.map((spec, index) => (
              <motion.div
                key={spec.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -10 }}
              >
                <Card className="h-full bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600/50 hover:border-blue-500/50 transition-all duration-500">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 text-blue-400">{spec.title}</h3>
                    <div className="space-y-3">
                      {spec.specs.map((item, idx) => (
                        <div key={idx} className="flex items-center space-x-3">
                          <Zap className="w-4 h-4 text-yellow-400" />
                          <span className="text-sm text-gray-300">{item}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Information */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Strategic Partnerships & Collaborations
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {partnershipInfo.map((partnership, index) => (
              <motion.div
                key={partnership.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card className="text-center hover:shadow-2xl transition-all duration-500">
                  <CardContent className="p-8">
                    <motion.div 
                      whileHover={{ rotate: 10 }}
                      className="text-6xl font-bold text-primary mb-4"
                    >
                      {partnership.count}
                    </motion.div>
                    <h3 className="text-xl font-bold mb-4">{partnership.name}</h3>
                    <p className="text-foreground-secondary mb-6">{partnership.description}</p>
                    
                    <div className="flex flex-wrap gap-2 justify-center">
                      {partnership.examples.map((example, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {example}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Metrics */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-900/20 to-purple-900/20">
        <div className="max-w-7xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Our Impact & Achievements
          </motion.h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {impactMetrics.map((impact, index) => (
              <motion.div
                key={impact.metric}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, rotateY: 5 }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <Card className="h-full bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg border-white/20 hover:border-blue-400/50 transition-all duration-500">
                  <CardContent className="p-6 text-center">
                    <motion.div 
                      whileHover={{ scale: 1.2 }}
                      className="text-4xl font-bold text-blue-400 mb-2"
                    >
                      {impact.value}
                    </motion.div>
                    
                    <div className="flex items-center justify-center space-x-2 mb-3">
                      <h3 className="font-semibold text-foreground">{impact.metric}</h3>
                      <Badge 
                        variant={impact.trend.includes('-') ? 'destructive' : 'default'}
                        className="text-xs"
                      >
                        {impact.trend}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-foreground-secondary">{impact.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Future Roadmap with Detailed Plans */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            2025 Roadmap & Future Plans
          </motion.h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {futurePlans.map((plan, index) => (
              <motion.div
                key={plan.quarter}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-500 border-l-4 border-l-blue-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="outline" className="font-semibold">
                        {plan.quarter}
                      </Badge>
                      <Badge 
                        variant={plan.status === 'In Development' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {plan.status}
                      </Badge>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-4 text-foreground">{plan.title}</h3>
                    
                    <div className="space-y-2">
                      {plan.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-3">
                          <Rocket className="w-4 h-4 text-blue-500" />
                          <span className="text-sm text-foreground-secondary">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Assurance Processes */}
      <section className="py-20 px-4 bg-gradient-to-br from-slate-900/30 to-blue-900/20">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Quality Assurance & Standards
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {qualityAssurance.map((qa, index) => (
              <motion.div
                key={qa.process}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -5 }}
              >
                <Card className="h-full bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-lg border-white/20 hover:border-green-400/50 transition-all duration-500">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <Shield className="w-8 h-8 text-green-500" />
                      <h3 className="text-lg font-bold text-foreground">{qa.process}</h3>
                    </div>
                    
                    <p className="text-foreground-secondary mb-6">{qa.description}</p>
                    
                    <div className="space-y-2">
                      {qa.steps.map((step, idx) => (
                        <div key={idx} className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                            {idx + 1}
                          </div>
                          <span className="text-sm text-foreground-secondary">{step}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Extensive Academic Coverage Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Complete Academic Ecosystem
          </motion.h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                title: "Class 9-12 Boards", 
                count: "5,000+", 
                icon: <GraduationCap className="w-8 h-8" />,
                subjects: ["Physics", "Chemistry", "Mathematics", "Biology", "Computer Science", "English", "Hindi", "Social Science"],
                boards: ["CBSE", "ICSE", "State Boards", "International Boards"]
              },
              { 
                title: "Engineering Entrance", 
                count: "8,000+", 
                icon: <Code className="w-8 h-8" />,
                subjects: ["JEE Main", "JEE Advanced", "BITSAT", "VITEEE", "SRMJEEE", "COMEDK", "MHT CET", "KCET"],
                boards: ["Physics", "Chemistry", "Mathematics", "Previous Years"]
              },
              { 
                title: "Medical Entrance", 
                count: "6,000+", 
                icon: <Heart className="w-8 h-8" />,
                subjects: ["NEET UG", "NEET PG", "AIIMS", "JIPMER", "State NEET", "MBBS", "BDS", "AYUSH"],
                boards: ["Physics", "Chemistry", "Biology", "Previous Years"]
              },
              { 
                title: "Competitive Exams", 
                count: "6,000+", 
                icon: <Trophy className="w-8 h-8" />,
                subjects: ["UPSC", "SSC", "Banking", "Railway", "Defence", "State PSC", "Teaching", "Insurance"],
                boards: ["GK", "Reasoning", "Quantitative", "English"]
              }
            ].map((category, index) => (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, rotateY: 5 }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <Card className="h-full hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-lg border-white/20">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <motion.div 
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                        className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white"
                      >
                        {category.icon}
                      </motion.div>
                      <div>
                        <h3 className="font-bold text-lg text-foreground">{category.title}</h3>
                        <Badge className="mt-1">{category.count} Papers</Badge>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold text-sm text-primary mb-2">Subjects/Exams:</h4>
                        <div className="flex flex-wrap gap-1">
                          {category.subjects.map((subject, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {subject}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-sm text-primary mb-2">Coverage:</h4>
                        <div className="flex flex-wrap gap-1">
                          {category.boards.map((board, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {board}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Advanced Technology Stack */}
      <section className="py-20 px-4 bg-gradient-to-br from-slate-900/30 to-blue-900/20">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Cutting-Edge Technology Infrastructure
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                category: "Frontend Technologies",
                icon: <Monitor className="w-8 h-8" />,
                technologies: [
                  "React 18 with TypeScript",
                  "Tailwind CSS for styling",
                  "Framer Motion animations",
                  "Three.js for 3D graphics",
                  "Radix UI components",
                  "Wouter for routing",
                  "TanStack Query for state",
                  "Vite for fast builds"
                ]
              },
              {
                category: "Backend Infrastructure",
                icon: <Server className="w-8 h-8" />,
                technologies: [
                  "Node.js with Express",
                  "PostgreSQL database",
                  "Drizzle ORM",
                  "Python for AI processing",
                  "Flask for microservices",
                  "Redis for caching",
                  "Docker containers",
                  "Nginx load balancer"
                ]
              },
              {
                category: "AI & Processing",
                icon: <Cpu className="w-8 h-8" />,
                technologies: [
                  "OpenAI GPT-4 integration",
                  "Google Gemini AI",
                  "Tesseract OCR engine",
                  "PyMuPDF for documents",
                  "Sharp for images",
                  "Natural language processing",
                  "Machine learning models",
                  "Computer vision APIs"
                ]
              }
            ].map((tech, index) => (
              <motion.div
                key={tech.category}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -10 }}
              >
                <Card className="h-full bg-gradient-to-br from-slate-800/50 to-slate-700/30 border-slate-600/50 hover:border-blue-500/50 transition-all duration-500">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-6">
                      <motion.div 
                        whileHover={{ scale: 1.2, rotate: 10 }}
                        className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white"
                      >
                        {tech.icon}
                      </motion.div>
                      <h3 className="text-xl font-bold text-blue-400">{tech.category}</h3>
                    </div>
                    
                    <div className="space-y-3">
                      {tech.technologies.map((item, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="flex items-center space-x-3"
                        >
                          <Zap className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                          <span className="text-sm text-gray-300">{item}</span>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* User Experience & Accessibility */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-center mb-16 gradient-text"
          >
            Exceptional User Experience Design
          </motion.h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Responsive Design",
                description: "Perfect experience across all devices",
                features: ["Mobile-first approach", "Tablet optimization", "Desktop enhancement", "Touch-friendly interface"],
                icon: <Tablet className="w-8 h-8" />
              },
              {
                title: "Performance Optimized",
                description: "Lightning-fast loading and interactions",
                features: ["Sub-second load times", "Lazy loading images", "Code splitting", "CDN acceleration"],
                icon: <Zap className="w-8 h-8" />
              },
              {
                title: "Accessibility Standards",
                description: "Inclusive design for all users",
                features: ["WCAG 2.1 compliance", "Screen reader support", "Keyboard navigation", "Color contrast"],
                icon: <Eye className="w-8 h-8" />
              },
              {
                title: "Multi-language Support",
                description: "Available in 22+ Indian languages",
                features: ["Hindi interface", "Regional content", "Auto-translation", "Cultural adaptation"],
                icon: <Languages className="w-8 h-8" />
              },
              {
                title: "Advanced Search",
                description: "AI-powered intelligent search",
                features: ["Natural language queries", "Smart suggestions", "Filter combinations", "Result ranking"],
                icon: <Search className="w-8 h-8" />
              },
              {
                title: "Community Features",
                description: "Connected learning ecosystem",
                features: ["Study groups", "Peer discussions", "Expert mentoring", "Progress sharing"],
                icon: <Users className="w-8 h-8" />
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, rotateY: 5 }}
                onHoverStart={() => setHoveredFeature(index)}
                onHoverEnd={() => setHoveredFeature(null)}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <Card className={`h-full transition-all duration-500 ${hoveredFeature === index ? 'shadow-2xl shadow-blue-500/20 border-blue-500/50' : 'hover:shadow-xl'}`}>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <motion.div 
                        animate={{ rotate: hoveredFeature === index ? 360 : 0 }}
                        transition={{ duration: 0.6 }}
                        className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl text-white"
                      >
                        {feature.icon}
                      </motion.div>
                      <div>
                        <h3 className="font-bold text-lg text-foreground">{feature.title}</h3>
                      </div>
                    </div>
                    
                    <p className="text-foreground-secondary mb-4">{feature.description}</p>
                    
                    <div className="space-y-2">
                      {feature.features.map((item, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="flex items-center space-x-2"
                        >
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-foreground-secondary">{item}</span>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-background-secondary">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold gradient-text mb-8"
          >
            Ready to Transform Your Study Experience?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-foreground-secondary mb-8"
          >
            Join millions of students who are already using StudentHub to achieve their academic goals.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/">
              <Button size="lg" className="btn-hero group">
                <BookOpen className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-300" />
                Explore Our Library
              </Button>
            </Link>
            <Link to="/tools">
              <Button size="lg" variant="outline" className="group">
                <Lightbulb className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-300" />
                Try Our Tools
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Back to Top Button */}
      {showBackToTop && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 rounded-full w-12 h-12 shadow-glow z-50"
          size="icon"
        >
          <ArrowUp className="w-5 h-5" />
        </Button>
      )}
    </div>
  );
};

export default About;
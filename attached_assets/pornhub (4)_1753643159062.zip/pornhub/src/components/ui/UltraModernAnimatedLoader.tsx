import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as THREE from 'three';

interface UltraModernAnimatedLoaderProps {
  onComplete: () => void;
}

export const UltraModernAnimatedLoader: React.FC<UltraModernAnimatedLoaderProps> = ({ onComplete }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Initializing StudentHub...');
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationIdRef = useRef<number | null>(null);

  const loadingMessages = [
    'Initializing StudentHub...',
    'Loading Educational Tools...',
    'Preparing 3D Animations...',
    'Setting Up Learning Environment...',
    'Loading Past Year Questions...',
    'Optimizing User Experience...',
    'Almost Ready...',
    'Welcome to StudentHub!'
  ];

  useEffect(() => {
    if (!canvasRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current, 
      antialias: false,
      alpha: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    sceneRef.current = scene;
    rendererRef.current = renderer;

    // Create animated logo geometry
    const logoGroup = new THREE.Group();
    
    // Central hub
    const hubGeometry = new THREE.IcosahedronGeometry(0.8, 1);
    const hubMaterial = new THREE.MeshBasicMaterial({ 
      color: 0x3B82F6,
      wireframe: true,
      transparent: true,
      opacity: 0.8
    });
    const hub = new THREE.Mesh(hubGeometry, hubMaterial);
    logoGroup.add(hub);

    // Orbiting particles
    const particles = [];
    const particleGeometry = new THREE.SphereGeometry(0.05, 8, 8);
    for (let i = 0; i < 20; i++) {
      const material = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL(i / 20, 0.8, 0.6) 
      });
      const particle = new THREE.Mesh(particleGeometry, material);
      const radius = 2 + Math.random() * 1;
      particle.position.set(
        Math.cos(i * 0.314) * radius,
        Math.sin(i * 0.314) * radius * 0.5,
        Math.sin(i * 0.628) * radius
      );
      particles.push({ mesh: particle, radius, angle: i * 0.314 });
      logoGroup.add(particle);
    }

    // Knowledge books floating around
    const bookGeometry = new THREE.BoxGeometry(0.2, 0.3, 0.05);
    const books = [];
    const bookColors = [0x10B981, 0xF59E0B, 0xEF4444, 0x8B5CF6, 0xF97316];
    
    for (let i = 0; i < 15; i++) {
      const bookMaterial = new THREE.MeshBasicMaterial({ 
        color: bookColors[i % bookColors.length],
        transparent: true,
        opacity: 0.7
      });
      const book = new THREE.Mesh(bookGeometry, bookMaterial);
      const radius = 3 + Math.random() * 2;
      book.position.set(
        Math.cos(i * 0.4) * radius,
        (Math.random() - 0.5) * 4,
        Math.sin(i * 0.4) * radius
      );
      book.rotation.set(
        Math.random() * Math.PI,
        Math.random() * Math.PI,
        Math.random() * Math.PI
      );
      books.push({ mesh: book, initialY: book.position.y, phase: Math.random() * Math.PI * 2 });
      logoGroup.add(book);
    }

    scene.add(logoGroup);
    camera.position.z = 8;

    // Animation loop
    const animate = () => {
      const time = Date.now() * 0.001;
      
      // Rotate central hub
      hub.rotation.x += 0.01;
      hub.rotation.y += 0.02;
      
      // Animate particles
      particles.forEach((particle, index) => {
        particle.angle += 0.02;
        particle.mesh.position.x = Math.cos(particle.angle) * particle.radius;
        particle.mesh.position.z = Math.sin(particle.angle) * particle.radius;
        particle.mesh.position.y = Math.sin(time * 2 + index) * 0.5;
        particle.mesh.rotation.x += 0.03;
        particle.mesh.rotation.y += 0.02;
      });
      
      // Animate books
      books.forEach((book, index) => {
        book.mesh.position.y = book.initialY + Math.sin(time + book.phase) * 0.3;
        book.mesh.rotation.x += 0.01;
        book.mesh.rotation.y += 0.015;
        book.mesh.rotation.z += 0.005;
      });
      
      // Rotate entire logo group
      logoGroup.rotation.y += 0.005;
      
      renderer.render(scene, camera);
      animationIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Progress simulation
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 15;
        if (newProgress >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => {
            onComplete();
          }, 1000);
          return 100;
        }
        
        // Update loading text based on progress
        const messageIndex = Math.floor((newProgress / 100) * loadingMessages.length);
        setLoadingText(loadingMessages[Math.min(messageIndex, loadingMessages.length - 1)]);
        
        return newProgress;
      });
    }, 150);

    // Cleanup
    return () => {
      clearInterval(progressInterval);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900"
      >
        {/* Animated background particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(50)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-blue-400 rounded-full opacity-60"
              initial={{
                x: Math.random() * window.innerWidth,
                y: Math.random() * window.innerHeight,
              }}
              animate={{
                x: Math.random() * window.innerWidth,
                y: Math.random() * window.innerHeight,
              }}
              transition={{
                duration: Math.random() * 10 + 10,
                repeat: Infinity,
                ease: "linear"
              }}
            />
          ))}
        </div>

        {/* 3D Scene Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          style={{ pointerEvents: 'none' }}
        />

        {/* Loading Content */}
        <div className="relative z-10 text-center space-y-8">
          {/* Logo Text */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-4"
          >
            <motion.h1 
              className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-cyan-400 bg-clip-text text-transparent"
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear"
              }}
              style={{
                backgroundSize: '200% 200%'
              }}
            >
              StudentHub
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl text-blue-200 font-light tracking-wide"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              Your Ultimate Learning Companion
            </motion.p>
          </motion.div>

          {/* Progress Section */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="space-y-6 w-80 mx-auto"
          >
            {/* Progress Bar */}
            <div className="relative">
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full relative"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Animated shine effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30"
                    animate={{ x: ['-100%', '100%'] }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                  />
                </motion.div>
              </div>
              
              {/* Progress percentage */}
              <motion.div 
                className="absolute -top-8 right-0 text-sm text-blue-300 font-medium"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                {Math.round(progress)}%
              </motion.div>
            </div>

            {/* Loading text */}
            <motion.p
              className="text-blue-200 text-lg font-medium"
              key={loadingText}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {loadingText}
            </motion.p>

            {/* Loading dots animation */}
            <div className="flex justify-center space-x-2">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-3 h-3 bg-blue-400 rounded-full"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    delay: i * 0.2,
                  }}
                />
              ))}
            </div>
          </motion.div>

          {/* Feature highlights */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1.2 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-blue-200 text-sm"
          >
            <div className="space-y-2">
              <div className="text-2xl">📚</div>
              <div>25,000+ PYQs</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl">🔧</div>
              <div>30+ Tools</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl">📰</div>
              <div>Latest News</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl">🎯</div>
              <div>AI Powered</div>
            </div>
          </motion.div>
        </div>

        {/* Bottom sparkle effect */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2">
          <motion.div
            className="flex space-x-1"
            animate={{
              rotate: [0, 360],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="w-2 h-2 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.1,
                }}
              />
            ))}
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default UltraModernAnimatedLoader;
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as THREE from 'three';
import { 
  BookOpen, 
  Brain, 
  Zap, 
  Sparkles, 
  Rocket,
  Trophy,
  Target,
  Star
} from 'lucide-react';

interface UltraModernLoaderProps {
  isVisible: boolean;
  onComplete: () => void;
}

export const UltraModernLoader: React.FC<UltraModernLoaderProps> = ({ 
  isVisible, 
  onComplete 
}) => {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Initializing StudentHub...');
  const [showContent, setShowContent] = useState(false);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  const loadingSteps = [
    { progress: 20, text: 'Loading 25,000+ Question Papers...' },
    { progress: 40, text: 'Initializing AI Tools...' },
    { progress: 60, text: 'Setting up 3D Graphics...' },
    { progress: 80, text: 'Connecting to Database...' },
    { progress: 95, text: 'Finalizing Experience...' },
    { progress: 100, text: 'Welcome to StudentHub!' }
  ];

  useEffect(() => {
    if (!isVisible) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current!,
      alpha: true,
      antialias: false
    });

    renderer.setSize(300, 300);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Create animated geometry
    const geometry = new THREE.IcosahedronGeometry(2, 1);
    const material = new THREE.MeshBasicMaterial({
      color: 0x3b82f6,
      wireframe: true,
      transparent: true,
      opacity: 0.8
    });
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Add particles
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 100;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i++) {
      positions[i] = (Math.random() - 0.5) * 10;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMaterial = new THREE.PointsMaterial({
      color: 0x60a5fa,
      size: 0.05,
      transparent: true,
      opacity: 0.6
    });
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    camera.position.z = 5;

    const animate = () => {
      requestAnimationFrame(animate);
      
      mesh.rotation.x += 0.01;
      mesh.rotation.y += 0.02;
      particles.rotation.y += 0.005;
      
      renderer.render(scene, camera);
    };

    animate();

    return () => {
      scene.clear();
      renderer.dispose();
    };
  }, [isVisible]);

  useEffect(() => {
    if (!isVisible) return;

    setShowContent(true);
    let currentStep = 0;
    
    const progressInterval = setInterval(() => {
      if (currentStep < loadingSteps.length) {
        setProgress(loadingSteps[currentStep].progress);
        setLoadingText(loadingSteps[currentStep].text);
        currentStep++;
      } else {
        clearInterval(progressInterval);
        setTimeout(() => {
          onComplete();
        }, 1000);
      }
    }, 800);

    return () => clearInterval(progressInterval);
  }, [isVisible, onComplete]);

  const floatingIcons = [
    { Icon: BookOpen, delay: 0, color: 'text-blue-400' },
    { Icon: Brain, delay: 0.2, color: 'text-purple-400' },
    { Icon: Zap, delay: 0.4, color: 'text-yellow-400' },
    { Icon: Sparkles, delay: 0.6, color: 'text-pink-400' },
    { Icon: Rocket, delay: 0.8, color: 'text-green-400' },
    { Icon: Trophy, delay: 1.0, color: 'text-orange-400' },
    { Icon: Target, delay: 1.2, color: 'text-red-400' },
    { Icon: Star, delay: 1.4, color: 'text-indigo-400' }
  ];

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 1.1 }}
        transition={{ duration: 0.6 }}
        className="fixed inset-0 z-[9999] bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center"
      >
        {/* Animated Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[conic-gradient(from_0deg,transparent,rgba(147,51,234,0.1),transparent)]" />
        </div>

        {/* Floating Icons */}
        <div className="absolute inset-0 overflow-hidden">
          {floatingIcons.map(({ Icon, delay, color }, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0, rotate: 0 }}
              animate={{ 
                opacity: [0, 1, 0],
                scale: [0, 1.2, 0],
                rotate: [0, 360],
                x: [0, Math.sin(index) * 100, 0],
                y: [0, Math.cos(index) * 100, 0]
              }}
              transition={{
                duration: 4,
                delay: delay,
                repeat: Infinity,
                repeatType: "loop"
              }}
              className={`absolute ${color}`}
              style={{
                left: `${20 + (index * 10)}%`,
                top: `${15 + (index * 8)}%`
              }}
            >
              <Icon className="w-8 h-8" />
            </motion.div>
          ))}
        </div>

        <div className="relative z-10 text-center space-y-8 max-w-md mx-auto px-6">
          {/* 3D Canvas */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="mx-auto relative"
          >
            <canvas 
              ref={canvasRef}
              className="w-[300px] h-[300px] mx-auto"
            />
            
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-blue-500/20 rounded-full blur-xl animate-pulse" />
          </motion.div>

          {/* Logo Text */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="space-y-4"
          >
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              StudentHub
            </h1>
            <p className="text-lg text-gray-300">
              Your Ultimate Study Companion
            </p>
          </motion.div>

          {/* Progress Bar */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1, duration: 0.6 }}
            className="space-y-4"
          >
            <div className="relative w-full h-2 bg-gray-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full relative"
              >
                <div className="absolute inset-0 bg-white/30 animate-shimmer" />
              </motion.div>
              
              {/* Progress Sparkles */}
              <motion.div
                animate={{ x: `${progress * 3}px` }}
                transition={{ duration: 0.5 }}
                className="absolute top-0 right-0 w-2 h-2 bg-white rounded-full shadow-lg"
                style={{ marginRight: `${100 - progress}%` }}
              />
            </div>

            <motion.p
              key={loadingText}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-sm text-gray-400 min-h-[20px]"
            >
              {loadingText}
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="text-xs text-gray-500"
            >
              {progress}% Complete
            </motion.div>
          </motion.div>

          {/* Stats Preview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2, duration: 0.8 }}
            className="grid grid-cols-3 gap-4 text-center"
          >
            <div className="space-y-1">
              <div className="text-lg font-bold text-blue-400">25K+</div>
              <div className="text-xs text-gray-400">Papers</div>
            </div>
            <div className="space-y-1">
              <div className="text-lg font-bold text-purple-400">170M+</div>
              <div className="text-xs text-gray-400">Users</div>
            </div>
            <div className="space-y-1">
              <div className="text-lg font-bold text-pink-400">30+</div>
              <div className="text-xs text-gray-400">Tools</div>
            </div>
          </motion.div>

          {/* Loading Dots */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.5 }}
            className="flex justify-center space-x-2"
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 1,
                  delay: i * 0.2,
                  repeat: Infinity,
                  repeatType: "loop"
                }}
                className="w-2 h-2 bg-blue-400 rounded-full"
              />
            ))}
          </motion.div>
        </div>

        {/* Corner Decorations */}
        <div className="absolute top-4 left-4">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-2 border-blue-400 border-dashed rounded-full"
          />
        </div>
        <div className="absolute bottom-4 right-4">
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="w-6 h-6 border-2 border-purple-400 border-dashed rounded-full"
          />
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default UltraModernLoader;
import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'framer-motion';

interface AnimatedLoaderProps {
  isLoading: boolean;
  onComplete: () => void;
}

export const AnimatedLoader: React.FC<AnimatedLoaderProps> = ({ isLoading, onComplete }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationIdRef = useRef<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [loadingPhase, setLoadingPhase] = useState(0);

  const phases = [
    "Initializing StudentHub...",
    "Loading 3D Components...",
    "Preparing 25,000+ Question Papers...",
    "Setting up AI Tools...",
    "Connecting to Community...",
    "Ready to Launch!"
  ];

  useEffect(() => {
    if (!isLoading) return;

    // Progress simulation
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 3;
        
        // Update loading phase based on progress
        const phase = Math.floor((newProgress / 100) * phases.length);
        setLoadingPhase(Math.min(phase, phases.length - 1));
        
        if (newProgress >= 100) {
          clearInterval(progressInterval);
          setTimeout(onComplete, 1000);
          return 100;
        }
        return newProgress;
      });
    }, 100);

    return () => clearInterval(progressInterval);
  }, [isLoading, onComplete]);

  useEffect(() => {
    if (!mountRef.current || !isLoading) return;

    // Create Three.js scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true,
      powerPreference: "high-performance"
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x0a0a0a, 0.95);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    mountRef.current.appendChild(renderer.domElement);
    sceneRef.current = scene;
    rendererRef.current = renderer;

    // Create central hub (icosahedron)
    const hubGeometry = new THREE.IcosahedronGeometry(1.5, 1);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x3b82f6,
      shininess: 100,
      transparent: true,
      opacity: 0.8,
      wireframe: true
    });
    const hub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(hub);

    // Create floating particles around hub
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 200;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 20;
      positions[i3 + 1] = (Math.random() - 0.5) * 20;
      positions[i3 + 2] = (Math.random() - 0.5) * 20;
      
      // Rainbow colors
      const hue = Math.random();
      const color = new THREE.Color().setHSL(hue, 0.8, 0.6);
      colors[i3] = color.r;
      colors[i3 + 1] = color.g;
      colors[i3 + 2] = color.b;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
      size: 0.1,
      vertexColors: true,
      blending: THREE.AdditiveBlending,
      transparent: true
    });
    
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // Create rotating rings
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const ringGeometry = new THREE.TorusGeometry(2 + i * 0.5, 0.05, 8, 100);
      const ringMaterial = new THREE.MeshPhongMaterial({
        color: [0xff6b6b, 0x4ecdc4, 0x45b7d1][i],
        transparent: true,
        opacity: 0.6
      });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.rotation.x = Math.PI / 2;
      ring.rotation.z = (i * Math.PI) / 3;
      scene.add(ring);
      rings.push(ring);
    }

    // Create orbiting spheres (representing question papers)
    const orbitingSpheres: THREE.Mesh[] = [];
    for (let i = 0; i < 8; i++) {
      const sphereGeometry = new THREE.SphereGeometry(0.15, 32, 32);
      const sphereMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(i / 8, 0.8, 0.6),
        shininess: 100
      });
      const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
      sphere.position.set(4, 0, 0);
      scene.add(sphere);
      orbitingSpheres.push(sphere);
    }

    // Add lights
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    camera.position.z = 8;

    // Animation loop
    const animate = () => {
      if (!scene || !renderer) return;

      const time = Date.now() * 0.001;

      // Rotate hub
      hub.rotation.x += 0.01;
      hub.rotation.y += 0.02;

      // Rotate rings
      rings.forEach((ring, index) => {
        ring.rotation.x += 0.005 * (index + 1);
        ring.rotation.y += 0.003 * (index + 1);
      });

      // Animate particles
      const positions = particles.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        positions[i3 + 1] += Math.sin(time + i) * 0.01;
      }
      particles.geometry.attributes.position.needsUpdate = true;
      particles.rotation.y += 0.002;

      // Orbit spheres
      orbitingSpheres.forEach((sphere, index) => {
        const angle = time + (index * Math.PI * 2) / orbitingSpheres.length;
        sphere.position.x = Math.cos(angle) * 4;
        sphere.position.z = Math.sin(angle) * 4;
        sphere.position.y = Math.sin(time * 2 + index) * 0.5;
        sphere.rotation.x += 0.02;
        sphere.rotation.y += 0.02;
      });

      // Camera movement
      camera.position.x = Math.sin(time * 0.2) * 2;
      camera.position.y = Math.cos(time * 0.3) * 1;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      animationIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [isLoading]);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900"
        >
          {/* 3D Canvas */}
          <div ref={mountRef} className="absolute inset-0" />
          
          {/* Overlay Content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center space-y-8 z-10">
              {/* Logo Animation */}
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ duration: 1, ease: "easeOutBack" }}
                className="relative"
              >
                <div className="text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  STUDENTHUB
                </div>
                <div className="text-lg text-gray-300 mt-2">India's Largest Question Paper Platform</div>
              </motion.div>

              {/* Loading Phase Text */}
              <motion.div
                key={loadingPhase}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="text-xl text-gray-200 font-medium"
              >
                {phases[loadingPhase]}
              </motion.div>

              {/* Progress Bar */}
              <div className="w-80 mx-auto space-y-4">
                <div className="relative h-2 bg-gray-700 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3 }}
                    className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full"
                  />
                  
                  {/* Shimmer effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-shimmer" />
                </div>
                
                <div className="flex justify-between text-sm text-gray-400">
                  <span>{Math.round(progress)}%</span>
                  <span>Loading...</span>
                </div>
              </div>

              {/* Feature Highlights */}
              <motion.div
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1, duration: 0.8 }}
                className="grid grid-cols-3 gap-6 mt-12 text-center"
              >
                {[
                  { label: "Question Papers", value: "25,000+" },
                  { label: "Active Users", value: "170M+" },
                  { label: "Languages", value: "22+" }
                ].map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1.5 + index * 0.2, duration: 0.5 }}
                    className="space-y-1"
                  >
                    <div className="text-2xl font-bold text-blue-400">{stat.value}</div>
                    <div className="text-sm text-gray-400">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>

              {/* Floating Elements */}
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ 
                      x: Math.random() * window.innerWidth,
                      y: Math.random() * window.innerHeight,
                      opacity: 0
                    }}
                    animate={{
                      y: [-20, 0, -20],
                      opacity: [0, 0.6, 0]
                    }}
                    transition={{
                      duration: 3,
                      delay: i * 0.3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className={`absolute w-2 h-2 rounded-full ${
                      ['bg-blue-400', 'bg-purple-400', 'bg-pink-400'][i % 3]
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
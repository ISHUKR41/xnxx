import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import * as THREE from 'three';

interface UltraModernLogoV4Props {
  size?: number;
  variant?: 'full' | 'compact' | 'icon';
  showText?: boolean;
  className?: string;
}

export const UltraModernLogoV4: React.FC<UltraModernLogoV4Props> = ({
  size = 80,
  variant = 'full',
  showText = true,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (!canvasRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current, 
      alpha: true, 
      antialias: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Enhanced Lighting System
    const ambientLight = new THREE.AmbientLight(0x404040, 0.8);
    scene.add(ambientLight);

    const directionalLight1 = new THREE.DirectionalLight(0x667eea, 2.0);
    directionalLight1.position.set(3, 3, 3);
    scene.add(directionalLight1);

    const directionalLight2 = new THREE.DirectionalLight(0xf093fb, 1.5);
    directionalLight2.position.set(-3, 2, 1);
    scene.add(directionalLight2);

    const directionalLight3 = new THREE.DirectionalLight(0x4facfe, 1.2);
    directionalLight3.position.set(0, -3, 2);
    scene.add(directionalLight3);

    // Central Knowledge Hub - Advanced Geometry
    const hubGeometry = new THREE.IcosahedronGeometry(0.8, 2);
    const hubMaterial = new THREE.MeshPhongMaterial({
      color: 0x667eea,
      transparent: true,
      opacity: 0.95,
      emissive: 0x667eea,
      emissiveIntensity: 0.3,
      shininess: 150,
      reflectivity: 0.8
    });
    const knowledgeHub = new THREE.Mesh(hubGeometry, hubMaterial);
    scene.add(knowledgeHub);

    // Orbital Elements - S and H Letters
    const sLetterElements: THREE.Mesh[] = [];
    const hLetterElements: THREE.Mesh[] = [];

    // Create S Letter Elements
    for (let i = 0; i < 8; i++) {
      const elementGeometry = new THREE.BoxGeometry(0.15, 0.15, 0.15);
      const elementMaterial = new THREE.MeshPhongMaterial({
        color: 0xf093fb,
        transparent: true,
        opacity: 0.9,
        emissive: 0xf093fb,
        emissiveIntensity: 0.2
      });
      
      const element = new THREE.Mesh(elementGeometry, elementMaterial);
      element.userData = {
        index: i,
        orbitRadius: 2.0,
        orbitSpeed: 0.02,
        rotationSpeed: 0.03
      };
      
      sLetterElements.push(element);
      scene.add(element);
    }

    // Create H Letter Elements
    for (let i = 0; i < 8; i++) {
      const elementGeometry = new THREE.SphereGeometry(0.12, 16, 16);
      const elementMaterial = new THREE.MeshPhongMaterial({
        color: 0x4facfe,
        transparent: true,
        opacity: 0.9,
        emissive: 0x4facfe,
        emissiveIntensity: 0.2
      });
      
      const element = new THREE.Mesh(elementGeometry, elementMaterial);
      element.userData = {
        index: i,
        orbitRadius: 2.5,
        orbitSpeed: -0.015,
        rotationSpeed: 0.025
      };
      
      hLetterElements.push(element);
      scene.add(element);
    }

    // Particle System
    const particles: THREE.Mesh[] = [];
    for (let i = 0; i < 30; i++) {
      const particleGeometry = new THREE.SphereGeometry(0.03, 8, 8);
      const particleMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color().setHSL(Math.random(), 0.8, 0.6),
        transparent: true,
        opacity: 0.7
      });
      
      const particle = new THREE.Mesh(particleGeometry, particleMaterial);
      particle.position.set(
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6,
        (Math.random() - 0.5) * 6
      );
      
      particle.userData = {
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.01,
          (Math.random() - 0.5) * 0.01,
          (Math.random() - 0.5) * 0.01
        )
      };
      
      particles.push(particle);
      scene.add(particle);
    }

    // Rotating Rings
    const rings: THREE.Mesh[] = [];
    for (let i = 0; i < 3; i++) {
      const ringGeometry = new THREE.TorusGeometry(1.5 + i * 0.3, 0.05, 8, 32);
      const ringMaterial = new THREE.MeshPhongMaterial({
        color: [0x667eea, 0xf093fb, 0x4facfe][i],
        transparent: true,
        opacity: 0.4,
        emissive: [0x667eea, 0xf093fb, 0x4facfe][i],
        emissiveIntensity: 0.1
      });
      
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.userData = {
        rotationAxis: i === 0 ? 'x' : i === 1 ? 'y' : 'z',
        rotationSpeed: 0.01 + i * 0.005
      };
      
      rings.push(ring);
      scene.add(ring);
    }

    camera.position.z = 4;

    // Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Central Hub Animation
      knowledgeHub.rotation.x += 0.008;
      knowledgeHub.rotation.y += 0.012;
      knowledgeHub.rotation.z += 0.006;

      if (isHovered) {
        knowledgeHub.scale.setScalar(1.2);
        const material = knowledgeHub.material as THREE.MeshPhongMaterial;
        material.emissiveIntensity = 0.5;
      } else {
        knowledgeHub.scale.setScalar(1);
        const material = knowledgeHub.material as THREE.MeshPhongMaterial;
        material.emissiveIntensity = 0.3;
      }

      // S Letter Elements - Form S Shape
      sLetterElements.forEach((element, index) => {
        const userData = element.userData;
        const angle = time * userData.orbitSpeed + (index / sLetterElements.length) * Math.PI * 2;
        
        // S-curve pattern
        const t = index / (sLetterElements.length - 1);
        const sPattern = Math.sin(t * Math.PI * 2) * 0.5;
        
        element.position.x = Math.cos(angle) * userData.orbitRadius + sPattern;
        element.position.y = (t - 0.5) * 2;
        element.position.z = Math.sin(angle) * userData.orbitRadius * 0.3;
        
        element.rotation.x += userData.rotationSpeed;
        element.rotation.y += userData.rotationSpeed;
        element.rotation.z += userData.rotationSpeed;
      });

      // H Letter Elements - Form H Shape
      hLetterElements.forEach((element, index) => {
        const userData = element.userData;
        const angle = time * userData.orbitSpeed + (index / hLetterElements.length) * Math.PI * 2;
        
        // H-pattern
        const t = index / (hLetterElements.length - 1);
        const isVertical = index < 3 || index >= 5;
        const isHorizontal = index >= 3 && index < 5;
        
        if (isVertical) {
          element.position.x = Math.cos(angle) * userData.orbitRadius + (index < 3 ? -0.8 : 0.8);
          element.position.y = (index < 3 ? (index - 1) * 0.6 : (index - 6) * 0.6);
        } else {
          element.position.x = Math.cos(angle) * userData.orbitRadius + (index - 4) * 0.4;
          element.position.y = 0;
        }
        
        element.position.z = Math.sin(angle) * userData.orbitRadius * 0.3;
        
        element.rotation.x += userData.rotationSpeed;
        element.rotation.y += userData.rotationSpeed;
        element.rotation.z += userData.rotationSpeed;
      });

      // Particle Animation
      particles.forEach((particle) => {
        particle.position.add(particle.userData.velocity);
        
        // Boundary check
        if (Math.abs(particle.position.x) > 3) particle.userData.velocity.x *= -1;
        if (Math.abs(particle.position.y) > 3) particle.userData.velocity.y *= -1;
        if (Math.abs(particle.position.z) > 3) particle.userData.velocity.z *= -1;
        
        particle.rotation.x += 0.02;
        particle.rotation.y += 0.02;
      });

      // Ring Animation
      rings.forEach((ring) => {
        const axis = ring.userData.rotationAxis;
        const speed = ring.userData.rotationSpeed;
        
        if (axis === 'x') ring.rotation.x += speed;
        else if (axis === 'y') ring.rotation.y += speed;
        else ring.rotation.z += speed;
      });

      // Camera subtle movement
      camera.position.x = Math.sin(time * 0.1) * 0.2;
      camera.position.y = Math.cos(time * 0.08) * 0.1;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [size, isHovered]);

  return (
    <div 
      className={`flex items-center space-x-3 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 3D Canvas Logo */}
      <motion.div
        className="relative"
        whileHover={{ scale: 1.1, rotateY: 15 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        <canvas 
          ref={canvasRef}
          className="rounded-2xl shadow-2xl border-2 border-white/20 backdrop-blur-sm"
          style={{ width: size, height: size }}
        />
        
        {/* Glow Effect */}
        <motion.div
          className="absolute inset-0 rounded-2xl"
          animate={{
            boxShadow: [
              '0 0 0 0 rgba(102, 126, 234, 0.4)',
              '0 0 0 8px rgba(102, 126, 234, 0)',
              '0 0 0 0 rgba(102, 126, 234, 0.4)'
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </motion.div>

      {/* Enhanced Text */}
      {showText && variant !== 'icon' && (
        <motion.div
          className="space-y-1"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <motion.h1 
            className={`font-bold leading-none ${
              variant === 'compact' ? 'text-xl' : 'text-2xl'
            }`}
            animate={{
              backgroundPosition: ['0%', '100%', '0%']
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            style={{
              background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)), hsl(var(--foreground)))',
              backgroundSize: '300% 300%',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}
          >
            STUDENTHUB
          </motion.h1>
          
          {variant === 'full' && (
            <motion.p 
              className="text-sm text-foreground-secondary font-medium"
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              Educational Excellence
            </motion.p>
          )}
        </motion.div>
      )}
    </div>
  );
};
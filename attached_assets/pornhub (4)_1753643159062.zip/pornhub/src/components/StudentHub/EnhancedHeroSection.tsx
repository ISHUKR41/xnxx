import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Download, 
  Award, 
  TrendingUp,
  Sparkles,
  Zap,
  Globe,
  ChevronRight,
  Play,
  Star,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import * as THREE from 'three';

export const EnhancedHeroSection: React.FC = () => {
  const [currentStats, setCurrentStats] = useState({ papers: 25000, students: 125000, universities: 850 });
  const [isHovered, setIsHovered] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true });
  const frameRef = useRef<number | null>(null);

  // Enhanced Mouse Tracking
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        setMousePosition({
          x: ((e.clientX - rect.left) / rect.width - 0.5) * 2,
          y: ((e.clientY - rect.top) / rect.height - 0.5) * 2
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Advanced 3D Background Scene
  useEffect(() => {
    if (!canvasRef.current || !isInView) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Advanced Lighting System
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const primaryLight = new THREE.DirectionalLight(0x667eea, 1.5);
    primaryLight.position.set(5, 5, 5);
    scene.add(primaryLight);

    const accentLight = new THREE.DirectionalLight(0xf093fb, 1.2);
    accentLight.position.set(-5, 3, 2);
    scene.add(accentLight);

    const backLight = new THREE.DirectionalLight(0x4facfe, 0.8);
    backLight.position.set(0, -5, -3);
    scene.add(backLight);

    // Floating Knowledge Nodes
    const nodes: THREE.Mesh[] = [];
    const nodeTypes = [
      { geometry: new THREE.IcosahedronGeometry(0.3, 1), color: 0x667eea, count: 20 },
      { geometry: new THREE.OctahedronGeometry(0.25), color: 0xf093fb, count: 15 },
      { geometry: new THREE.TetrahedronGeometry(0.2), color: 0x4facfe, count: 12 },
      { geometry: new THREE.DodecahedronGeometry(0.18), color: 0x00d4ff, count: 10 }
    ];

    nodeTypes.forEach(type => {
      for (let i = 0; i < type.count; i++) {
        const material = new THREE.MeshPhongMaterial({
          color: type.color,
          transparent: true,
          opacity: 0.8,
          emissive: type.color,
          emissiveIntensity: 0.1
        });
        
        const node = new THREE.Mesh(type.geometry, material);
        node.position.set(
          (Math.random() - 0.5) * 30,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 15
        );
        
        node.userData = {
          rotationSpeed: {
            x: (Math.random() - 0.5) * 0.02,
            y: (Math.random() - 0.5) * 0.02,
            z: (Math.random() - 0.5) * 0.02
          },
          floatSpeed: 0.01 + Math.random() * 0.02,
          floatAmplitude: 0.5 + Math.random() * 1.0,
          originalY: node.position.y
        };
        
        nodes.push(node);
        scene.add(node);
      }
    });

    // Connection Lines between nodes
    const connections: THREE.Line[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const distance = nodes[i].position.distanceTo(nodes[j].position);
        if (distance < 8) {
          const points = [nodes[i].position, nodes[j].position];
          const geometry = new THREE.BufferGeometry().setFromPoints(points);
          const material = new THREE.LineBasicMaterial({ 
            color: 0x667eea,
            transparent: true,
            opacity: 0.2
          });
          const line = new THREE.Line(geometry, material);
          connections.push(line);
          scene.add(line);
        }
      }
    }

    camera.position.z = 15;

    // Animation Loop
    let time = 0;
    const animate = () => {
      time += 0.016;

      // Animate nodes
      nodes.forEach((node, index) => {
        const userData = node.userData;
        
        node.rotation.x += userData.rotationSpeed.x;
        node.rotation.y += userData.rotationSpeed.y;
        node.rotation.z += userData.rotationSpeed.z;
        
        node.position.y = userData.originalY + Math.sin(time * userData.floatSpeed + index) * userData.floatAmplitude;
        
        // Mouse interaction
        const mouseInfluence = 0.5;
        node.position.x += mousePosition.x * mouseInfluence * 0.1;
        node.position.z += mousePosition.y * mouseInfluence * 0.1;
        
        // Hover effect
        if (isHovered) {
          node.scale.setScalar(1.2);
          const material = node.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0.3;
        } else {
          node.scale.setScalar(1);
          const material = node.material as THREE.MeshPhongMaterial;
          material.emissiveIntensity = 0.1;
        }
      });

      // Camera movement
      camera.position.x = Math.sin(time * 0.1) * 2 + mousePosition.x * 3;
      camera.position.y = Math.cos(time * 0.08) * 1 + mousePosition.y * 2;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameRef.current = requestAnimationFrame(animate);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
      scene.clear();
      renderer.dispose();
    };
  }, [isInView, isHovered, mousePosition]);

  // Dynamic Stats Animation
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStats(prev => ({
        papers: prev.papers + Math.floor(Math.random() * 5) + 1,
        students: prev.students + Math.floor(Math.random() * 50) + 10,
        universities: prev.universities + Math.floor(Math.random() * 2)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const features = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "25,000+ Question Papers",
      description: "Largest collection of authentic past year papers",
      color: "from-blue-500 to-blue-600",
      delay: 0.1
    },
    {
      icon: <GraduationCap className="w-6 h-6" />,
      title: "All Educational Levels",
      description: "From Class 9 to PhD across all boards",
      color: "from-purple-500 to-purple-600",
      delay: 0.2
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "30+ Smart Tools",
      description: "AI-powered PDF, image, and text utilities",
      color: "from-green-500 to-green-600",
      delay: 0.3
    },
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Global Access",
      description: "Available 24/7 from anywhere in the world",
      color: "from-orange-500 to-orange-600",
      delay: 0.4
    }
  ];

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-background-secondary to-background"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 3D Background Canvas */}
      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-30"
      />

      {/* Animated Background Gradients */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            'radial-gradient(circle at 20% 50%, rgba(102, 126, 234, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 80% 20%, rgba(240, 147, 251, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 40% 80%, rgba(79, 172, 254, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 20% 50%, rgba(102, 126, 234, 0.1) 0%, transparent 50%)'
          ]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-gradient-to-r from-primary to-accent rounded-full"
            animate={{
              x: [0, window.innerWidth],
              y: [
                Math.random() * window.innerHeight,
                Math.random() * window.innerHeight,
                Math.random() * window.innerHeight
              ],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0]
            }}
            transition={{
              duration: 10 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeInOut"
            }}
            style={{
              left: Math.random() * -100,
              top: Math.random() * window.innerHeight
            }}
          />
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="text-center space-y-12">
          {/* Enhanced Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Animated Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="flex justify-center"
            >
              <Badge 
                variant="outline" 
                className="px-6 py-2 text-sm bg-gradient-to-r from-primary/20 to-accent/20 border-primary/30 backdrop-blur-sm"
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  className="mr-2"
                >
                  <Sparkles className="w-4 h-4" />
                </motion.div>
                India's #1 Educational Platform
              </Badge>
            </motion.div>

            {/* Main Headline */}
            <motion.h1 
              className="text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold leading-tight"
              animate={{
                backgroundPosition: ['0%', '100%', '0%']
              }}
              transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
              style={{
                background: 'linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--accent)), hsl(var(--primary)), hsl(var(--foreground)))',
                backgroundSize: '400% 400%',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              <motion.span
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0 }}
              >
                STUDENT
              </motion.span>
              <motion.span
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                HUB
              </motion.span>
              <motion.span
                className="block text-3xl md:text-4xl lg:text-5xl xl:text-6xl mt-4"
                animate={{ 
                  scale: [1, 1.05, 1],
                  opacity: [0.9, 1, 0.9]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                Educational Excellence
              </motion.span>
            </motion.h1>

            {/* Enhanced Subtitle */}
            <motion.p 
              className="text-xl md:text-2xl lg:text-3xl text-foreground-secondary max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 1, delay: 0.4 }}
            >
              Access <motion.span 
                className="text-primary font-bold"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {currentStats.papers.toLocaleString()}+
              </motion.span> authentic question papers, 
              <motion.span 
                className="text-accent font-bold"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                30+ smart tools
              </motion.span>, and comprehensive study materials for all Indian educational boards and competitive exams.
            </motion.p>
          </motion.div>

          {/* Enhanced Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <motion.div
              whileHover={{ scale: 1.05, rotateY: 5 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                className="
                  group relative overflow-hidden
                  bg-gradient-to-r from-primary via-accent to-primary
                  hover:from-primary/90 hover:via-accent/90 hover:to-primary/90
                  text-white font-bold py-4 px-8 rounded-xl
                  shadow-2xl hover:shadow-3xl
                  text-lg border-2 border-white/20 hover:border-white/40
                  transform-gpu transition-all duration-500
                  bg-size-200 bg-pos-0
                "
                style={{ backgroundSize: '200% 200%' }}
              >
                <motion.div
                  className="absolute inset-0"
                  animate={{
                    backgroundPosition: ['0%', '100%', '0%']
                  }}
                  transition={{ duration: 3, ease: "easeInOut", repeat: Infinity }}
                  style={{
                    background: 'linear-gradient(-45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.3), rgba(255,255,255,0.1))',
                    backgroundSize: '200% 200%'
                  }}
                />
                
                <span className="relative z-10 flex items-center space-x-3">
                  <span>Explore Question Papers</span>
                  <motion.div
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    <ChevronRight className="w-5 h-5" />
                  </motion.div>
                </span>

                <motion.div
                  className="absolute inset-0 rounded-xl"
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(102, 126, 234, 0.4)',
                      '0 0 0 10px rgba(102, 126, 234, 0)',
                      '0 0 0 0 rgba(102, 126, 234, 0.4)'
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                variant="outline" 
                size="lg"
                className="
                  group py-4 px-8 rounded-xl text-lg font-semibold
                  border-2 border-primary/50 hover:border-primary
                  bg-background/20 backdrop-blur-sm
                  hover:bg-primary/10 transition-all duration-300
                  text-foreground hover:text-primary
                "
              >
                <span className="flex items-center space-x-3">
                  <Play className="w-5 h-5" />
                  <span>Watch Demo</span>
                </span>
              </Button>
            </motion.div>
          </motion.div>

          {/* Enhanced Feature Cards */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.8 }}
            className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 mt-20"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50, rotateY: -15 }}
                animate={isInView ? { opacity: 1, y: 0, rotateY: 0 } : {}}
                transition={{ 
                  duration: 0.8, 
                  delay: feature.delay,
                  type: "spring",
                  bounce: 0.3
                }}
                whileHover={{ 
                  y: -10, 
                  rotateY: 5,
                  scale: 1.05,
                  transition: { duration: 0.3 }
                }}
                className="group relative"
              >
                <div className="
                  relative p-8 rounded-2xl backdrop-blur-sm
                  bg-gradient-to-br from-white/10 to-white/5
                  border border-white/20 hover:border-white/40
                  shadow-xl hover:shadow-2xl
                  transform-gpu transition-all duration-500
                  overflow-hidden
                ">
                  {/* Animated Background */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10`}
                    transition={{ duration: 0.5 }}
                  />

                  {/* Floating Particles */}
                  <div className="absolute inset-0 overflow-hidden">
                    {[...Array(5)].map((_, i) => (
                      <motion.div
                        key={i}
                        className={`absolute w-1 h-1 bg-gradient-to-r ${feature.color} rounded-full opacity-0 group-hover:opacity-60`}
                        animate={{
                          x: [0, Math.random() * 200 - 100],
                          y: [0, Math.random() * 200 - 100],
                          scale: [0, 1, 0]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: Math.random() * 2
                        }}
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`
                        }}
                      />
                    ))}
                  </div>

                  <div className="relative z-10 space-y-4">
                    <motion.div
                      className={`
                        w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color}
                        flex items-center justify-center text-white
                        shadow-lg group-hover:shadow-xl
                        transform-gpu transition-all duration-300
                      `}
                      whileHover={{ 
                        rotate: [0, 10, -10, 0],
                        scale: 1.1
                      }}
                      transition={{ duration: 0.6 }}
                    >
                      {feature.icon}
                    </motion.div>

                    <div>
                      <motion.h3 
                        className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors duration-300"
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                      >
                        {feature.title}
                      </motion.h3>
                      <p className="text-foreground-secondary group-hover:text-foreground transition-colors duration-300">
                        {feature.description}
                      </p>
                    </div>

                    <motion.div
                      className="flex items-center text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      animate={{ x: [0, 10, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <span className="text-sm font-medium mr-2">Learn More</span>
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Enhanced Live Stats */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 1.2 }}
            className="grid grid-cols-3 gap-8 mt-20 max-w-4xl mx-auto"
          >
            {[
              { label: "Question Papers", value: currentStats.papers, icon: <BookOpen className="w-6 h-6" /> },
              { label: "Active Students", value: currentStats.students, icon: <Users className="w-6 h-6" /> },
              { label: "Universities", value: currentStats.universities, icon: <Award className="w-6 h-6" /> }
            ].map((stat, index) => (
              <motion.div
                key={index}
                className="text-center space-y-4"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <motion.div
                  className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center text-primary border border-primary/30"
                  animate={{ 
                    rotate: [0, 360],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    rotate: { duration: 8, repeat: Infinity, ease: "linear" },
                    scale: { duration: 2, repeat: Infinity, delay: index * 0.3 }
                  }}
                >
                  {stat.icon}
                </motion.div>
                
                <div>
                  <motion.div 
                    className="text-3xl md:text-4xl font-bold text-foreground"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: index * 0.5 }}
                  >
                    {stat.value.toLocaleString()}+
                  </motion.div>
                  <div className="text-foreground-secondary font-medium">
                    {stat.label}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
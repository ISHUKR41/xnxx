import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  Upload,
  Download,
  FileText,
  Image,
  Scissors,
  Combine,
  Shield,
  Lock,
  Unlock,
  RotateCcw,
  Edit,
  Zap,
  Crop,
  Type,
  ClipboardCheck,
  Brain,
  Mic,
  Camera,
  BookOpen,
  Calculator,
  Search,
  RefreshCw,
  Settings,
  Wrench,
  Sparkles,
  Star,
  Heart,
  Eye,
  Palette,
  Grid,
  Layers
} from 'lucide-react';

interface ToolProps {
  toolName: string;
  onClose: () => void;
}

export const ComprehensiveToolImplementation: React.FC<ToolProps> = ({ toolName, onClose }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [options, setOptions] = useState<Record<string, any>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Generic file upload handler
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = Array.from(event.target.files || []);
    setFiles(uploadedFiles);
    toast({
      title: "Files uploaded",
      description: `${uploadedFiles.length} file(s) selected`,
    });
  };

  // Generic processing function with backend API calls
  const processFiles = async () => {
    if (files.length === 0 && !text) {
      toast({
        title: "No input provided",
        description: "Please upload files or enter text",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setProgress(0);

    try {
      const formData = new FormData();
      files.forEach((file, index) => {
        formData.append(`file${index}`, file);
      });
      formData.append('text', text);
      formData.append('toolName', toolName);
      formData.append('options', JSON.stringify(options));

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Make API call to backend
      const response = await fetch('/api/tools/process', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      clearInterval(progressInterval);
      setProgress(100);

      if (result.success) {
        setResult(result.downloadUrl || result.processedText || 'Processing completed successfully');
        toast({
          title: "Processing completed",
          description: result.message || "Your files have been processed successfully",
        });
      } else {
        throw new Error(result.error || 'Processing failed');
      }
    } catch (error) {
      console.error('Processing error:', error);
      toast({
        title: "Processing failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Tool-specific UI components
  const renderToolSpecificUI = () => {
    switch (toolName) {
      case 'PDF to Word':
        return (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
              <FileText className="w-12 h-12 mx-auto mb-4 text-blue-500" />
              <p className="text-lg font-semibold mb-2">Upload PDF Files</p>
              <p className="text-gray-600 mb-4">Drag and drop or click to select PDF files</p>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Select PDF Files
              </Button>
            </div>
            {files.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold">Selected Files:</h4>
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-100 rounded">
                    <span>{file.name}</span>
                    <Badge>{(file.size / 1024 / 1024).toFixed(2)} MB</Badge>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'Image Compressor':
        return (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-green-300 rounded-lg p-8 text-center hover:border-green-500 transition-colors">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
              <Image className="w-12 h-12 mx-auto mb-4 text-green-500" />
              <p className="text-lg font-semibold mb-2">Upload Images</p>
              <p className="text-gray-600 mb-4">Supports JPG, PNG, WebP, and more</p>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Select Images
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Quality</label>
                <Input
                  type="range"
                  min="10"
                  max="100"
                  value={options.quality || 80}
                  onChange={(e) => setOptions({...options, quality: parseInt(e.target.value)})}
                />
                <span className="text-sm text-gray-600">{options.quality || 80}%</span>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Format</label>
                <select
                  value={options.format || 'jpeg'}
                  onChange={(e) => setOptions({...options, format: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="jpeg">JPEG</option>
                  <option value="png">PNG</option>
                  <option value="webp">WebP</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 'Grammar Checker':
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium">Enter text to check:</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type or paste your text here..."
                className="min-h-[200px]"
              />
              <div className="flex justify-between text-sm text-gray-600">
                <span>{text.length} characters</span>
                <span>{text.split(/\s+/).filter(word => word.length > 0).length} words</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setText('')} variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Clear
              </Button>
              <Button onClick={() => navigator.clipboard.readText().then(setText)} variant="outline">
                <ClipboardCheck className="w-4 h-4 mr-2" />
                Paste
              </Button>
            </div>
          </div>
        );

      case 'Text Summarizer':
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium">Enter text to summarize:</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste your article, document, or long text here..."
                className="min-h-[250px]"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Summary Length</label>
                <select
                  value={options.length || 'medium'}
                  onChange={(e) => setOptions({...options, length: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="short">Short (2-3 sentences)</option>
                  <option value="medium">Medium (4-6 sentences)</option>
                  <option value="long">Long (7-10 sentences)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Focus</label>
                <select
                  value={options.focus || 'general'}
                  onChange={(e) => setOptions({...options, focus: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="general">General Summary</option>
                  <option value="academic">Academic Focus</option>
                  <option value="business">Business Focus</option>
                  <option value="technical">Technical Focus</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 'OCR Scanner':
        return (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-purple-300 rounded-lg p-8 text-center hover:border-purple-500 transition-colors">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
              <Camera className="w-12 h-12 mx-auto mb-4 text-purple-500" />
              <p className="text-lg font-semibold mb-2">Upload Images or PDFs</p>
              <p className="text-gray-600 mb-4">Extract text from images and documents</p>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Select Files
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Language</label>
                <select
                  value={options.language || 'eng'}
                  onChange={(e) => setOptions({...options, language: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="eng">English</option>
                  <option value="hin">Hindi</option>
                  <option value="ben">Bengali</option>
                  <option value="tel">Telugu</option>
                  <option value="mar">Marathi</option>
                  <option value="tam">Tamil</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Output Format</label>
                <select
                  value={options.outputFormat || 'text'}
                  onChange={(e) => setOptions({...options, outputFormat: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="text">Plain Text</option>
                  <option value="formatted">Formatted Text</option>
                  <option value="json">JSON Data</option>
                </select>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-500 transition-colors">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
              <Wrench className="w-12 h-12 mx-auto mb-4 text-gray-500" />
              <p className="text-lg font-semibold mb-2">Universal Tool Interface</p>
              <p className="text-gray-600 mb-4">Upload files or enter text for processing</p>
              <Button onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" />
                Select Files
              </Button>
            </div>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Or enter text here..."
              className="min-h-[100px]"
            />
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold gradient-text">{toolName}</h2>
        <Button variant="outline" onClick={onClose}>
          ✕
        </Button>
      </div>

      {renderToolSpecificUI()}

      {isProcessing && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Processing...</span>
            <span className="text-sm text-gray-600">{progress}%</span>
          </div>
          <Progress value={progress} className="w-full" />
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>AI is working on your files...</span>
          </div>
        </div>
      )}

      <div className="flex gap-4">
        <Button 
          onClick={processFiles} 
          disabled={isProcessing || (files.length === 0 && !text)}
          className="flex-1 btn-hero"
        >
          {isProcessing ? (
            <>
              <Sparkles className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Process Files
            </>
          )}
        </Button>
        
        {result && (
          <Button onClick={() => window.open(result, '_blank')} className="flex-1">
            <Download className="w-4 h-4 mr-2" />
            Download Result
          </Button>
        )}
      </div>

      {result && !result.startsWith('http') && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="w-5 h-5 mr-2 text-yellow-500" />
              Processing Result
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg">
              <pre className="whitespace-pre-wrap text-sm">{result}</pre>
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
};

export default ComprehensiveToolImplementation;
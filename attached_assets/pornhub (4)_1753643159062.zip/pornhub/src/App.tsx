import React, { useState, useEffect } from 'react';
import "@/styles/globals.css";
import "./App.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { UltraModernAnimatedLoader } from "@/components/ui/UltraModernAnimatedLoader";
import Index from "./pages/Index";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Tools from "./pages/Tools";
import News from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import AdminNews from "./pages/AdminNews";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate app initialization time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {isLoading && (
          <UltraModernAnimatedLoader 
            onComplete={() => setIsLoading(false)} 
          />
        )}
        {!isLoading && (
          <>
            <Toaster />
            <Sonner />
            <Router>
              <Switch>
                <Route path="/" component={Index} />
                <Route path="/about" component={About} />
                <Route path="/contact" component={Contact} />
                <Route path="/tools" component={Tools} />
                <Route path="/news" component={News} />
                <Route path="/news/:slug" component={NewsDetail} />
                <Route path="/admin/news" component={AdminNews} />
                <Route component={NotFound} />
              </Switch>
            </Router>
          </>
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;

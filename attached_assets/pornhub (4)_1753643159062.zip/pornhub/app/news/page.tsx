import { NewsGrid } from '@/src/components/News/NewsGrid';

export default function NewsPage() {
  return <NewsGrid />;
}
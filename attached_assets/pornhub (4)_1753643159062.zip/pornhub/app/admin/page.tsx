import { AdminDashboard } from '@/src/components/News/AdminDashboard';

export default function AdminPage() {
  return <AdminDashboard />;
}